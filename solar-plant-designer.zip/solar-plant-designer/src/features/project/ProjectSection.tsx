import { useRef, useState } from 'react';
import { useStore } from '@/store/projectStore';
import { listProjects, loadProject, deleteProject, migrateProject, setLastOpen } from '@/services/storage';
import { createProject, createDemoProject } from '@/utils/projectFactory';
import { uid } from '@/utils/id';
import { TextField, SelectField, Notice } from '@/components/ui';
import { downloadBlob } from '@/services/exportService';
import type { LengthUnit } from '@/types';

export function ProjectSection() {
  const project = useStore((s) => s.project);
  const { setProject, update, save, notify } = useStore.getState();
  const isDirty = useStore((s) => s.dirty);
  const [list, setList] = useState(listProjects());
  const fileRef = useRef<HTMLInputElement>(null);
  const refresh = () => setList(listProjects());

  const guard = () => !isDirty || window.confirm('Discard unsaved changes to the current project?');

  return (
    <div className="space-y-3">
      <TextField label="Project name" value={project.name} testId="project-name" onCommit={(v) => update((p) => ({ ...p, name: v || 'Untitled project' }))} />
      <SelectField<LengthUnit> label="Default display length unit" value={project.settings.displayUnit}
        options={(['mm', 'cm', 'm', 'in', 'ft'] as LengthUnit[]).map((u) => ({ value: u, label: u }))}
        onChange={(u) => update((p) => ({ ...p, settings: { ...p.settings, displayUnit: u } }))} />
      {project.metadata.isDemo && <Notice tone="info">{project.metadata.notes}</Notice>}
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" data-testid="save-project" onClick={() => { save(); refresh(); }}>Save project</button>
        <button className="btn btn-secondary" data-testid="new-project" onClick={() => { if (!guard()) return; setProject(createProject(), { resetHistory: true, dirty: true }); notify('New project created'); }}>New project</button>
        <button className="btn btn-secondary" onClick={() => { const c = { ...structuredClone(project), id: uid('prj'), name: `${project.name} (copy)` }; setProject(c, { resetHistory: true, dirty: true }); notify('Duplicated - save to keep the copy'); }}>Duplicate</button>
        <button className="btn btn-secondary" onClick={() => { if (!guard()) return; setProject(createDemoProject(), { resetHistory: true, dirty: true }); }}>Load demo project</button>
      </div>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" onClick={() => fileRef.current?.click()}>Import project (.json)</button>
        <button className="btn btn-secondary" onClick={() => downloadBlob(new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' }), `${slug(project.name)}.spd.json`)}>Export project (.json)</button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" aria-label="Import project file"
          onChange={async (e) => {
            const f = e.target.files?.[0]; e.target.value = '';
            if (!f) return;
            try {
              const p = migrateProject(JSON.parse(await f.text()));
              if (!guard()) return;
              setProject(p, { resetHistory: true, dirty: true });
              notify(`Imported "${p.name}"`, 'ok');
            } catch (err) { notify(`Import failed: ${err instanceof Error ? err.message : 'invalid file'}`, 'error'); }
          }} />
      </div>
      <h3 className="subhead">Saved projects</h3>
      {!list.length && <p className="text-[13px] text-char-700">No saved projects yet. Save the current project to keep it in this browser.</p>}
      <ul className="divide-y divide-rule rounded-[3px] border border-rule bg-white" aria-label="Saved projects">
        {list.map((e) => (
          <li key={e.id} className={`flex items-center justify-between gap-2 px-2 py-1.5 text-[13px] ${e.id === project.id ? 'bg-pv-100/50' : ''}`}>
            <div className="min-w-0">
              <div className="truncate font-semibold">{e.name}</div>
              <div className="text-[11.5px] text-char-700">Saved {new Date(e.updatedAt).toLocaleString()}</div>
            </div>
            <div className="flex shrink-0 gap-1">
              <button className="btn btn-ghost px-2 py-1" onClick={() => { if (!guard()) return; const p = loadProject(e.id); if (p) { setProject(p, { resetHistory: true }); setLastOpen(p.id); } }}>Open</button>
              <button className="btn btn-ghost px-2 py-1 text-alarm-600" aria-label={`Delete ${e.name}`} onClick={() => { if (window.confirm(`Delete "${e.name}"? This cannot be undone.`)) { deleteProject(e.id); refresh(); } }}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
      <p className="text-[11.5px] text-char-700">Projects are stored in this browser (localStorage, schema v{project.schemaVersion}). Export to JSON for backups.</p>
    </div>
  );
}

export const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'project';
