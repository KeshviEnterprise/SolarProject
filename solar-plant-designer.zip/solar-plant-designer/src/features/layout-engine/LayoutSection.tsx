import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { KV, HowCalculated, Notice, fmt, Tag } from '@/components/ui';
import { autoLayoutNow, generateOptionsAction, applyOption } from '@/services/actions';
import { formatArea } from '@/calculations/units';
import { formatEnergyKwh } from '@/calculations/units';

export function LayoutSection() {
  const { project: p, stats, areas, invalidPanels } = useDerived();
  const options = useStore((s) => s.layoutOptions);
  const status = useStore((s) => s.optionsStatus);
  const tool = useStore((s) => s.tool);
  const sel = useStore((s) => s.selection);
  const { set, update } = useStore.getState();
  const u = p.settings.displayUnit;
  const selectedPanels = sel.kind === 'panel' ? sel.ids.length : 0;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" data-testid="generate-auto-layout" disabled={status === 'running' || !areas.valid} onClick={() => void generateOptionsAction()}>
          {status === 'running' ? 'Evaluating configurations…' : 'Generate auto layout'}
        </button>
        <button className="btn btn-secondary" data-testid="fill-current" disabled={!areas.valid} onClick={() => autoLayoutNow('Current mounting settings')}>Fill with current settings</button>
      </div>
      {!p.solarResource && <p className="text-[11.5px] text-char-700">Estimated generation per configuration appears once solar data is loaded (Energy analysis).</p>}
      {options && (
        <div className="overflow-x-auto rounded-[3px] border border-rule bg-white" data-testid="layout-options">
          <table className="table-eng">
            <thead>
              <tr><th>Configuration</th><th className="num">Panels</th><th className="num">DC kWp</th><th className="num">Pitch m</th><th className="num">Utilisation</th><th className="num">Shading</th><th className="num">Est. kWh/yr</th><th className="num">kWh/kWp</th><th className="num">Free area</th><th /></tr>
            </thead>
            <tbody>
              {options.map((o) => (
                <tr key={o.id} className={p.layout.configLabel === o.label ? 'bg-pv-100/50' : ''}>
                  <td title={o.spacingNote}>{o.label}</td>
                  <td className="num">{o.panelCount}</td>
                  <td className="num">{fmt(o.dcKwp, 2)}</td>
                  <td className="num">{o.pitchM !== null ? fmt(o.pitchM, 2) : '—'}</td>
                  <td className="num">{fmt(o.utilizationPct, 1)} %</td>
                  <td className="num">{o.shadingLossPct !== null ? `${fmt(o.shadingLossPct, 1)} %` : '—'}</td>
                  <td className="num">{o.annualKwh !== null ? fmt(o.annualKwh, 0) : '—'}</td>
                  <td className="num">{o.specificYield !== null ? fmt(o.specificYield, 0) : '—'}</td>
                  <td className="num">{formatArea(o.maintenanceAreaM2, u)}</td>
                  <td><button className="btn btn-dark px-2 py-0.5 text-[12px]" data-testid={`apply-${o.id}`} onClick={() => applyOption(o)}>Apply</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="px-2 py-1.5 text-[11.5px] text-char-700">
            No configuration is ranked "best": more panels raise output but also row shading and reduce maintenance space. Generation and shading are modelled with the loaded solar data {p.solarResource?.isDemo && <Tag kind="demo" />}.
          </p>
        </div>
      )}

      <h3 className="subhead">Manual design</h3>
      <div className="flex flex-wrap gap-1.5" role="toolbar" aria-label="Manual panel tools">
        <button className={`btn ${tool === 'select' ? 'bg-navy-800 text-white' : 'btn-secondary'}`} aria-pressed={tool === 'select'} onClick={() => set({ tool: 'select' })}>Select / move</button>
        <button className={`btn ${tool === 'add-panel' ? 'bg-navy-800 text-white' : 'btn-secondary'}`} aria-pressed={tool === 'add-panel'} data-testid="tool-add-panel" onClick={() => set({ tool: 'add-panel' })}>Add panel</button>
        <button className="btn btn-secondary" onClick={() => set({ selection: { kind: 'panel', ids: p.layout.panels.map((x) => x.id) }, tool: 'select' })}>Select all</button>
        <button className="btn btn-danger" disabled={!p.layout.panels.length} onClick={() => { if (window.confirm('Remove all panels?')) update((q) => ({ ...q, layout: { ...q.layout, panels: [], configLabel: '' }, analysis: null })); }}>Clear panels</button>
      </div>
      <p className="text-[12px] text-char-700">
        Shift-click or drag a box to select several panels; drag to move the group; arrow keys nudge 0.1 m (Shift: 1 m); Delete removes; Ctrl/Cmd+D duplicates. Selected: {selectedPanels}. Row, lock and rotate actions are in the properties panel.
      </p>

      <h3 className="subhead">Live layout figures</h3>
      <KV label="Panel count" value={<span data-testid="panel-count">{stats.panelCount}</span>} tag="calculated" />
      <KV label="Installed DC capacity" value={<span data-testid="dc-capacity">{fmt(stats.dcKwp, 2)} kWp</span>} tag="calculated">
        <HowCalculated formula="P_DC = N × P_module" lines={[{ label: 'N', value: String(stats.panelCount) }, { label: 'P_module', value: `${p.panel.powerW} W` }]} result={`${fmt(stats.dcKwp, 2)} kWp`} />
      </KV>
      <KV label="Rows / max panels per row" value={`${stats.rows} / ${stats.maxPerRow}`} tag="calculated" />
      <KV label="Module area" value={formatArea(stats.moduleAreaM2, u)} tag="calculated" />
      <KV label="Area occupied (plan footprint)" value={formatArea(stats.footprintAreaM2, u)} tag="calculated" />
      <KV label="Roof utilisation" value={`${fmt(stats.utilizationPct, 1)} %`} tag="calculated">
        <HowCalculated formula="Utilisation = Σ module plan footprint / roof plan area" lines={[{ label: 'Footprint', value: formatArea(stats.footprintAreaM2, u) }, { label: 'Roof plan area', value: formatArea(areas.roofPlanAreaM2, u) }, { label: 'Of usable area', value: `${fmt(stats.usableUtilizationPct, 1)} %` }]} result={`${fmt(stats.utilizationPct, 1)} %`} />
      </KV>
      <KV label="Remaining usable area" value={formatArea(stats.remainingAreaM2, u)} tag="calculated" />
      {p.layout.configLabel && <KV label="Configuration" value={p.layout.configLabel} />}
      {p.analysis && <KV label="Last analysis" value={formatEnergyKwh(p.analysis.annualAcKwh) + '/yr'} tag={p.analysis.isDemoData ? 'demo' : 'calculated'} />}
      {invalidPanels.size > 0 && <Notice tone="warning">{invalidPanels.size} panel(s) are outside the boundary or overlap a keep-out (outlined red on the plan).</Notice>}
    </div>
  );
}
