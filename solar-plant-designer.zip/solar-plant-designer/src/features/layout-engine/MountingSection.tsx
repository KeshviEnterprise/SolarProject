import { useState } from 'react';
import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { NumberField, SelectField, KV, HowCalculated, Notice, Grid2, fmt, Tag } from '@/components/ui';
import { calculateRowSpacing, suggestTiltFromLatitude, equatorFacingAzimuth, orientedDims, moduleDims } from '@/calculations/panelLayout';
import { optimiseTiltAsync } from '@/services/workerClient';
import { compass } from '@/calculations/structure';
import { MONTH_SHORT } from '@/calculations/solarPosition';
import type { Mounting, MountingType, PanelOrientation, RowSpacingMode } from '@/types';

export function MountingSection() {
  const { project: p, surfaces, mounts } = useDerived();
  const { update, notify } = useStore.getState();
  const m = p.mounting;
  const set = (patch: Partial<Mounting>) => update((q) => ({ ...q, mounting: { ...q.mounting, ...patch }, analysis: null }));
  const [opt, setOpt] = useState<{ tiltDeg: number; poaKwhM2: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const lat = p.location.latitude;
  const latTilt = suggestTiltFromLatitude(lat);
  const racked = surfaces.some((s) => mounts[s.id]?.racked);
  const flatLike = p.structure.roofType === 'flat' || p.structure.roofType === 'ground';
  const k = Math.max(1, Math.round(m.modulesHigh));
  const od = orientedDims(moduleDims(p.panel), m.orientation);
  const slant = k * od.slant + (k - 1) * m.moduleGapM;
  const rs = calculateRowSpacing({ latitudeDeg: lat, tiltDeg: m.tiltDeg, slantM: slant, azimuthDeg: m.azimuthDeg, terrainSlopeDeg: p.structure.roofType === 'ground' ? p.structure.terrainSlopeDeg : 0, startHour: m.shadeFreeStartHour, endHour: m.shadeFreeEndHour });

  return (
    <div className="space-y-3">
      <Grid2>
        <SelectField<MountingType> label="Mounting type" value={m.type} testId="mounting-type" options={[{ value: 'fixed-tilt', label: 'Fixed tilt (racked)' }, { value: 'roof-following', label: 'Roof-following (flush)' }, { value: 'adjustable-tilt', label: 'Adjustable (seasonal) tilt' }]} onChange={(v) => set({ type: v, seasonalTiltsDeg: v === 'adjustable-tilt' ? m.seasonalTiltsDeg ?? defaultSeasonal(lat) : m.seasonalTiltsDeg })} />
        <SelectField<PanelOrientation> label="Panel orientation" value={m.orientation} testId="orientation" options={[{ value: 'portrait', label: 'Portrait' }, { value: 'landscape', label: 'Landscape' }]} onChange={(v) => set({ orientation: v })} />
      </Grid2>
      {!flatLike && <Notice tone="info">Sloped roofs and canopies use roof-following mounting: tilt = roof slope ({p.structure.slopeDeg}°), azimuth = plane azimuth. Tilt and azimuth fields below apply to flat roofs and ground mounts.</Notice>}
      <Grid2>
        <NumberField label="Tilt" unit="°" value={m.tiltDeg} min={0} max={75} testId="tilt" tag="user" onCommit={(v) => v !== null && set({ tiltDeg: v })} disabled={!flatLike || m.type === 'roof-following'} />
        <NumberField label="Azimuth" unit="°" value={m.azimuthDeg} min={0} max={360} testId="azimuth" tag="user" onCommit={(v) => v !== null && set({ azimuthDeg: v % 360 })} hint={`${compass(m.azimuthDeg)} · custom orientation allowed`} disabled={!flatLike} />
        <NumberField label="Modules per table (up-slope)" value={m.modulesHigh} min={1} max={4} onCommit={(v) => v !== null && set({ modulesHigh: Math.round(v) })} />
        <NumberField label="Module gap" kind="length" displayUnit="mm" value={m.moduleGapM} min={0} max={1} onCommit={(v) => v !== null && set({ moduleGapM: v })} />
        <NumberField label="Lowest-edge clearance" kind="length" displayUnit={p.settings.displayUnit} value={m.clearanceM} min={0} max={5} onCommit={(v) => v !== null && set({ clearanceM: v })} />
      </Grid2>

      <h3 className="subhead">Initial tilt/azimuth suggestion <Tag kind="estimated" /></h3>
      <KV label="Equator-facing azimuth" value={`${equatorFacingAzimuth(lat)}° (${compass(equatorFacingAzimuth(lat))})`} tag="calculated" />
      <KV label="Latitude-based tilt" value={`${fmt(latTilt, 1)}°`} tag="estimated">
        <HowCalculated formula="β = 1.3793 + φ(1.2011 + φ(−0.014404 + 0.000080509 φ))   (N. hemisphere)" lines={[{ label: 'Latitude φ', value: `${lat.toFixed(3)}°` }]} result={`${fmt(latTilt, 1)}°`} note="Polynomial fit of optimal fixed tilt vs latitude from Jacobson & Jadhav (2018), Solar Energy 169. An initial design assumption only." />
      </KV>
      <KV label="POA-optimised tilt (energy model)" value={opt ? `${opt.tiltDeg}° · ${fmt(opt.poaKwhM2, 0)} kWh/m²/yr` : p.solarResource ? 'Not computed' : 'Needs solar data'} tag={opt ? (p.solarResource?.isDemo ? 'demo' : 'calculated') : undefined} />
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" disabled={!flatLike} onClick={() => set({ tiltDeg: Math.round(latTilt), azimuthDeg: equatorFacingAzimuth(lat) })}>Use latitude-based suggestion</button>
        <button className="btn btn-secondary" disabled={!p.solarResource || busy} onClick={async () => { setBusy(true); try { const r = await optimiseTiltAsync(p); setOpt(r); } catch { notify('Tilt optimisation failed', 'error'); } setBusy(false); }}>{busy ? 'Optimising…' : 'Optimise tilt with solar data'}</button>
        {opt && flatLike && <button className="btn btn-secondary" onClick={() => set({ tiltDeg: opt.tiltDeg, azimuthDeg: equatorFacingAzimuth(lat) })}>Apply {opt.tiltDeg}°</button>}
      </div>
      <p className="text-[11.5px] text-char-700">The optimised tilt maximises unshaded plane-of-array irradiation only; row spacing, wind load and land use may favour lower tilts.</p>

      {racked && (<>
        <h3 className="subhead">Row spacing</h3>
        <SelectField<RowSpacingMode> label="Spacing method" value={m.rowSpacingMode} options={[{ value: 'shade-free', label: 'Shade-free window on winter solstice' }, { value: 'gcr', label: 'Ground coverage ratio (GCR)' }, { value: 'manual', label: 'Manual pitch' }]} onChange={(v) => set({ rowSpacingMode: v })} />
        {m.rowSpacingMode === 'shade-free' && <Grid2>
          <NumberField label="Shade-free from (solar time)" unit="h" value={m.shadeFreeStartHour} min={6} max={12} onCommit={(v) => v !== null && set({ shadeFreeStartHour: v })} />
          <NumberField label="Shade-free until (solar time)" unit="h" value={m.shadeFreeEndHour} min={12} max={18} onCommit={(v) => v !== null && set({ shadeFreeEndHour: v })} />
        </Grid2>}
        {m.rowSpacingMode === 'gcr' && <NumberField label="Ground coverage ratio" value={m.gcr} min={0.1} max={1} onCommit={(v) => v !== null && set({ gcr: v })} />}
        {m.rowSpacingMode === 'manual' && <NumberField label="Row pitch (plan)" kind="length" displayUnit={p.settings.displayUnit} value={m.manualPitchM} min={0.3} max={50} onCommit={(v) => v !== null && set({ manualPitchM: v })} />}
        <KV label="Shade-free pitch (plan)" value={`${fmt(rs.pitchPlanM, 2)} m`} tag="calculated">
          <HowCalculated formula={'tan αp = tan(elev) / cos(sun az − array az)\npitch = L·[cos β + sin β / tan αp]   (maximum over window)'}
            lines={[{ label: 'Table slant length L', value: `${fmt(slant, 3)} m (${k} × ${m.orientation})` }, { label: 'Tilt β', value: `${m.tiltDeg}°` }, { label: 'Design day', value: `Winter solstice (day ${rs.designDoy})` }, { label: 'Window', value: `${m.shadeFreeStartHour}:00-${m.shadeFreeEndHour}:00 solar time` }, { label: 'Critical time', value: rs.criticalSolarHour !== null ? `${rs.criticalSolarHour.toFixed(2)} h, elev ${fmt(rs.criticalElevationDeg, 1)}°, az ${fmt(rs.criticalAzimuthDeg, 1)}°` : '—' }]}
            result={`${fmt(rs.pitchPlanM, 2)} m · gap ${fmt(rs.gapPlanM, 2)} m · GCR ${fmt(rs.gcr, 2)}`} />
        </KV>
        {rs.lowSun && <Notice tone="warning">The sun is below 2° during part of the shade-free window at this latitude; those times were ignored.</Notice>}
        <Grid2>
          <NumberField label="Walkway every N rows (0 = none)" value={m.walkwayEveryRows} min={0} max={100} onCommit={(v) => v !== null && set({ walkwayEveryRows: Math.round(v) })} />
          <NumberField label="Walkway width" kind="length" displayUnit={p.settings.displayUnit} value={m.walkwayWidthM} min={0} max={10} onCommit={(v) => v !== null && set({ walkwayWidthM: v })} />
        </Grid2>
      </>)}

      {m.type === 'adjustable-tilt' && flatLike && (<>
        <h3 className="subhead">Seasonal tilt schedule</h3>
        <div className="grid grid-cols-4 gap-2">
          {(m.seasonalTiltsDeg ?? defaultSeasonal(lat)).map((t, i) => (
            <NumberField key={i} label={MONTH_SHORT[i]} unit="°" value={t} min={0} max={75} onCommit={(v) => v !== null && set({ seasonalTiltsDeg: (m.seasonalTiltsDeg ?? defaultSeasonal(lat)).map((x, j) => (j === i ? v : x)) })} />
          ))}
        </div>
        <p className="text-[11.5px] text-char-700">Row spacing uses the fixed tilt above; set it to the steepest tilt used in winter.</p>
      </>)}
    </div>
  );
}

/** Starting schedule: latitude ± 15° between winter and summer (assumption, editable). */
function defaultSeasonal(lat: number): number[] {
  const a = Math.abs(lat);
  return Array.from({ length: 12 }, (_, i) => {
    const winter = lat >= 0 ? [0, 1, 9, 10, 11].includes(i) : [4, 5, 6, 7].includes(i);
    const summer = lat >= 0 ? [4, 5, 6, 7].includes(i) : [0, 1, 10, 11].includes(i);
    return Math.max(0, Math.round(winter ? a + 15 : summer ? a - 15 : a));
  });
}
