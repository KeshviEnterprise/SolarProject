import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { STRUCTURE_TYPES, STRUCTURE_BY_ID, ROOF_TYPE_LABELS, MATERIAL_LABELS } from '@/data/structureTypes';
import { NumberField, SelectField, KV, HowCalculated, Notice, fmt, Grid2 } from '@/components/ui';
import { applyStructureType } from '@/utils/projectFactory';
import { rectangleBoundary, compass } from '@/calculations/structure';
import { formatArea, formatLength } from '@/calculations/units';
import type { Structure, RoofType, RoofMaterial, RoofCondition, StructureTypeId } from '@/types';

export function StructureSection() {
  const { project: p, areas, surfaces, ridge, weightKg, stats } = useDerived();
  const { update } = useStore.getState();
  const st = p.structure;
  const u = p.settings.displayUnit;
  const set = (patch: Partial<Structure>, clearLayout = false) => update((q) => ({ ...q, structure: { ...q.structure, ...patch }, analysis: null, ...(clearLayout ? { layout: { ...q.layout, panels: q.layout.panels } } : {}) }));
  const groups = [...new Set(STRUCTURE_TYPES.map((s) => s.group))];
  const sloped = st.roofType === 'shed' || st.roofType === 'gable' || st.roofType === 'canopy';
  const pitchRatio = Math.tan((st.slopeDeg * Math.PI) / 180) * 12;

  return (
    <div className="space-y-3">
      <div>
        <label htmlFor="stype" className="label">Structure type</label>
        <select id="stype" data-testid="structure-type" className="input" value={st.type}
          onChange={(e) => {
            const id = e.target.value as StructureTypeId;
            if (p.layout.panels.length && !window.confirm('Changing the structure type resets the roof geometry and removes the current layout. Continue?')) return;
            update((q) => applyStructureType(q, id));
          }}>
          {groups.map((g) => (
            <optgroup key={g} label={g}>
              {STRUCTURE_TYPES.filter((s) => s.group === g).map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </optgroup>
          ))}
        </select>
        <p className="mt-1 text-[11.5px] text-char-700">{STRUCTURE_BY_ID[st.type].note} Defaults are starting assumptions - replace with measured values.</p>
      </div>
      <Grid2>
        <SelectField<RoofType> label="Roof / surface geometry" value={st.roofType} options={Object.entries(ROOF_TYPE_LABELS).map(([value, label]) => ({ value: value as RoofType, label }))} onChange={(v) => set({ roofType: v, eaveHeightM: v === 'ground' ? 0 : st.eaveHeightM || 6, slopeDeg: v === 'flat' || v === 'ground' ? 0 : st.slopeDeg || 10 })} />
        <SelectField<RoofMaterial> label="Roof material" value={st.material} options={Object.entries(MATERIAL_LABELS).map(([value, label]) => ({ value: value as RoofMaterial, label }))} onChange={(v) => set({ material: v })} />
      </Grid2>

      <h3 className="subhead">Dimensions</h3>
      <Grid2>
        <NumberField label="Length (east-west)" kind="length" displayUnit={u} value={st.lengthM} min={0.5} max={5000} testId="dim-length" tag="user" onCommit={(v) => v !== null && set({ lengthM: v })} />
        <NumberField label="Width (north-south)" kind="length" displayUnit={u} value={st.widthM} min={0.5} max={5000} testId="dim-width" tag="user" onCommit={(v) => v !== null && set({ widthM: v })} />
      </Grid2>
      <button className="btn btn-secondary w-full" data-testid="apply-rectangle" onClick={() => set({ boundary: rectangleBoundary(st.lengthM, st.widthM) })}>
        Set boundary to {formatLength(st.lengthM, u)} × {formatLength(st.widthM, u)} rectangle
      </button>
      <p className="text-[11.5px] text-char-700">For irregular shapes draw the boundary in the Roof editor; the rectangle fields are then only a helper.</p>
      <Grid2>
        {st.roofType !== 'ground' && <NumberField label={st.roofType === 'canopy' ? 'Canopy low-edge height' : 'Eave / roof height'} kind="length" displayUnit={u} value={st.eaveHeightM} min={0} max={500} tag="user" onCommit={(v) => v !== null && set({ eaveHeightM: v })} />}
        {sloped && <NumberField label="Roof slope" unit="°" value={st.slopeDeg} min={0} max={75} tag="user" onCommit={(v) => v !== null && set({ slopeDeg: v })} hint={`Pitch ≈ ${pitchRatio.toFixed(1)}:12 · ${(Math.tan((st.slopeDeg * Math.PI) / 180) * 100).toFixed(1)} %`} />}
        {sloped && <NumberField label={st.roofType === 'gable' ? 'Azimuth of primary plane' : 'Roof azimuth (downslope)'} unit="°" value={st.roofAzimuthDeg} min={0} max={360} tag="user" onCommit={(v) => v !== null && set({ roofAzimuthDeg: v % 360 })} hint={`${compass(st.roofAzimuthDeg)} · 180° = south`} />}
        {st.roofType === 'ground' && <NumberField label="Terrain slope toward array" unit="°" value={st.terrainSlopeDeg} min={0} max={30} tag="user" onCommit={(v) => v !== null && set({ terrainSlopeDeg: v })} hint="Ground falling toward the array azimuth" />}
        {st.roofType !== 'ground' && st.roofType !== 'canopy' && <NumberField label="Parapet height" kind="length" displayUnit={u} value={st.parapetHeightM} min={0} max={5} tag="user" onCommit={(v) => v !== null && set({ parapetHeightM: v })} />}
        <NumberField label={st.roofType === 'ground' ? 'Boundary setback' : 'Edge setback'} kind="length" displayUnit={u} value={st.setbackM} min={0} max={50} tag="user" onCommit={(v) => v !== null && set({ setbackM: v })} hint="Clear strip kept free of panels" />
      </Grid2>

      <h3 className="subhead">Derived geometry</h3>
      {!areas.valid && <Notice tone="error">The boundary polygon is invalid (self-intersecting or fewer than 3 points).</Notice>}
      <KV label="Roof / land plan area" value={formatArea(areas.roofPlanAreaM2, u)} tag="calculated">
        <HowCalculated formula="A = ½ |Σ (xᵢ·yᵢ₊₁ − xᵢ₊₁·yᵢ)|  (shoelace formula)" lines={[{ label: 'Boundary vertices', value: String(st.boundary.length) }, { label: 'Perimeter', value: formatLength(areas.perimeterM, u) }]} result={formatArea(areas.roofPlanAreaM2, u)} />
      </KV>
      {sloped && <KV label="Actual sloped roof area" value={formatArea(areas.roofSurfaceAreaM2, u)} tag="calculated">
        <HowCalculated formula="A_surface = A_plan / cos(slope)" lines={[{ label: 'Plan area', value: formatArea(areas.roofPlanAreaM2, u) }, { label: 'Slope', value: `${st.slopeDeg}°` }]} result={formatArea(areas.roofSurfaceAreaM2, u)} />
      </KV>}
      {sloped && <KV label={st.roofType === 'gable' ? 'Ridge height' : 'High-edge height'} value={formatLength(ridge, u)} tag="calculated" />}
      <KV label="Setback strip area" value={formatArea(areas.setbackAreaM2, u)} tag="calculated" />
      <KV label="Obstacle keep-out area" value={formatArea(areas.keepoutAreaM2, u)} tag="calculated" />
      <KV label="Usable installation area" value={formatArea(areas.usableAreaM2, u)} tag="calculated">
        <HowCalculated formula="Usable = plan area − setback strip − obstacle keep-outs (obstacle + buffer)" lines={[{ label: 'Plan area', value: formatArea(areas.roofPlanAreaM2, u) }, { label: 'Setback strip', value: formatArea(areas.setbackAreaM2, u) }, { label: 'Keep-outs', value: formatArea(areas.keepoutAreaM2, u) }]} result={formatArea(areas.usableAreaM2, u)} note="Evaluated numerically on a fine grid (up to 160 000 samples)." />
      </KV>
      <KV label="Installation surfaces" value={surfaces.map((s) => `${s.name} (${s.slopeDeg}°, ${compass(s.azimuthDeg)})`).join('; ') || '—'} tag="calculated" />

      {st.roofType !== 'ground' && (<>
        <h3 className="subhead">Structural information</h3>
        <Grid2>
          <NumberField label="Roof age" unit="years" value={st.roofAgeYears} allowEmpty min={0} max={200} onCommit={(v) => set({ roofAgeYears: v })} />
          <SelectField<RoofCondition> label="Roof condition" value={st.condition} options={[{ value: 'unknown', label: 'Unknown' }, { value: 'good', label: 'Good' }, { value: 'fair', label: 'Fair' }, { value: 'poor', label: 'Poor' }]} onChange={(v) => set({ condition: v })} />
          <NumberField label="Permissible added load" unit="kg/m²" value={st.structuralCapacityKgM2} allowEmpty min={0} max={2000} onCommit={(v) => set({ structuralCapacityKgM2: v })} hint="From a structural engineer; leave empty if unknown" />
        </Grid2>
        <KV label="Estimated system weight" value={`${fmt(weightKg / 1000, 2)} t`} tag="estimated">
          <HowCalculated formula="W = N × module mass + module area × mounting mass per m²" lines={[{ label: 'Modules N', value: String(stats.panelCount) }, { label: 'Module mass', value: `${p.panel.weightKg} kg` }, { label: 'Mounting allowance', value: `${p.mounting.type === 'roof-following' ? 4 : p.mounting.type === 'adjustable-tilt' ? 10 : 8} kg/m² (assumption)` }]} result={`${fmt(weightKg, 0)} kg`} />
        </KV>
        {stats.moduleAreaM2 > 0 && <KV label="Average array load" value={`${fmt(weightKg / stats.moduleAreaM2, 1)} kg/m²`} tag="estimated" />}
        {st.structuralCapacityKgM2 === null ? <Notice tone="warning">Structural suitability has not been verified.</Notice>
          : <Notice tone="info">A capacity figure has been entered. This tool compares loads only; it does not certify that the roof is structurally safe.</Notice>}
      </>)}
    </div>
  );
}
