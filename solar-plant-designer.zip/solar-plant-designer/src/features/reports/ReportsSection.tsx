import { useState } from 'react';
import { useStore } from '@/store/projectStore';
import { downloadBlob, monthlyCsv, panelsCsv, planPng } from '@/services/exportService';
import { slug } from '@/features/project/ProjectSection';
import { Notice } from '@/components/ui';
import { ENGINEERING_DISCLAIMER } from '@/utils/disclaimers';

export function ReportsSection() {
  const p = useStore((s) => s.project);
  const { notify } = useStore.getState();
  const [busy, setBusy] = useState<string | null>(null);
  const name = slug(p.name);
  const run = async (key: string, fn: () => Promise<void> | void) => {
    setBusy(key);
    try { await fn(); } catch (e) { notify(e instanceof Error ? e.message : 'Export failed', 'error'); }
    setBusy(null);
  };

  return (
    <div className="space-y-3">
      {!p.analysis && <Notice tone="info">The report can be generated now, but energy sections stay empty until the analysis has been run.</Notice>}
      {p.analysis?.isDemoData && <Notice tone="demo">Results use DEMO solar data; exports are watermarked and labelled accordingly.</Notice>}
      <button className="btn btn-primary w-full" data-testid="export-pdf" disabled={!!busy} onClick={() => run('pdf', async () => {
        const { generateReportPdf } = await import('@/services/reportPdf');
        downloadBlob(await generateReportPdf(p), `${name}-report.pdf`);
      })}>{busy === 'pdf' ? 'Building PDF…' : 'Download PDF report'}</button>
      <div className="grid grid-cols-2 gap-2">
        <button className="btn btn-secondary" disabled={!!busy} onClick={() => run('png', async () => { const b = await planPng(p); if (!b) throw new Error('PNG rendering failed in this browser'); downloadBlob(b, `${name}-plan.png`); })}>Plan drawing (PNG)</button>
        <button className="btn btn-secondary" disabled={!!busy || !p.analysis} data-testid="export-csv" onClick={() => run('csv', () => downloadBlob(new Blob([monthlyCsv(p)], { type: 'text/csv' }), `${name}-monthly.csv`))}>Monthly results (CSV)</button>
        <button className="btn btn-secondary" disabled={!!busy || !p.layout.panels.length} onClick={() => run('pcsv', () => downloadBlob(new Blob([panelsCsv(p)], { type: 'text/csv' }), `${name}-panels.csv`))}>Panel coordinates (CSV)</button>
        <button className="btn btn-secondary" disabled={!!busy} data-testid="export-json" onClick={() => run('json', () => downloadBlob(new Blob([JSON.stringify(p, null, 2)], { type: 'application/json' }), `${name}.spd.json`))}>Project data (JSON)</button>
      </div>
      <p className="text-[12px] text-char-700">Each chart in the energy results also has its own CSV and PNG export. The PDF contains project and location details, structure, roof diagram, layout, panel and inverter data, irradiation, monthly and annual results, losses, a sunlight table, assumptions, warnings and the disclaimer.</p>
      <h3 className="subhead">Disclaimer</h3>
      <p className="text-[12px] leading-relaxed text-char-800">{ENGINEERING_DISCLAIMER}</p>
    </div>
  );
}
