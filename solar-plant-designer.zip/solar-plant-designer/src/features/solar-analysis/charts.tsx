import { useRef, type ReactNode } from 'react';
import { downloadBlob } from '@/services/exportService';

/** Card wrapping a chart with CSV and PNG export. */
export function ChartCard({ title, unit, children, csv, testId, note }: { title: string; unit: string; children: ReactNode; csv: () => string; testId?: string; note?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const png = async () => {
    const svg = ref.current?.querySelector('svg.recharts-surface') as SVGSVGElement | null;
    if (!svg) return;
    const blob = await svgToPng(svg, 2);
    if (blob) downloadBlob(blob, `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`);
  };
  return (
    <section className="flex min-w-0 flex-col rounded-[3px] border border-rule bg-white" data-testid={testId} aria-label={title}>
      <header className="flex items-center justify-between border-b border-rule px-3 py-1.5">
        <h3 className="font-cond text-[14px] font-semibold text-navy-900">{title} <span className="font-sans text-[11.5px] font-normal text-char-700">({unit})</span></h3>
        <div className="flex gap-1">
          <button className="btn btn-ghost px-1.5 py-0.5 text-[11px]" onClick={() => downloadBlob(new Blob([csv()], { type: 'text/csv' }), `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.csv`)}>CSV</button>
          <button className="btn btn-ghost px-1.5 py-0.5 text-[11px]" onClick={() => void png()}>PNG</button>
        </div>
      </header>
      <div ref={ref} className="h-60 px-1 pt-2">{children}</div>
      {note && <p className="px-3 pb-2 text-[11px] text-char-700">{note}</p>}
    </section>
  );
}

export async function svgToPng(svg: SVGSVGElement, scale = 2): Promise<Blob | null> {
  const clone = svg.cloneNode(true) as SVGSVGElement;
  const w = svg.clientWidth || Number(svg.getAttribute('width')) || 800;
  const h = svg.clientHeight || Number(svg.getAttribute('height')) || 400;
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('width', String(w));
  clone.setAttribute('height', String(h));
  const src = new XMLSerializer().serializeToString(clone);
  return svgStringToPng(src, w, h, scale);
}

export function svgStringToPng(src: string, w: number, h: number, scale = 2): Promise<Blob | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = w * scale; c.height = h * scale;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0, c.width, c.height);
      c.toBlob((b) => resolve(b), 'image/png');
    };
    img.onerror = () => resolve(null);
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(src);
  });
}

export const toCsv = (header: string[], rows: (string | number)[][]) => [header, ...rows].map((r) => r.map((c) => (typeof c === 'string' && /[",\n]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c)).join(',')).join('\n');
