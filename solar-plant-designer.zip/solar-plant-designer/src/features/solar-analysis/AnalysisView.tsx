import { useMemo, useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid, Cell, ComposedChart, Area } from 'recharts';
import { useStore } from '@/store/projectStore';
import { MONTH_SHORT, MONTH_NAMES, DAYS_IN_MONTH } from '@/calculations/solarPosition';
import { formatEnergyKwh } from '@/calculations/units';
import { HowCalculated, Tag, Notice, fmt } from '@/components/ui';
import { ChartCard, toCsv } from './charts';
import { runAnalysisAction, isAnalysisStale } from '@/services/actions';
import type { AnalysisResult } from '@/types';

const AX = { fontSize: 10.5 };

export function AnalysisView() {
  const p = useStore((s) => s.project);
  const status = useStore((s) => s.analysisStatus);
  const a = p.analysis;
  if (!a) {
    return (
      <div className="flex h-full items-center justify-center bg-paper p-6">
        <div className="max-w-md space-y-3 text-center">
          <h2 className="panel-title">No energy results yet</h2>
          <p className="text-[13px] text-char-700">Generate a layout, load solar resource data and run the analysis. Results come from the documented model using real provider data - nothing is pre-filled.</p>
          <button className="btn btn-primary" disabled={status === 'running'} onClick={() => void runAnalysisAction()}>{status === 'running' ? 'Running…' : 'Run analysis'}</button>
        </div>
      </div>
    );
  }
  return <Results a={a} />;
}

function Results({ a }: { a: AnalysisResult }) {
  const p = useStore((s) => s.project);
  const [hm, setHm] = useState(new Date().getMonth());
  const src = a.isDemoData ? 'demo' : 'calculated';
  const stale = isAnalysisStale();
  const monthly = useMemo(() => a.months.map((m, i) => ({
    month: MONTH_SHORT[i], ghi: +m.ghiKwhM2.toFixed(1), poa: +m.poaKwhM2.toFixed(1), energy: Math.round(m.acKwh), psh: +m.peakSunHours.toFixed(2),
    pr: +(m.performanceRatio * 100).toFixed(1), beam: +(m.ghiKwhM2 * m.beamFraction).toFixed(1), diffuse: +(m.ghiKwhM2 * (1 - m.beamFraction)).toFixed(1),
    tMean: +m.tMeanC.toFixed(1), tMax: p.solarResource?.monthly[i].tMaxC ?? null, tMin: p.solarResource?.monthly[i].tMinC ?? null,
  })), [a, p.solarResource]);
  const daily = useMemo(() => { let c = 0; return a.daily.map((d, i) => { c += d; return { day: i + 1, kwh: +d.toFixed(1), cum: Math.round(c) }; }); }, [a]);
  const seasons = useMemo(() => {
    const north = p.location.latitude >= 0;
    const defs = north ? [['Winter (DJF)', [11, 0, 1]], ['Spring (MAM)', [2, 3, 4]], ['Summer (JJA)', [5, 6, 7]], ['Autumn (SON)', [8, 9, 10]]] : [['Summer (DJF)', [11, 0, 1]], ['Autumn (MAM)', [2, 3, 4]], ['Winter (JJA)', [5, 6, 7]], ['Spring (SON)', [8, 9, 10]]];
    return (defs as [string, number[]][]).map(([name, ms]) => ({ season: name, energy: Math.round(ms.reduce((s, m) => s + a.months[m].acKwh, 0)) }));
  }, [a, p.location.latitude]);
  const waterfall = useMemo(() => {
    const nom = a.lossStages[0].energyAfterKwh;
    const rows = [{ name: 'Nominal', base: 0, value: Math.round(nom), kind: 'total' }];
    for (const s of a.lossStages.slice(1)) rows.push({ name: s.label.replace(/ \(.*\)/, ''), base: Math.round(s.energyAfterKwh), value: Math.round(s.lossKwh), kind: 'loss' });
    rows.push({ name: 'Net AC', base: 0, value: Math.round(a.annualAcKwh), kind: 'total' });
    return rows;
  }, [a]);
  const hourly = a.months[hm].hourly.map((h) => ({ hour: h.hour, poa: Math.round(h.poaW), ac: +h.acKw.toFixed(2), tc: +h.cellTempC.toFixed(1), shaded: +(h.shadedFraction * 100).toFixed(1) }));
  const nominal = a.lossStages[0].energyAfterKwh;

  return (
    <div className="h-full overflow-auto bg-paper" data-testid="analysis-view">
      <div className="mx-auto max-w-[1400px] space-y-4 p-4">
        {a.isDemoData && <Notice tone="demo"><strong>DEMO / ESTIMATED results.</strong> Computed from synthetic demo solar data, not measured or satellite data. Do not use for decisions.</Notice>}
        {stale && <Notice tone="warning">The design has changed since these results were computed ({new Date(a.computedAt).toLocaleString()}). <button className="underline" onClick={() => void runAnalysisAction()}>Re-run analysis</button></Notice>}
        {a.warnings.filter((w) => !w.startsWith('DEMO')).map((w) => <Notice key={w} tone="warning">{w}</Notice>)}

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Kpi label="Annual generation" value={formatEnergyKwh(a.annualAcKwh)} unit="per year" tag={src} testId="kpi-annual">
            <HowCalculated formula={'E = Σ_months Σ_steps kWp × POA_eff/1000 × f_temp × η_sys × Δt × days'} lines={[
              { label: 'Installed DC capacity', value: `${fmt(a.dcKwp, 2)} kWp` },
              { label: 'Plane-of-array irradiation', value: `${fmt(a.annualPoaKwhM2, 0)} kWh/m²` },
              { label: 'Nominal (kWp × POA)', value: formatEnergyKwh(nominal) },
              ...a.lossStages.slice(1).map((s) => ({ label: `× ${s.label}`, value: `${fmt(100 - s.lossPct, 2)} %` })),
            ]} result={formatEnergyKwh(a.annualAcKwh)} note={`Solar data: ${a.providerLabel}. Stage factors are annual energy-weighted results of the hour-by-hour model.`} />
          </Kpi>
          <Kpi label="Specific yield" value={`${fmt(a.specificYield, 0)}`} unit="kWh/kWp/yr" tag={src}>
            <HowCalculated formula="SY = E_annual / P_DC" lines={[{ label: 'E_annual', value: formatEnergyKwh(a.annualAcKwh) }, { label: 'P_DC', value: `${fmt(a.dcKwp, 2)} kWp` }]} result={`${fmt(a.specificYield, 1)} kWh/kWp`} />
          </Kpi>
          <Kpi label="Performance ratio" value={`${fmt(a.performanceRatio * 100, 1)} %`} unit="IEC 61724 basis" tag={src}>
            <HowCalculated formula="PR = E_annual / (P_DC × H_POA / 1 kW/m²)" lines={[{ label: 'E_annual', value: formatEnergyKwh(a.annualAcKwh) }, { label: 'P_DC', value: `${fmt(a.dcKwp, 2)} kWp` }, { label: 'H_POA (unshaded)', value: `${fmt(a.annualPoaKwhM2, 1)} kWh/m²` }]} result={`${fmt(a.performanceRatio * 100, 2)} %`} />
          </Kpi>
          <Kpi label="Capacity factor" value={`${fmt(a.capacityFactorDc * 100, 1)} %`} unit="DC basis" tag={src}>
            <HowCalculated formula="CF = E_annual / (P_DC × 8760 h)" lines={[{ label: 'E_annual', value: formatEnergyKwh(a.annualAcKwh) }, { label: 'P_DC × 8760 h', value: formatEnergyKwh(a.dcKwp * 8760) }]} result={`${fmt(a.capacityFactorDc * 100, 2)} %`} />
          </Kpi>
        </div>

        <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
          <ChartCard title="Monthly solar irradiation" unit="kWh/m²" testId="chart-irradiation" csv={() => toCsv(['Month', 'GHI kWh/m2', 'POA kWh/m2'], monthly.map((m) => [m.month, m.ghi, m.poa]))}>
            <ResponsiveContainer><BarChart data={monthly}><CartesianGrid stroke="#eceff3" vertical={false} /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v} kWh/m²`} /><Legend wrapperStyle={AX} /><Bar isAnimationActive={false} dataKey="ghi" name="Horizontal (GHI)" fill="#9aa3ad" /><Bar isAnimationActive={false} dataKey="poa" name="Plane of array" fill="#F5B700" /></BarChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Monthly energy generation" unit="kWh" testId="chart-monthly-energy" csv={() => toCsv(['Month', 'AC kWh'], monthly.map((m) => [m.month, m.energy]))}>
            <ResponsiveContainer><BarChart data={monthly}><CartesianGrid stroke="#eceff3" vertical={false} /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v.toLocaleString()} kWh`} /><Legend wrapperStyle={AX} /><Bar isAnimationActive={false} dataKey="energy" name="AC energy" fill="#2563EB" /></BarChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Peak sun hours" unit="h/day on array plane" csv={() => toCsv(['Month', 'Peak sun hours'], monthly.map((m) => [m.month, m.psh]))}>
            <ResponsiveContainer><LineChart data={monthly}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v} h`} /><Legend wrapperStyle={AX} /><Line isAnimationActive={false} dataKey="psh" name="Peak sun hours" stroke="#F5B700" strokeWidth={2.5} dot /></LineChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Daily energy generation" unit="kWh/day" note="Typical-year daily profile: monthly climatology interpolated between representative days and scaled to monthly totals. Not measured daily data." csv={() => toCsv(['Day of year', 'kWh'], daily.map((d) => [d.day, d.kwh]))}>
            <ResponsiveContainer><LineChart data={daily}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="day" tick={AX} ticks={[1, 60, 121, 182, 244, 305, 365]} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v} kWh`} labelFormatter={(l) => `Day ${l}`} /><Legend wrapperStyle={AX} /><Line dataKey="kwh" name="Daily AC energy" stroke="#2563EB" dot={false} strokeWidth={1.5} isAnimationActive={false} /></LineChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Cumulative annual generation" unit="kWh" csv={() => toCsv(['Day of year', 'Cumulative kWh'], daily.map((d) => [d.day, d.cum]))}>
            <ResponsiveContainer><ComposedChart data={daily}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="day" tick={AX} ticks={[1, 60, 121, 182, 244, 305, 365]} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v.toLocaleString()} kWh`} labelFormatter={(l) => `Day ${l}`} /><Legend wrapperStyle={AX} /><Area dataKey="cum" name="Cumulative" stroke="#1F8A4C" fill="#DDF3E5" isAnimationActive={false} /></ComposedChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Seasonal generation" unit="kWh" note="Meteorological seasons for the site's hemisphere." csv={() => toCsv(['Season', 'kWh'], seasons.map((s) => [s.season, s.energy]))}>
            <ResponsiveContainer><BarChart data={seasons}><CartesianGrid stroke="#eceff3" vertical={false} /><XAxis dataKey="season" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v.toLocaleString()} kWh`} /><Legend wrapperStyle={AX} /><Bar isAnimationActive={false} dataKey="energy" name="AC energy" fill="#1F3452" /></BarChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Loss breakdown" unit="kWh/yr" testId="chart-losses" csv={() => toCsv(['Stage', 'Loss kWh', 'Loss %', 'Energy after kWh', 'Source'], a.lossStages.map((s) => [s.label, Math.round(s.lossKwh), s.lossPct.toFixed(2), Math.round(s.energyAfterKwh), s.source]))}>
            <ResponsiveContainer>
              <BarChart data={waterfall} margin={{ bottom: 40 }}><CartesianGrid stroke="#eceff3" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 9.5 }} angle={-35} textAnchor="end" interval={0} /><YAxis tick={AX} /><Tooltip formatter={(v: number, n: string) => (n === 'base' ? null : `${v.toLocaleString()} kWh`)} />
                <Bar isAnimationActive={false} dataKey="base" stackId="w" fill="transparent" legendType="none" />
                <Bar isAnimationActive={false} dataKey="value" stackId="w" name="Energy / loss">{waterfall.map((r, i) => <Cell key={i} fill={r.kind === 'total' ? '#2563EB' : '#D23B30'} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Solar resource" unit="kWh/m² per month, horizontal" note="Beam/diffuse split modelled with the Erbs correlation from the provider's GHI." csv={() => toCsv(['Month', 'Beam kWh/m2', 'Diffuse kWh/m2'], monthly.map((m) => [m.month, m.beam, m.diffuse]))}>
            <ResponsiveContainer><BarChart data={monthly}><CartesianGrid stroke="#eceff3" vertical={false} /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v} kWh/m²`} /><Legend wrapperStyle={AX} /><Bar isAnimationActive={false} dataKey="beam" stackId="r" name="Beam (modelled)" fill="#F5B700" /><Bar isAnimationActive={false} dataKey="diffuse" stackId="r" name="Diffuse (modelled)" fill="#9aa3ad" /></BarChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Temperature" unit="°C" csv={() => toCsv(['Month', 'Mean', 'Mean daily max', 'Mean daily min'], monthly.map((m) => [m.month, m.tMean, m.tMax ?? '', m.tMin ?? '']))}>
            <ResponsiveContainer><LineChart data={monthly}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} /><Tooltip formatter={(v: number) => `${v} °C`} /><Legend wrapperStyle={AX} /><Line isAnimationActive={false} dataKey="tMax" name="Mean daily max" stroke="#D23B30" dot={false} connectNulls /><Line isAnimationActive={false} dataKey="tMean" name="Mean" stroke="#1F3452" strokeWidth={2} /><Line isAnimationActive={false} dataKey="tMin" name="Mean daily min" stroke="#2563EB" dot={false} connectNulls /></LineChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Performance ratio" unit="%" csv={() => toCsv(['Month', 'PR %'], monthly.map((m) => [m.month, m.pr]))}>
            <ResponsiveContainer><LineChart data={monthly}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="month" tick={AX} /><YAxis tick={AX} domain={['auto', 'auto']} /><Tooltip formatter={(v: number) => `${v} %`} /><Legend wrapperStyle={AX} /><Line isAnimationActive={false} dataKey="pr" name="Monthly PR" stroke="#1F8A4C" strokeWidth={2.5} /></LineChart></ResponsiveContainer>
          </ChartCard>
          <ChartCard title={`Representative day · ${MONTH_NAMES[hm]}`} unit="W/m², kW" note="Modelled day (solar time) for the selected month." csv={() => toCsv(['Solar hour', 'POA W/m2', 'AC kW', 'Cell temp C', 'Shaded %'], hourly.map((h) => [h.hour, h.poa, h.ac, h.tc, h.shaded]))}>
            <div className="flex h-full flex-col">
              <select aria-label="Month for hourly profile" className="input mb-1 w-40 py-0.5" value={hm} onChange={(e) => setHm(+e.target.value)}>{MONTH_NAMES.map((m, i) => <option key={m} value={i}>{m}</option>)}</select>
              <div className="flex-1"><ResponsiveContainer><ComposedChart data={hourly}><CartesianGrid stroke="#eceff3" /><XAxis dataKey="hour" tick={AX} /><YAxis yAxisId="w" tick={AX} /><YAxis yAxisId="k" orientation="right" tick={AX} /><Tooltip /><Legend wrapperStyle={AX} /><Area yAxisId="w" dataKey="poa" name="POA W/m²" fill="#FFF3CC" stroke="#F5B700" isAnimationActive={false} /><Line yAxisId="k" dataKey="ac" name="AC kW" stroke="#2563EB" dot={false} strokeWidth={2} isAnimationActive={false} /></ComposedChart></ResponsiveContainer></div>
            </div>
          </ChartCard>
        </div>

        <section className="rounded-[3px] border border-rule bg-white" aria-label="Monthly analysis table">
          <header className="border-b border-rule px-3 py-2"><h3 className="panel-title">Monthly analysis <Tag kind={src} /></h3></header>
          <div className="overflow-x-auto">
            <table className="table-eng" data-testid="monthly-table">
              <thead><tr><th>Month</th><th className="num">Solar irradiation GHI (kWh/m²)</th><th className="num">POA (kWh/m²)</th><th className="num">Peak sun hours (h/d)</th><th className="num">Avg. temperature (°C)</th><th className="num">Energy generation (kWh)</th><th className="num">Avg. daily (kWh/d)</th><th className="num">Losses (kWh)</th><th className="num">Shading (%)</th><th className="num">Performance ratio (%)</th></tr></thead>
              <tbody>
                {a.months.map((m, i) => (
                  <tr key={i}><td>{MONTH_NAMES[i]}</td><td className="num">{fmt(m.ghiKwhM2, 1)}</td><td className="num">{fmt(m.poaKwhM2, 1)}</td><td className="num">{fmt(m.peakSunHours, 2)}</td><td className="num">{fmt(m.tMeanC, 1)}</td><td className="num">{fmt(m.acKwh, 0)}</td><td className="num">{fmt(m.avgDailyKwh, 1)}</td><td className="num">{fmt(m.lossesKwh, 0)}</td><td className="num">{fmt(m.shadingLossPct, 1)}</td><td className="num">{fmt(m.performanceRatio * 100, 1)}</td></tr>
                ))}
                <tr className="font-semibold"><td>Year</td><td className="num">{fmt(a.annualGhiKwhM2, 0)}</td><td className="num">{fmt(a.annualPoaKwhM2, 0)}</td><td className="num">{fmt(a.annualPoaKwhM2 / 365, 2)}</td><td className="num">{fmt(a.months.reduce((s, m) => s + m.tMeanC * m.days, 0) / 365, 1)}</td><td className="num" data-testid="annual-total">{fmt(a.annualAcKwh, 0)}</td><td className="num">{fmt(a.annualAcKwh / 365, 1)}</td><td className="num">{fmt(a.months.reduce((s, m) => s + m.lossesKwh, 0), 0)}</td><td className="num">{fmt(a.lossStages[1].lossPct, 1)}</td><td className="num">{fmt(a.performanceRatio * 100, 1)}</td></tr>
              </tbody>
            </table>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <section className="rounded-[3px] border border-rule bg-white p-3">
            <h3 className="panel-title mb-2">Loss stages</h3>
            <table className="table-eng"><thead><tr><th>Stage</th><th className="num">Loss %</th><th className="num">Loss kWh</th><th>Source</th></tr></thead>
              <tbody>{a.lossStages.slice(1).map((s) => <tr key={s.key}><td>{s.label}</td><td className="num">{fmt(s.lossPct, 2)}</td><td className="num">{fmt(s.lossKwh, 0)}</td><td><Tag kind={s.source} /></td></tr>)}</tbody>
            </table>
          </section>
          <section className="rounded-[3px] border border-rule bg-white p-3">
            <h3 className="panel-title mb-2">Array groups</h3>
            <table className="table-eng"><thead><tr><th>Surface</th><th className="num">Panels</th><th className="num">kWp</th><th className="num">Tilt</th><th className="num">Azimuth</th><th className="num">POA kWh/m²</th></tr></thead>
              <tbody>{a.surfaces.map((s) => <tr key={s.surfaceId}><td>{s.name}</td><td className="num">{s.panelCount}</td><td className="num">{fmt(s.kWp, 2)}</td><td className="num">{fmt(s.tiltDeg, 1)}°</td><td className="num">{fmt(s.azimuthDeg, 0)}°</td><td className="num">{fmt(s.annualPoaKwhM2, 0)}</td></tr>)}</tbody>
            </table>
            <h4 className="subhead">Model assumptions</h4>
            <ul className="list-disc space-y-0.5 pl-4 text-[12px] text-char-800">{a.assumptions.map((x) => <li key={x}>{x}</li>)}</ul>
            <p className="mt-2 text-[11.5px] text-char-700">Days per month used: {DAYS_IN_MONTH.join(', ')} (non-leap year).</p>
          </section>
        </div>
      </div>
    </div>
  );
}

function Kpi({ label, value, unit, tag, children, testId }: { label: string; value: string; unit: string; tag: 'demo' | 'calculated'; children?: React.ReactNode; testId?: string }) {
  return (
    <section className="rounded-[3px] border border-rule border-t-4 border-t-sun-500 bg-white p-3" aria-label={label}>
      <div className="flex items-center justify-between text-[12px] text-char-700">{label}<Tag kind={tag} /></div>
      <div className="font-cond text-[26px] font-semibold leading-tight text-navy-900" data-testid={testId}>{value}</div>
      <div className="text-[11.5px] text-char-700">{unit}</div>
      {children}
    </section>
  );
}
