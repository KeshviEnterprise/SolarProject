import { useState } from 'react';
import { useStore } from '@/store/projectStore';
import { NumberField, KV, Notice, Tag, Grid2, fmt, HowCalculated } from '@/components/ui';
import { PROVIDERS } from '@/services/providers';
import { fetchSolarData, useDemoSolarData, runAnalysisAction, isAnalysisStale } from '@/services/actions';
import { calculateSystemLosses, DEFAULT_LOSSES } from '@/calculations/losses';
import { MONTH_SHORT, DAYS_IN_MONTH } from '@/calculations/solarPosition';
import type { Losses, SolarProviderId } from '@/types';

export function EnergySection() {
  const p = useStore((s) => s.project);
  const status = useStore((s) => s.solarStatus);
  const attempts = useStore((s) => s.solarAttempts);
  const aStatus = useStore((s) => s.analysisStatus);
  const aError = useStore((s) => s.analysisError);
  const { update, set } = useStore.getState();
  const [provider, setProvider] = useState<SolarProviderId>(p.solarResource && p.solarResource.provider !== 'demo' ? p.solarResource.provider : 'nasa-power');
  const r = p.solarResource;
  const L = p.losses;
  const setL = (patch: Partial<Losses>) => update((q) => ({ ...q, losses: { ...q.losses, ...patch }, analysis: null }));
  const sys = calculateSystemLosses(L);
  const annualGhi = r ? r.monthly.reduce((a, m, i) => a + m.ghiKwhM2Day * DAYS_IN_MONTH[i], 0) : 0;

  return (
    <div className="space-y-3">
      <h3 className="subhead mt-0">Solar resource data</h3>
      <div>
        <label className="label" htmlFor="provider">Primary data provider</label>
        <select id="provider" className="input" value={provider} onChange={(e) => setProvider(e.target.value as SolarProviderId)}>
          {(['nasa-power', 'pvgis', 'pvwatts'] as SolarProviderId[]).map((id) => <option key={id} value={id}>{PROVIDERS[id].label}</option>)}
        </select>
        <p className="mt-1 text-[11.5px] text-char-700">{PROVIDERS[provider].description} If it fails, the other real providers are tried in turn.</p>
      </div>
      <button className="btn btn-primary w-full" data-testid="fetch-solar" disabled={status === 'loading'} onClick={() => void fetchSolarData(provider)}>{status === 'loading' ? 'Fetching solar data…' : r && !r.isDemo ? 'Refresh solar data' : 'Fetch solar data'}</button>
      {status === 'error' && (
        <div className="space-y-2" data-testid="solar-error">
          <Notice tone="error">
            <strong>Solar resource data is currently unavailable.</strong>
            <ul className="mt-1 list-disc pl-4">{attempts.map((a) => <li key={a.provider}>{a.provider}: {a.error}</li>)}</ul>
          </Notice>
          <div className="flex gap-2">
            <button className="btn btn-secondary" onClick={() => void fetchSolarData(provider)}>Retry</button>
            <button className="btn btn-danger" data-testid="use-demo-data" onClick={useDemoSolarData}>Use demo data</button>
          </div>
          <p className="text-[11.5px] text-char-700">Demo data is synthetic (extraterrestrial irradiation × an assumed clearness index) and every result will be marked DEMO / ESTIMATED.</p>
        </div>
      )}
      {r && (
        <div className="space-y-1">
          {r.isDemo && <Notice tone="demo"><strong>DEMO data.</strong> {r.notes[0]}</Notice>}
          <KV label="Source" value={r.providerLabel} tag={r.isDemo ? 'demo' : 'external'} />
          <KV label="Period" value={r.period} />
          <KV label="Retrieved" value={new Date(r.fetchedAt).toLocaleString()} />
          <KV label="Annual GHI" value={`${fmt(annualGhi, 0)} kWh/m²`} tag={r.isDemo ? 'demo' : 'external'} />
          <div className="overflow-x-auto">
            <table className="table-eng mt-1 bg-white">
              <thead><tr><th>Month</th><th className="num">GHI kWh/m²/d</th><th className="num">T mean °C</th><th className="num">T max / min</th></tr></thead>
              <tbody>{r.monthly.map((m, i) => <tr key={i}><td>{MONTH_SHORT[i]}</td><td className="num">{fmt(m.ghiKwhM2Day, 2)}</td><td className="num">{fmt(m.tMeanC, 1)}</td><td className="num">{m.tMaxC !== null ? `${fmt(m.tMaxC, 1)} / ${fmt(m.tMinC, 1)}` : '—'}</td></tr>)}</tbody>
            </table>
          </div>
          {!r.isDemo && r.notes.map((n) => <p key={n} className="text-[11.5px] text-char-700">{n}</p>)}
          {r.requestUrl && <p className="break-all text-[11px] text-char-700">Request: {r.requestUrl}</p>}
        </div>
      )}

      <h3 className="subhead">Loss assumptions</h3>
      <p className="text-[12px] text-char-700">Temperature, shading, reflection (incidence angle) and clipping are computed by the model. The losses below are editable assumptions <Tag kind="assumption" />.</p>
      <Grid2>
        <NumberField label="Soiling" unit="%" value={L.soilingPct} min={0} max={49} onCommit={(v) => v !== null && setL({ soilingPct: v })} />
        <NumberField label="Module mismatch" unit="%" value={L.mismatchPct} min={0} max={49} onCommit={(v) => v !== null && setL({ mismatchPct: v })} />
        <NumberField label="DC wiring" unit="%" value={L.dcWiringPct} min={0} max={49} onCommit={(v) => v !== null && setL({ dcWiringPct: v })} />
        <NumberField label="AC wiring" unit="%" value={L.acWiringPct} min={0} max={49} onCommit={(v) => v !== null && setL({ acWiringPct: v })} />
        <NumberField label="Inverter loss" unit="%" value={L.inverterPct} min={0} max={49} onCommit={(v) => v !== null && setL({ inverterPct: v })} hint={`Selected inverter max. η ${p.electrical.inverter.maxEfficiencyPct} %`} />
        <NumberField label="Availability" unit="%" value={L.availabilityPct} min={50} max={100} onCommit={(v) => v !== null && setL({ availabilityPct: v })} />
        <NumberField label="Other (LID, etc.)" unit="%" value={L.otherPct} min={0} max={49} onCommit={(v) => v !== null && setL({ otherPct: v })} />
        <NumberField label="Ground albedo" value={L.albedo} min={0} max={1} onCommit={(v) => v !== null && setL({ albedo: v })} />
        <NumberField label="Shading override" unit="%" value={L.shadingOverridePct} allowEmpty min={0} max={99} onCommit={(v) => setL({ shadingOverridePct: v })} hint="Empty = use computed shading" />
      </Grid2>
      <KV label="Combined fixed-loss factor" value={`${fmt(sys.combinedFactor * 100, 2)} %`} tag="calculated">
        <HowCalculated formula="η_sys = Π (1 − Lᵢ)" lines={sys.factors.map((f) => ({ label: f.label, value: `${fmt(f.pct, 2)} % → × ${f.factor.toFixed(4)}` }))} result={`${fmt(sys.combinedFactor, 4)} (−${fmt(sys.combinedLossPct, 2)} %)`} />
      </KV>
      <button className="btn btn-ghost border border-rule text-[12px]" onClick={() => setL({ ...DEFAULT_LOSSES, albedo: L.albedo })}>Reset loss assumptions to defaults</button>

      <h3 className="subhead">Run</h3>
      <button className="btn btn-primary w-full" data-testid="run-analysis-side" disabled={aStatus === 'running'} onClick={() => void runAnalysisAction()}>{aStatus === 'running' ? 'Running analysis…' : 'Run energy analysis'}</button>
      {aError && <Notice tone="error">{aError}</Notice>}
      {p.analysis && isAnalysisStale() && <Notice tone="warning">The design changed since the last analysis. Run it again to update results.</Notice>}
      {p.analysis && <button className="btn btn-secondary w-full" onClick={() => set({ view: 'analysis' })}>Open energy results</button>}
    </div>
  );
}
