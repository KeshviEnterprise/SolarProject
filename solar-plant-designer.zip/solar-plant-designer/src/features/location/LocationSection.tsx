import { useState } from 'react';
import { useStore } from '@/store/projectStore';
import { NumberField, TextField, KV, Tag, Notice, fmt, HowCalculated } from '@/components/ui';
import { MapView } from './MapView';
import { searchPlaces, fetchSiteInfo, estimateUtcOffset, type GeocodeResult } from '@/services/geoService';
import { latitudeSchema, longitudeSchema, fieldError } from '@/calculations/validation';
import { calculateSunriseSunset, formatClock, formatDuration, dayOfYear, declinationDeg } from '@/calculations/solarPosition';
import type { Location } from '@/types';

export function LocationSection() {
  const loc = useStore((s) => s.project.location);
  const resource = useStore((s) => s.project.solarResource);
  const doy = useStore((s) => s.sun.doy);
  const { update, notify } = useStore.getState();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<GeocodeResult[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const setLoc = (patch: Partial<Location>) => update((p) => {
    const moved = patch.latitude !== undefined || patch.longitude !== undefined;
    return { ...p, location: { ...p.location, ...patch }, ...(moved ? { solarResource: null, analysis: null } : {}) };
  });

  const lookupSite = async (lat: number, lon: number) => {
    try {
      const info = await fetchSiteInfo(lat, lon);
      setLoc({ timezone: info.timezone, utcOffsetHours: info.utcOffsetHours, utcOffsetSource: 'external', elevationM: info.elevationM, elevationSource: info.elevationM !== null ? 'external' : null });
    } catch {
      setLoc({ timezone: null, utcOffsetHours: estimateUtcOffset(lon), utcOffsetSource: 'estimated', elevationM: null, elevationSource: null });
      notify('Time zone lookup failed - offset estimated from longitude', 'info');
    }
  };

  const pick = (lat: number, lon: number, extra: Partial<Location> = {}) => {
    setLoc({ latitude: lat, longitude: lon, ...extra });
    void lookupSite(lat, lon);
  };

  const search = async () => {
    if (!q.trim()) return;
    setBusy(true); setErr(null);
    try { const r = await searchPlaces(q); setResults(r); if (!r.length) setErr('No places matched. Try a city name or enter coordinates.'); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Search failed'); setResults(null); }
    finally { setBusy(false); }
  };

  const t = calculateSunriseSunset(loc.latitude, loc.longitude, doy, loc.utcOffsetHours);
  const d = new Date(Date.UTC(2023, 0, doy));
  const annualGhi = resource ? resource.monthly.reduce((a, m, i) => a + m.ghiKwhM2Day * [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][i], 0) : null;

  return (
    <div className="space-y-3">
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); void search(); }} role="search">
        <label className="sr-only" htmlFor="loc-q">Search location</label>
        <input id="loc-q" data-testid="location-search" className="input" placeholder="Search address or city" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn btn-dark shrink-0" disabled={busy}>{busy ? 'Searching…' : 'Search'}</button>
      </form>
      {err && <Notice tone="warning">{err}</Notice>}
      {results && results.length > 0 && (
        <ul className="max-h-40 divide-y divide-rule overflow-auto rounded-[3px] border border-rule bg-white text-[12.5px]">
          {results.map((r) => (
            <li key={`${r.lat},${r.lon}`}>
              <button className="w-full px-2 py-1.5 text-left hover:bg-paper" onClick={() => { pick(+r.lat.toFixed(6), +r.lon.toFixed(6), { address: r.displayName, city: r.city, state: r.state, country: r.country, postalCode: r.postalCode }); setResults(null); }}>{r.displayName}</button>
            </li>
          ))}
        </ul>
      )}
      <MapView lat={loc.latitude} lon={loc.longitude} onPick={(a, b) => pick(a, b)} />
      <div className="grid grid-cols-2 gap-x-3 gap-y-2.5">
        <NumberField label="Latitude" unit="°" value={loc.latitude} testId="lat" validate={(v) => fieldError(latitudeSchema, v)} onCommit={(v) => v !== null && pick(v, loc.longitude)} tag="user" />
        <NumberField label="Longitude" unit="°" value={loc.longitude} testId="lon" validate={(v) => fieldError(longitudeSchema, v)} onCommit={(v) => v !== null && pick(loc.latitude, v)} tag="user" />
      </div>
      <TextField label="Address" value={loc.address} onCommit={(v) => setLoc({ address: v })} />
      <div className="grid grid-cols-2 gap-x-3 gap-y-2.5">
        <TextField label="City" value={loc.city} onCommit={(v) => setLoc({ city: v })} />
        <TextField label="State" value={loc.state} onCommit={(v) => setLoc({ state: v })} />
        <TextField label="Country" value={loc.country} onCommit={(v) => setLoc({ country: v })} />
        <TextField label="Postal code" value={loc.postalCode} onCommit={(v) => setLoc({ postalCode: v })} />
      </div>
      <div className="grid grid-cols-2 gap-x-3">
        <NumberField label="UTC offset" unit="h" value={loc.utcOffsetHours} min={-12} max={14} tag={loc.utcOffsetSource} onCommit={(v) => v !== null && setLoc({ utcOffsetHours: v, utcOffsetSource: 'user' })} />
        <div className="self-end pb-1.5 text-[12px] text-char-700">{loc.timezone ?? 'Time zone not looked up'}</div>
      </div>

      <h3 className="subhead">Site sun data · {d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', timeZone: 'UTC' })}</h3>
      <KV label="Latitude / longitude" value={`${loc.latitude.toFixed(4)}°, ${loc.longitude.toFixed(4)}°`} tag="user" />
      <KV label="Elevation" value={loc.elevationM !== null ? `${fmt(loc.elevationM, 0)} m` : 'Not available'} tag={loc.elevationSource ?? undefined} />
      <KV label="Sunrise" value={formatClock(t.sunrise)} tag="calculated" />
      <KV label="Solar noon" value={formatClock(t.solarNoon)} tag="calculated" />
      <KV label="Sunset" value={formatClock(t.sunset)} tag="calculated" />
      <KV label="Day length" value={formatDuration(t.dayLengthHours)} tag="calculated">
        <HowCalculated formula={'ωs = arccos[cos 90.833° / (cos φ cos δ) − tan φ tan δ]\nDay length = 2·ωs / 15°'}
          lines={[{ label: 'Latitude φ', value: `${loc.latitude.toFixed(4)}°` }, { label: 'Declination δ', value: `${declinationDeg(doy).toFixed(2)}°` }, { label: 'Day of year', value: String(doy) }]}
          result={formatDuration(t.dayLengthHours)} note="NOAA algorithm; 90.833° includes refraction and the solar disc. Clock times in standard time; daylight saving not applied." />
      </KV>
      <KV label="Max. sun elevation" value={`${t.maxElevationDeg.toFixed(1)}°`} tag="calculated" />
      <KV label="Annual GHI" value={annualGhi !== null ? `${fmt(annualGhi, 0)} kWh/m²` : 'Load solar data (Energy analysis)'} tag={resource ? (resource.isDemo ? 'demo' : 'external') : undefined} />
      {resource && <p className="text-[11.5px] text-char-700">Solar resource: {resource.providerLabel} <Tag kind={resource.isDemo ? 'demo' : 'external'} /></p>}
      <p className="text-[11px] text-char-700">Search by OpenStreetMap Nominatim · time zone and elevation by Open-Meteo. Date for sun times is set in Shading (today: day {dayOfYear(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())}).</p>
    </div>
  );
}
