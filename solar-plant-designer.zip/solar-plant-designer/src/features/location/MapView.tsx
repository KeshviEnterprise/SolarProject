import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

/**
 * Leaflet map with OpenStreetMap tiles (optional Esri World Imagery layer).
 * Clicking the map or dragging the pin sets coordinates. If tiles fail to load the map still
 * works as a coordinate picker on a blank background and a notice is shown.
 */
export function MapView({ lat, lon, onPick }: { lat: number; lon: number; onPick: (lat: number, lon: number) => void }) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const marker = useRef<L.CircleMarker | null>(null);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;
  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    if (!el.current || map.current) return;
    const m = L.map(el.current, { zoomControl: true, attributionControl: true }).setView([lat, lon], 15);
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' });
    const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Imagery © Esri, Maxar, Earthstar Geographics' });
    let errors = 0;
    const onErr = () => { errors++; if (errors > 3) setTileError(true); };
    osm.on('tileerror', onErr); sat.on('tileerror', onErr);
    osm.addTo(m);
    L.control.layers({ 'Street map': osm, Satellite: sat }, {}, { position: 'topright' }).addTo(m);
    marker.current = L.circleMarker([lat, lon], { radius: 8, color: '#0E1B2E', weight: 2, fillColor: '#F5B700', fillOpacity: 1 }).addTo(m);
    m.on('click', (e: L.LeafletMouseEvent) => pickRef.current(+e.latlng.lat.toFixed(6), +e.latlng.lng.toFixed(6)));
    map.current = m;
    return () => { m.remove(); map.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!map.current || !marker.current) return;
    marker.current.setLatLng([lat, lon]);
    if (!map.current.getBounds().contains([lat, lon])) map.current.setView([lat, lon], map.current.getZoom());
  }, [lat, lon]);

  return (
    <div className="relative">
      <div ref={el} className="h-56 w-full rounded-[3px] border border-rule" role="application" aria-label="Map - click to place the site pin" />
      {tileError && <p className="mt-1 text-[11.5px] text-char-700">Map tiles could not be loaded. Click the grey map area or type coordinates below - calculations do not depend on the map.</p>}
    </div>
  );
}
