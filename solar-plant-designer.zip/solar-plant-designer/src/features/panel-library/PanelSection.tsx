import { useStore } from '@/store/projectStore';
import { PANEL_LIBRARY, CUSTOM_PANEL, panelEfficiencyPct } from '@/data/panelLibrary';
import { NumberField, SelectField, TextField, Toggle, KV, HowCalculated, Notice, Grid2, fmt } from '@/components/ui';
import { validatePanel } from '@/calculations/validation';
import type { PanelSpec, PanelTechnology } from '@/types';

export function PanelSection() {
  const panel = useStore((s) => s.project.panel);
  const { update } = useStore.getState();
  const errs = validatePanel(panel);
  const set = (patch: Partial<PanelSpec>) => update((p) => {
    const next = { ...p.panel, ...patch };
    if (next.id !== 'custom' && Object.keys(patch).some((k) => k !== 'sourceNote')) { next.id = 'custom'; next.manufacturer = p.panel.manufacturer === 'Generic' ? 'Custom (edited)' : next.manufacturer; next.sourceNote = 'User-edited values.'; }
    if ('powerW' in patch || 'lengthMm' in patch || 'widthMm' in patch) next.efficiencyPct = +panelEfficiencyPct(next.powerW, next.lengthMm, next.widthMm).toFixed(2);
    return { ...p, panel: next, analysis: null };
  });
  const areaM2 = (panel.lengthMm / 1000) * (panel.widthMm / 1000);
  const derivedEff = panelEfficiencyPct(panel.powerW, panel.lengthMm, panel.widthMm);

  return (
    <div className="space-y-3">
      <SelectField label="Panel library" testId="panel-select" value={PANEL_LIBRARY.some((x) => x.id === panel.id) ? panel.id : 'custom'}
        options={[...PANEL_LIBRARY.map((x) => ({ value: x.id, label: `${x.powerW} W · ${x.model}` })), { value: 'custom', label: 'Custom panel' }]}
        onChange={(id) => update((p) => ({ ...p, panel: id === 'custom' ? { ...CUSTOM_PANEL, ...p.panel, id: 'custom', manufacturer: 'Custom', sourceNote: 'User-entered values.' } : { ...PANEL_LIBRARY.find((x) => x.id === id)! }, layout: { ...p.layout, panels: [] }, analysis: null }))} />
      <Notice tone="info">{panel.sourceNote} Changing the panel clears the layout; regenerate it afterwards.</Notice>
      <Grid2>
        <TextField label="Manufacturer" value={panel.manufacturer} onCommit={(v) => set({ manufacturer: v })} />
        <TextField label="Model" value={panel.model} onCommit={(v) => set({ model: v })} />
        <NumberField label="Rated power (STC)" unit="W" value={panel.powerW} testId="panel-power" min={1} max={1500} tag="user" onCommit={(v) => v !== null && set({ powerW: v })} />
        <SelectField<PanelTechnology> label="Technology" value={panel.technology} options={(['mono-PERC', 'TOPCon', 'HJT', 'IBC', 'poly', 'thin-film', 'other'] as PanelTechnology[]).map((t) => ({ value: t, label: t }))} onChange={(v) => set({ technology: v })} />
        <NumberField label="Length" unit="mm" value={panel.lengthMm} testId="panel-length" min={100} max={4000} tag="user" onCommit={(v) => v !== null && set({ lengthMm: v })} />
        <NumberField label="Width" unit="mm" value={panel.widthMm} testId="panel-width" min={100} max={3000} tag="user" onCommit={(v) => v !== null && set({ widthMm: v })} />
        <NumberField label="Thickness" unit="mm" value={panel.thicknessMm} min={1} max={200} onCommit={(v) => v !== null && set({ thicknessMm: v })} />
        <NumberField label="Weight" unit="kg" value={panel.weightKg} min={0} max={200} onCommit={(v) => v !== null && set({ weightKg: v })} />
        <NumberField label="Efficiency" unit="%" value={panel.efficiencyPct} min={0.1} max={50} tag={Math.abs(derivedEff - panel.efficiencyPct) < 0.05 ? 'calculated' : 'user'} onCommit={(v) => v !== null && update((p) => ({ ...p, panel: { ...p.panel, efficiencyPct: v } }))} />
        <div className="flex items-end pb-1.5"><Toggle label="Bifacial" checked={panel.bifacial} onChange={(v) => set({ bifacial: v })} /></div>
      </Grid2>
      <h3 className="subhead">Electrical (STC)</h3>
      <Grid2>
        <NumberField label="Voc" unit="V" value={panel.vocV} min={0.1} onCommit={(v) => v !== null && set({ vocV: v })} />
        <NumberField label="Isc" unit="A" value={panel.iscA} min={0.01} onCommit={(v) => v !== null && set({ iscA: v })} />
        <NumberField label="Vmp" unit="V" value={panel.vmpV} min={0.1} onCommit={(v) => v !== null && set({ vmpV: v })} />
        <NumberField label="Imp" unit="A" value={panel.impA} min={0.01} onCommit={(v) => v !== null && set({ impA: v })} />
        <NumberField label="Temp. coeff. Pmax" unit="%/°C" value={panel.tempCoeffPmaxPctPerC} min={-1} max={0.1} onCommit={(v) => v !== null && set({ tempCoeffPmaxPctPerC: v })} />
        <NumberField label="Temp. coeff. Voc" unit="%/°C" value={panel.tempCoeffVocPctPerC} min={-1} max={0.1} onCommit={(v) => v !== null && set({ tempCoeffVocPctPerC: v })} />
      </Grid2>
      {Object.values(errs).map((e) => <Notice key={e} tone="error">{e}</Notice>)}
      {panel.bifacial && <Notice tone="info">Bifacial rear-side gain is not modelled; energy is computed for the front side only.</Notice>}
      <h3 className="subhead">Derived</h3>
      <KV label="Module area" value={`${fmt(areaM2, 3)} m²`} tag="calculated" />
      <KV label="Efficiency from power and area" value={`${fmt(derivedEff, 2)} %`} tag="calculated">
        <HowCalculated formula="η = P_STC / (A × 1000 W/m²)" lines={[{ label: 'P_STC', value: `${panel.powerW} W` }, { label: 'Area', value: `${panel.lengthMm} × ${panel.widthMm} mm = ${fmt(areaM2, 3)} m²` }]} result={`${fmt(derivedEff, 2)} %`} />
      </KV>
      <KV label="Fill factor" value={fmt((panel.vmpV * panel.impA) / (panel.vocV * panel.iscA), 3)} tag="calculated" />
      <KV label="Vmp × Imp" value={`${fmt(panel.vmpV * panel.impA, 1)} W`} tag="calculated" />
    </div>
  );
}
