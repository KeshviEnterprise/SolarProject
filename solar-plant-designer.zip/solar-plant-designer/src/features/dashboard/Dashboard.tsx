import type { ReactNode } from 'react';
import { useDerived } from '@/hooks/useDerived';
import { useStore } from '@/store/projectStore';
import { Tag, fmt, Notice } from '@/components/ui';
import { formatArea, formatEnergyKwh } from '@/calculations/units';
import { STRUCTURE_BY_ID } from '@/data/structureTypes';
import { compass } from '@/calculations/structure';
import { DAYS_IN_MONTH } from '@/calculations/solarPosition';
import { isAnalysisStale } from '@/services/actions';
import type { Provenance } from '@/types';

export function Dashboard() {
  const { project: p, areas, stats, surfaces, mounts, issues, weightKg } = useDerived();
  const { set } = useStore.getState();
  const a = p.analysis;
  const r = p.solarResource;
  const u = p.settings.displayUnit;
  const src: Provenance = r?.isDemo ? 'demo' : 'external';
  const res: Provenance = a?.isDemoData ? 'demo' : 'calculated';
  const shadingLoss = a?.lossStages.find((s) => s.key === 'shading');
  const tilts = [...new Set(surfaces.map((s) => `${fmt(mounts[s.id]?.tiltDeg, 1)}°`))].join(' / ');
  const azs = [...new Set(surfaces.map((s) => `${fmt(mounts[s.id]?.azimuthDeg, 0)}° ${compass(mounts[s.id]?.azimuthDeg ?? 0)}`))].join(' / ');

  return (
    <div className="h-full overflow-auto bg-paper" data-testid="dashboard">
      <div className="mx-auto max-w-[1300px] space-y-4 p-4">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div><h2 className="font-cond text-[24px] font-semibold text-navy-900">{p.name}</h2><p className="text-[12.5px] text-char-700">{[p.location.city, p.location.state, p.location.country].filter(Boolean).join(', ')} · {p.location.latitude.toFixed(4)}°, {p.location.longitude.toFixed(4)}°</p></div>
          {!a && <button className="btn btn-primary" onClick={() => set({ section: 'energy' })}>Set up energy analysis</button>}
        </div>
        {a?.isDemoData && <Notice tone="demo">Energy figures are DEMO / ESTIMATED values from synthetic solar data.</Notice>}
        {a && isAnalysisStale() && <Notice tone="warning">Design changed after the last analysis; energy figures are out of date.</Notice>}
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          <Group title="Project">
            <Row l="Structure type" v={STRUCTURE_BY_ID[p.structure.type].label} t="user" />
            <Row l="Roof area" v={formatArea(areas.roofPlanAreaM2, u)} t="calculated" />
            <Row l="Usable area" v={formatArea(areas.usableAreaM2, u)} t="calculated" />
            <Row l="Obstacles" v={String(p.obstacles.length)} t="user" />
            <Row l="Estimated system weight" v={`${fmt(weightKg / 1000, 2)} t`} t="estimated" />
          </Group>
          <Group title="Solar system">
            <Row l="Panel" v={`${p.panel.powerW} W ${p.panel.technology}`} t="user" />
            <Row l="Number of panels" v={String(stats.panelCount)} t="calculated" />
            <Row l="DC capacity" v={`${fmt(stats.dcKwp, 2)} kWp`} t="calculated" />
            <Row l="Inverter" v={p.electrical.enabled ? `${p.electrical.inverterQty} × ${p.electrical.inverter.acPowerKw} kW` : 'Not configured'} t={p.electrical.enabled ? 'user' : undefined} />
            <Row l="Tilt" v={tilts || '—'} t="user" />
            <Row l="Azimuth" v={azs || '—'} t="user" />
          </Group>
          <Group title="Solar resource">
            <Row l="Annual GHI" v={r ? `${fmt(r.monthly.reduce((s, m, i) => s + m.ghiKwhM2Day * DAYS_IN_MONTH[i], 0), 0)} kWh/m²` : 'Not loaded'} t={r ? src : undefined} />
            <Row l="Annual POA irradiation" v={a ? `${fmt(a.annualPoaKwhM2, 0)} kWh/m²` : '—'} t={a ? res : undefined} />
            <Row l="Peak sun hours" v={a ? `${fmt(a.annualPoaKwhM2 / 365, 2)} h/day` : '—'} t={a ? res : undefined} />
            <Row l="Data source" v={r?.providerLabel ?? '—'} t={r ? src : undefined} />
          </Group>
          <Group title="Energy">
            <Row l="Annual energy" v={a ? formatEnergyKwh(a.annualAcKwh) : '—'} t={a ? res : undefined} testId="dash-annual" />
            <Row l="Monthly average" v={a ? formatEnergyKwh(a.annualAcKwh / 12) : '—'} t={a ? res : undefined} />
            <Row l="Daily average" v={a ? formatEnergyKwh(a.annualAcKwh / 365) : '—'} t={a ? res : undefined} />
            <Row l="Specific yield" v={a ? `${fmt(a.specificYield, 0)} kWh/kWp` : '—'} t={a ? res : undefined} />
            <Row l="Performance ratio" v={a ? `${fmt(a.performanceRatio * 100, 1)} %` : '—'} t={a ? res : undefined} />
            <Row l="Capacity factor" v={a ? `${fmt(a.capacityFactorDc * 100, 1)} %` : '—'} t={a ? res : undefined} />
          </Group>
          <Group title="Design">
            <Row l="Roof utilisation" v={`${fmt(stats.utilizationPct, 1)} %`} t="calculated" />
            <Row l="Shading loss" v={shadingLoss ? `${fmt(shadingLoss.lossPct, 1)} %` : '—'} t={a ? res : undefined} />
            <Row l="Total system losses" v={a ? `${fmt((1 - a.annualAcKwh / a.lossStages[0].energyAfterKwh) * 100, 1)} %` : '—'} t={a ? res : undefined} />
            <Row l="Rows / row pitch" v={`${stats.rows} / ${Object.values(p.layout.pitchBySurface).map((x) => `${fmt(x, 2)} m`).join(', ') || '—'}`} t="calculated" />
          </Group>
          <Group title={`Warnings (${issues.length})`}>
            {issues.length === 0 ? <p className="text-[13px] text-char-700">No issues found by the automatic checks.</p> :
              <ul className="space-y-1">{issues.map((i) => <li key={i.message} className="text-[12.5px]"><span className={`mr-1 font-semibold ${i.level === 'error' ? 'text-alarm-600' : i.level === 'warning' ? 'text-[#8a6500]' : 'text-char-700'}`}>{i.area}:</span>{i.message}</li>)}</ul>}
          </Group>
        </div>
      </div>
    </div>
  );
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return <section className="rounded-[3px] border border-rule bg-white p-3" aria-label={title}><h3 className="mb-1.5 border-b-2 border-navy-800 pb-1 font-cond text-[13px] font-semibold uppercase tracking-wider text-navy-900">{title}</h3>{children}</section>;
}

function Row({ l, v, t, testId }: { l: string; v: string; t?: Provenance; testId?: string }) {
  return <div className="flex items-baseline justify-between gap-2 border-b border-dashed border-rule/80 py-1 text-[13px]"><span className="text-char-700">{l}</span><span className="flex items-center gap-1.5 text-right font-semibold" data-testid={testId}>{v}{t && <Tag kind={t} />}</span></div>;
}
