import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { NumberField, SelectField, KV, HowCalculated, Notice, Toggle, Grid2, fmt, TextField } from '@/components/ui';
import { INVERTER_LIBRARY } from '@/data/inverterLibrary';
import { suggestStringConfiguration, HOT_CELL_RISE_C } from '@/calculations/electrical';
import type { Electrical, InverterSpec } from '@/types';

export function ElectricalSection() {
  const { project: p, strings: r, stats } = useDerived();
  const { update, notify } = useStore.getState();
  const e = p.electrical;
  const set = (patch: Partial<Electrical>) => update((q) => ({ ...q, electrical: { ...q.electrical, ...patch }, analysis: null }));
  const setInv = (patch: Partial<InverterSpec>) => set({ inverter: { ...e.inverter, ...patch, id: 'custom', sourceNote: 'User-edited values.' } });

  return (
    <div className="space-y-3">
      <Notice tone="warning">This is a preliminary design calculation and must be verified by a qualified electrical engineer.</Notice>
      <Toggle label="Include inverter AC limit (clipping) in the energy analysis" checked={e.enabled} testId="electrical-enabled" onChange={(v) => set({ enabled: v })} />
      <SelectField label="Inverter" value={INVERTER_LIBRARY.some((i) => i.id === e.inverter.id) ? e.inverter.id : 'custom'}
        options={[...INVERTER_LIBRARY.map((i) => ({ value: i.id, label: i.model })), { value: 'custom', label: 'Custom inverter' }]}
        onChange={(id) => id !== 'custom' && set({ inverter: { ...INVERTER_LIBRARY.find((i) => i.id === id)! } })} />
      <p className="text-[11.5px] text-char-700">{e.inverter.sourceNote}</p>
      <Grid2>
        <TextField label="Model" value={e.inverter.model} onCommit={(v) => setInv({ model: v })} />
        <NumberField label="AC rating" unit="kW" value={e.inverter.acPowerKw} min={0.1} onCommit={(v) => v !== null && setInv({ acPowerKw: v })} tag="user" />
        <NumberField label="Max DC voltage" unit="V" value={e.inverter.maxDcVoltageV} min={10} onCommit={(v) => v !== null && setInv({ maxDcVoltageV: v })} />
        <NumberField label="MPPT count" value={e.inverter.mpptCount} min={1} max={40} onCommit={(v) => v !== null && setInv({ mpptCount: Math.round(v) })} />
        <NumberField label="MPPT min voltage" unit="V" value={e.inverter.mpptMinV} min={1} onCommit={(v) => v !== null && setInv({ mpptMinV: v })} />
        <NumberField label="MPPT max voltage" unit="V" value={e.inverter.mpptMaxV} min={1} onCommit={(v) => v !== null && setInv({ mpptMaxV: v })} />
        <NumberField label="Max current per MPPT" unit="A" value={e.inverter.maxInputCurrentPerMpptA} min={0.1} onCommit={(v) => v !== null && setInv({ maxInputCurrentPerMpptA: v })} />
        <NumberField label="Max efficiency" unit="%" value={e.inverter.maxEfficiencyPct} min={50} max={100} onCommit={(v) => v !== null && setInv({ maxEfficiencyPct: v })} />
      </Grid2>
      <h3 className="subhead">Configuration</h3>
      <Grid2>
        <NumberField label="Inverter quantity" value={e.inverterQty} min={1} max={1000} testId="inv-qty" onCommit={(v) => v !== null && set({ inverterQty: Math.round(v) })} tag="user" />
        <NumberField label="Modules per string" value={e.modulesPerString} min={1} max={60} onCommit={(v) => v !== null && set({ modulesPerString: Math.round(v) })} tag="user" />
        <NumberField label="Number of strings" value={e.stringsTotal} min={1} max={10000} onCommit={(v) => v !== null && set({ stringsTotal: Math.round(v) })} tag="user" />
        <NumberField label="Site minimum temperature" unit="°C" value={e.minAmbientC} min={-60} max={40} onCommit={(v) => v !== null && set({ minAmbientC: v })} tag="user" />
        <NumberField label="Site maximum temperature" unit="°C" value={e.maxAmbientC} min={0} max={60} onCommit={(v) => v !== null && set({ maxAmbientC: v })} tag="user" />
      </Grid2>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" disabled={!stats.panelCount} onClick={() => {
          const qty = Math.max(1, Math.round(stats.dcKwp / 1.2 / e.inverter.acPowerKw));
          set({ inverterQty: qty });
          notify(`${qty} inverter(s) for a DC/AC ratio near 1.2`, 'info');
        }}>Size inverter quantity (DC/AC ≈ 1.2)</button>
        <button className="btn btn-secondary" disabled={!stats.panelCount} onClick={() => {
          const s = suggestStringConfiguration(p.panel, e.inverter, e.inverterQty, stats.panelCount, e.minAmbientC, e.maxAmbientC);
          if (!s) { notify('No valid string length for this panel and inverter.', 'error'); return; }
          set({ modulesPerString: s.modulesPerString, stringsTotal: s.stringsTotal });
          notify(`${s.stringsTotal} strings × ${s.modulesPerString} modules (${s.unassigned} unassigned)`, 'info');
        }}>Suggest strings</button>
      </div>
      <h3 className="subhead">Results</h3>
      <KV label="Module Voc at min. temperature" value={`${fmt(r.vocColdModuleV, 2)} V`} tag="calculated" />
      <KV label="String Voc (STC / cold)" value={`${fmt(r.stringVocStcV, 0)} V / ${fmt(r.stringVocColdV, 0)} V`} tag="calculated">
        <HowCalculated formula="Voc,cold = n × Voc,STC × [1 + βVoc (Tmin − 25 °C)]" lines={[{ label: 'n', value: String(e.modulesPerString) }, { label: 'Voc,STC', value: `${p.panel.vocV} V` }, { label: 'βVoc', value: `${p.panel.tempCoeffVocPctPerC} %/°C` }, { label: 'Tmin', value: `${e.minAmbientC} °C (cell ≈ ambient at dawn)` }]} result={`${fmt(r.stringVocColdV, 1)} V (limit ${e.inverter.maxDcVoltageV} V)`} />
      </KV>
      <KV label="String Vmp (STC / hot)" value={`${fmt(r.stringVmpStcV, 0)} V / ${fmt(r.stringVmpHotV, 0)} V`} tag="calculated">
        <HowCalculated formula="Vmp,hot = n × Vmp,STC × [1 + βVoc (Tamb,max + 30 − 25)]" lines={[{ label: 'Hot cell temperature', value: `${e.maxAmbientC + HOT_CELL_RISE_C} °C (assumption: +${HOT_CELL_RISE_C} °C)` }, { label: 'MPPT window', value: `${e.inverter.mpptMinV}-${e.inverter.mpptMaxV} V` }]} result={`${fmt(r.stringVmpHotV, 1)} V`} note="βVoc is used as a proxy for the Vmp coefficient." />
      </KV>
      <KV label="String Isc / Imp" value={`${fmt(r.stringIscA, 2)} A / ${fmt(r.stringImpA, 2)} A`} tag="calculated" />
      <KV label="Valid modules per string" value={`${r.minModulesPerString}-${r.maxModulesPerString}`} tag="calculated" />
      <KV label="Strings per inverter / per MPPT" value={`${fmt(r.stringsPerInverter, 1)} / ${r.stringsPerMppt}`} tag="calculated" />
      <KV label="DC capacity in strings" value={`${fmt(r.dcKwp, 2)} kWp`} tag="calculated" />
      <KV label="AC capacity" value={`${fmt(r.acKw, 1)} kW`} tag="calculated" />
      <KV label="DC/AC ratio" value={fmt(r.dcAcRatio, 2)} tag="calculated">
        <HowCalculated formula="DC/AC = modules in strings × P_module / (inverters × P_AC)" lines={[{ label: 'DC', value: `${fmt(r.dcKwp, 2)} kWp` }, { label: 'AC', value: `${fmt(r.acKw, 1)} kW` }]} result={fmt(r.dcAcRatio, 3)} />
      </KV>
      {r.warnings.map((w) => <Notice key={w.message} tone={w.level === 'error' ? 'error' : 'warning'}>{w.message}</Notice>)}
    </div>
  );
}
