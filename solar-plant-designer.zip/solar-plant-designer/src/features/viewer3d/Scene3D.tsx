import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { OrbitControls, Line } from '@react-three/drei';
import * as THREE from 'three';
import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { surfaceHeightAt, type InstallSurface } from '@/calculations/structure';
import { orientedDims, moduleDims } from '@/calculations/panelLayout';
import { calculateSolarPosition, sunPathForDay } from '@/calculations/solarPosition';
import { sunVector3, surfaceAt } from '@/calculations/shading';
import { bbox, obstacleFootprint } from '@/calculations/geometry';
import type { Obstacle, Vec2 } from '@/types';

/** Plan (x east, y north, z up) → three.js (x east, y up, z = −north). */
const P = (p: Vec2, z: number) => new THREE.Vector3(p.x, z, -p.y);

export function Scene3D() {
  const { project: p, surfaces, mounts } = useDerived();
  const sun = useStore((s) => s.sun);
  const camera = useStore((s) => s.camera);
  const b = p.structure.boundary.length ? bbox(p.structure.boundary) : { minX: 0, minY: 0, maxX: 10, maxY: 10 };
  const center = new THREE.Vector3((b.minX + b.maxX) / 2, 0, -(b.minY + b.maxY) / 2);
  const span = Math.max(10, b.maxX - b.minX, b.maxY - b.minY);
  const pos = calculateSolarPosition(p.location.latitude, p.location.longitude, sun.doy, sun.clockHour, p.location.utcOffsetHours);
  const sv = sunVector3(Math.max(pos.elevationDeg, -5), pos.azimuthDeg);
  const sunDist = span * 1.6;
  const sunPoint = new THREE.Vector3(center.x + sv[0] * sunDist, sv[1] * sunDist, center.z + sv[2] * sunDist);
  const up = pos.elevationDeg > 0;

  return (
    <div className="relative h-full w-full bg-[#dfe6ee]" data-testid="scene-3d">
      <Canvas shadows camera={{ position: [center.x + span * 1.15, span * 1.0, center.z + span * 1.4], fov: 45, near: 0.1, far: span * 30 }} gl={{ preserveDrawingBuffer: true, antialias: true }}>
        <color attach="background" args={['#dfe6ee']} />
        <hemisphereLight args={['#ffffff', '#8a9096', up ? 0.55 : 0.35]} />
        {up && (
          <directionalLight castShadow position={sunPoint} intensity={2.2} shadow-mapSize={[2048, 2048]} shadow-bias={-0.0004}
            shadow-camera-left={-span} shadow-camera-right={span} shadow-camera-top={span} shadow-camera-bottom={-span} shadow-camera-near={0.5} shadow-camera-far={sunDist * 3}>
            <object3D attach="target" position={center} />
          </directionalLight>
        )}
        <mesh position={sunPoint}><sphereGeometry args={[span * 0.03, 16, 16]} /><meshBasicMaterial color={up ? '#F5B700' : '#7a808a'} /></mesh>
        <SunPath lat={p.location.latitude} lon={p.location.longitude} doy={sun.doy} tz={p.location.utcOffsetHours} center={center} r={sunDist} />
        <Ground center={center} span={span} />
        <Building surfaces={surfaces} boundary={p.structure.boundary} roofType={p.structure.roofType} eave={p.structure.eaveHeightM} parapet={p.structure.parapetHeightM} />
        <Panels />
        {p.obstacles.map((o) => <ObstacleMesh key={o.id} o={o} surfaces={surfaces} eave={p.structure.eaveHeightM} />)}
        <Compass center={center} span={span} />
        <OrbitControls makeDefault target={center} maxPolarAngle={Math.PI / 2 - 0.02} />
        <CameraRig command={camera} center={center} span={span} />
      </Canvas>
      <ViewButtons />
      <div className="absolute left-3 top-3 rounded-[3px] border border-rule bg-white/90 px-2 py-1 text-[11.5px]">
        Sun {up ? `elev ${pos.elevationDeg.toFixed(1)}° · az ${pos.azimuthDeg.toFixed(1)}°` : 'below horizon'} · {mounts && Object.keys(mounts).length} surface(s) · {p.layout.panels.length} panels
      </div>
    </div>
  );
}

function ViewButtons() {
  const { set } = useStore.getState();
  const cam = useStore((s) => s.camera);
  const go = (kind: 'reset' | 'top' | 'front' | 'side') => set({ camera: { kind, n: cam.n + 1 } });
  return (
    <div className="absolute bottom-3 right-3 flex gap-1" role="toolbar" aria-label="3D camera">
      {(['reset', 'top', 'front', 'side'] as const).map((k) => <button key={k} className="btn btn-secondary px-2 py-1 text-[12px] capitalize" onClick={() => go(k)}>{k === 'front' ? 'Front (south)' : k === 'side' ? 'Side (east)' : k}</button>)}
    </div>
  );
}

function CameraRig({ command, center, span }: { command: { kind: string; n: number }; center: THREE.Vector3; span: number }) {
  const { camera, controls } = useThree() as unknown as { camera: THREE.PerspectiveCamera; controls: { target: THREE.Vector3; update: () => void } | null };
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    const d = span * 1.5;
    const posMap: Record<string, [number, number, number]> = {
      reset: [center.x + span * 1.15, span * 1.0, center.z + span * 1.4],
      top: [center.x, d * 1.2, center.z + 0.01],
      front: [center.x, span * 0.25, center.z + d],
      side: [center.x + d, span * 0.25, center.z],
    };
    camera.position.set(...posMap[command.kind]);
    if (controls) { controls.target.copy(center); controls.update(); }
    camera.lookAt(center);
  }, [command.n]); // eslint-disable-line react-hooks/exhaustive-deps
  return null;
}

function Ground({ center, span }: { center: THREE.Vector3; span: number }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[center.x, -0.01, center.z]} receiveShadow>
      <planeGeometry args={[span * 6, span * 6]} />
      <meshStandardMaterial color="#b9c2a8" />
    </mesh>
  );
}

function Compass({ center, span }: { center: THREE.Vector3; span: number }) {
  const r = span * 0.75;
  const labels: [string, number, number][] = [['N', 0, -r], ['S', 0, r], ['E', r, 0], ['W', -r, 0]];
  return (
    <group position={[center.x, 0.05, center.z]}>
      {labels.map(([t, x, z]) => <GroundLabel key={t} text={t} position={[x, 0.02, z]} size={span * 0.1} color={t === 'N' ? '#D23B30' : '#1F3452'} />)}
    </group>
  );
}

/** Text drawn into a canvas texture - no font download needed (works offline). */
function GroundLabel({ text, position, size, color }: { text: string; position: [number, number, number]; size: number; color: string }) {
  const tex = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const ctx = c.getContext('2d')!;
    ctx.font = 'bold 96px Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = color;
    ctx.fillText(text, 64, 70);
    const t = new THREE.CanvasTexture(c);
    t.anisotropy = 4;
    return t;
  }, [text, color]);
  useEffect(() => () => tex.dispose(), [tex]);
  return (
    <mesh position={position} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[size, size]} />
      <meshBasicMaterial map={tex} transparent depthWrite={false} />
    </mesh>
  );
}

function SunPath({ lat, lon, doy, tz, center, r }: { lat: number; lon: number; doy: number; tz: number; center: THREE.Vector3; r: number }) {
  const pts = useMemo(() => sunPathForDay(lat, lon, doy, tz, 10).map((s) => {
    const v = sunVector3(s.elevationDeg, s.azimuthDeg);
    return new THREE.Vector3(center.x + v[0] * r, v[1] * r, center.z + v[2] * r);
  }), [lat, lon, doy, tz, center.x, center.z, r]);
  if (pts.length < 2) return null;
  return <Line points={pts} color="#F5B700" lineWidth={1.5} dashed dashSize={r * 0.02} gapSize={r * 0.015} />;
}

/** Walls + roof planes + gable/high-side infill + parapets. */
function Building({ surfaces, boundary, roofType, eave, parapet }: { surfaces: InstallSurface[]; boundary: Vec2[]; roofType: string; eave: number; parapet: number }) {
  const walls = useMemo(() => {
    if (roofType === 'ground' || roofType === 'canopy' || boundary.length < 3 || eave <= 0) return null;
    const shape = new THREE.Shape(boundary.map((q) => new THREE.Vector2(q.x, q.y)));
    const g = new THREE.ExtrudeGeometry(shape, { depth: eave, bevelEnabled: false });
    g.rotateX(-Math.PI / 2);
    return g;
  }, [boundary, roofType, eave]);

  const roofGeoms = useMemo(() => surfaces.map((s) => {
    const contour = s.polygon.map((q) => new THREE.Vector2(q.x, q.y));
    const tris = THREE.ShapeUtils.triangulateShape(contour, []);
    const pos: number[] = [];
    for (const t of tris) for (const i of t) { const q = s.polygon[i]; pos.push(q.x, surfaceHeightAt(s, q) + 0.001, -q.y); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.computeVertexNormals();
    // infill walls between eave and sloped plane edges
    const inf: number[] = [];
    if (roofType === 'shed' || roofType === 'gable') {
      for (let i = 0; i < s.polygon.length; i++) {
        const a = s.polygon[i], c = s.polygon[(i + 1) % s.polygon.length];
        const ha = surfaceHeightAt(s, a), hc = surfaceHeightAt(s, c);
        if (ha - s.baseZ < 0.01 && hc - s.baseZ < 0.01) continue;
        inf.push(a.x, s.baseZ, -a.y, c.x, s.baseZ, -c.y, c.x, hc, -c.y, a.x, s.baseZ, -a.y, c.x, hc, -c.y, a.x, ha, -a.y);
      }
    }
    const gi = new THREE.BufferGeometry();
    gi.setAttribute('position', new THREE.Float32BufferAttribute(inf, 3));
    gi.computeVertexNormals();
    return { id: s.id, roof: g, infill: gi, kind: s.kind };
  }), [surfaces, roofType]);

  const posts = useMemo(() => {
    if (roofType !== 'canopy') return [];
    const out: { p: Vec2; h: number }[] = [];
    for (const s of surfaces) for (const q of s.polygon) out.push({ p: q, h: surfaceHeightAt(s, q) });
    return out;
  }, [surfaces, roofType]);

  return (
    <group>
      {walls && <mesh geometry={walls} castShadow receiveShadow><meshStandardMaterial color="#d9dcdf" /></mesh>}
      {roofGeoms.map((r) => (
        <group key={r.id}>
          <mesh geometry={r.roof} castShadow receiveShadow><meshStandardMaterial color={r.kind === 'ground' ? '#a8b392' : '#9aa3ad'} side={THREE.DoubleSide} /></mesh>
          <mesh geometry={r.infill} castShadow receiveShadow><meshStandardMaterial color="#cfd3d7" side={THREE.DoubleSide} /></mesh>
        </group>
      ))}
      {posts.map((q, i) => <mesh key={i} position={[q.p.x, q.h / 2, -q.p.y]} castShadow><boxGeometry args={[0.2, q.h, 0.2]} /><meshStandardMaterial color="#6b7480" /></mesh>)}
      {parapet > 0 && roofType !== 'ground' && roofType !== 'canopy' && boundary.map((a, i) => {
        const c = boundary[(i + 1) % boundary.length];
        const L = Math.hypot(c.x - a.x, c.y - a.y);
        const ang = Math.atan2(c.y - a.y, c.x - a.x);
        return <mesh key={i} position={[(a.x + c.x) / 2, eave + parapet / 2, -(a.y + c.y) / 2]} rotation={[0, ang, 0]} castShadow receiveShadow><boxGeometry args={[L, parapet, 0.2]} /><meshStandardMaterial color="#c9cdd2" /></mesh>;
      })}
    </group>
  );
}

function Panels() {
  const { project: p, surfaces, mounts } = useDerived();
  const ref = useRef<THREE.InstancedMesh>(null);
  const legs = useRef<THREE.InstancedMesh>(null);
  const dims = moduleDims(p.panel);
  const byId = useMemo(() => new Map(surfaces.map((s) => [s.id, s])), [surfaces]);
  const panels = p.layout.panels;
  const legData = useMemo(() => {
    const out: { x: number; y: number; z0: number; h: number }[] = [];
    for (const pn of panels) {
      const s = byId.get(pn.surfaceId);
      if (!s || !mounts[s.id]?.racked || pn.stackIndex !== 0) continue;
      const od = orientedDims(dims, pn.orientation);
      const k = Math.max(1, Math.round(p.mounting.modulesHigh));
      const slant = k * od.slant + (k - 1) * p.mounting.moduleGapM;
      const t = (pn.tiltDeg * Math.PI) / 180;
      const f = { x: Math.sin((pn.azimuthDeg * Math.PI) / 180), y: Math.cos((pn.azimuthDeg * Math.PI) / 180) };
      const front = { x: pn.center.x + f.x * (od.slant * Math.cos(t)) / 2, y: pn.center.y + f.y * (od.slant * Math.cos(t)) / 2 };
      const back = { x: front.x - f.x * slant * Math.cos(t), y: front.y - f.y * slant * Math.cos(t) };
      const zf = surfaceHeightAt(s, front), zb = surfaceHeightAt(s, back);
      out.push({ x: front.x, y: front.y, z0: zf, h: p.mounting.clearanceM });
      out.push({ x: back.x, y: back.y, z0: zb, h: p.mounting.clearanceM + slant * Math.sin(t) });
    }
    return out;
  }, [panels, byId, mounts, dims, p.mounting]);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(0, 0, 0, 'YXZ'), sc = new THREE.Vector3(1, 1, 1);
    panels.forEach((pn, i) => {
      const s = byId.get(pn.surfaceId) ?? surfaceAt(surfaces, pn.center) ?? undefined;
      const racked = s ? mounts[s.id]?.racked : false;
      const od = orientedDims(dims, pn.orientation);
      const t = (pn.tiltDeg * Math.PI) / 180;
      const base = s ? surfaceHeightAt(s, pn.center) : p.structure.eaveHeightM;
      const z = racked ? base + p.mounting.clearanceM + (pn.stackIndex + 0.5) * (od.slant + p.mounting.moduleGapM) * Math.sin(t) : base + 0.1 + (od.slant / 2) * Math.sin(t) * 0; // flush: sits on plane
      e.set(t, Math.PI - (pn.azimuthDeg * Math.PI) / 180, 0, 'YXZ');
      q.setFromEuler(e);
      m.compose(new THREE.Vector3(pn.center.x, z + 0.02, -pn.center.y), q, sc.set(od.alongRow * 0.99, 1, od.slant * 0.99));
      mesh.setMatrixAt(i, m);
    });
    mesh.count = panels.length;
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    const lg = legs.current;
    if (lg) {
      legData.forEach((l, i) => { m.compose(new THREE.Vector3(l.x, l.z0 + l.h / 2, -l.y), new THREE.Quaternion(), new THREE.Vector3(1, Math.max(0.01, l.h), 1)); lg.setMatrixAt(i, m); });
      lg.count = legData.length;
      lg.instanceMatrix.needsUpdate = true;
      lg.computeBoundingSphere();
    }
  }, [panels, byId, surfaces, mounts, dims, p.mounting, p.structure.eaveHeightM, legData]);

  const cap = Math.max(1, panels.length);
  return (
    <group>
      <instancedMesh key={`pn-${cap}`} ref={ref} args={[undefined, undefined, cap]} castShadow receiveShadow>
        <boxGeometry args={[1, 0.04, 1]} />
        <meshStandardMaterial color="#1f4fc9" metalness={0.35} roughness={0.35} />
      </instancedMesh>
      <instancedMesh key={`lg-${legData.length}`} ref={legs} args={[undefined, undefined, Math.max(1, legData.length)]} castShadow>
        <boxGeometry args={[0.05, 1, 0.05]} />
        <meshStandardMaterial color="#8d949c" metalness={0.6} roughness={0.4} />
      </instancedMesh>
    </group>
  );
}

function ObstacleMesh({ o, surfaces, eave }: { o: Obstacle; surfaces: InstallSurface[]; eave: number }) {
  const s = o.base === 'roof' ? surfaceAt(surfaces, o.center) : null;
  const baseZ = o.base === 'ground' ? 0 : s ? surfaceHeightAt(s, o.center) : eave;
  const rot = (o.rotationDeg * Math.PI) / 180;
  if (o.kind === 'exclusion' || o.kind === 'walkway' || o.kind === 'skylight' || o.heightM <= 0) {
    const fp = obstacleFootprint(o, 0);
    const shape = new THREE.Shape(fp.map((q) => new THREE.Vector2(q.x, q.y)));
    return (
      <mesh position={[0, baseZ + 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <shapeGeometry args={[shape]} />
        <meshStandardMaterial color={o.kind === 'walkway' ? '#2E9E5B' : o.kind === 'skylight' ? '#a9d4f5' : '#F5B700'} transparent opacity={0.8} side={THREE.DoubleSide} />
      </mesh>
    );
  }
  if (o.kind === 'tree') {
    const trunk = o.heightM * 0.4;
    return (
      <group position={[o.center.x, baseZ, -o.center.y]}>
        <mesh position={[0, trunk / 2, 0]} castShadow><cylinderGeometry args={[0.2, 0.3, trunk, 8]} /><meshStandardMaterial color="#6b4f35" /></mesh>
        <mesh position={[0, trunk + (o.heightM - trunk) / 2, 0]} castShadow><sphereGeometry args={[o.widthM / 2, 14, 12]} /><meshStandardMaterial color="#3f7d3a" /></mesh>
      </group>
    );
  }
  const color = o.kind === 'nearby-structure' ? '#b5b0a6' : '#c7564d';
  return (
    <mesh position={[o.center.x, baseZ + o.heightM / 2, -o.center.y]} rotation={[0, rot, 0]} castShadow receiveShadow>
      {o.shape === 'circle' ? <cylinderGeometry args={[o.widthM / 2, o.widthM / 2, o.heightM, 20]} /> : <boxGeometry args={[o.widthM, o.heightM, o.depthM]} />}
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

export { P };
