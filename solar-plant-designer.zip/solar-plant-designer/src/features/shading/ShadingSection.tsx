import { useEffect, useMemo, useState } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid, ReferenceDot } from 'recharts';
import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { KV, Toggle, HowCalculated, Notice, fmt } from '@/components/ui';
import { calculateSolarPosition, calculateSunriseSunset, formatClock, formatDuration, sunPathForDay, MONTH_NAMES, dayOfYear, solarToClock, winterSolsticeDoy, summerSolsticeDoy } from '@/calculations/solarPosition';
import { buildShadowCasters, buildShadingScene, computeObstacleShading, interRowShadedFraction, calculateShadowLength, shadowDirectionDeg } from '@/calculations/shading';
import { parapetSegments } from '@/calculations/structure';
import { moduleDims, orientedDims } from '@/calculations/panelLayout';

const KEY_DAYS = (lat: number) => [
  { label: 'Winter solstice', doy: winterSolsticeDoy(lat) },
  { label: 'March equinox', doy: 80 },
  { label: 'Summer solstice', doy: summerSolsticeDoy(lat) },
  { label: 'September equinox', doy: 266 },
];

export function ShadingSection() {
  const { project: p, surfaces, mounts } = useDerived();
  const sun = useStore((s) => s.sun);
  const playing = useStore((s) => s.playing);
  const showShadows = useStore((s) => s.showShadows);
  const { set } = useStore.getState();
  const loc = p.location;
  const times = calculateSunriseSunset(loc.latitude, loc.longitude, sun.doy, loc.utcOffsetHours);
  const pos = calculateSolarPosition(loc.latitude, loc.longitude, sun.doy, sun.clockHour, loc.utcOffsetHours);
  const date = new Date(Date.UTC(2023, 0, sun.doy));
  const month = date.getUTCMonth(), day = date.getUTCDate();
  const [seasonal, setSeasonal] = useState<{ label: string; cells: { t: string; pct: number | null }[] }[] | null>(null);

  // PLAY SUN PATH: advance 6 minutes every 80 ms from sunrise to sunset
  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => {
      const st = useStore.getState();
      const t = calculateSunriseSunset(st.project.location.latitude, st.project.location.longitude, st.sun.doy, st.project.location.utcOffsetHours);
      const start = t.sunrise ?? 0, end = t.sunset ?? 24;
      let h = st.sun.clockHour + 0.1;
      if (h > end || h < start) h = start;
      st.set({ sun: { ...st.sun, clockHour: h } });
    }, 80);
    return () => window.clearInterval(id);
  }, [playing]);

  const setClock = (h: number) => set({ sun: { ...sun, clockHour: Math.max(0, Math.min(23.99, h)) } });
  const setDoy = (d: number) => set({ sun: { ...sun, doy: Math.max(1, Math.min(365, Math.round(d))) } });

  const chart = useMemo(() => {
    const series = [...KEY_DAYS(loc.latitude).slice(0, 3), { label: 'Selected date', doy: sun.doy }];
    const rows = new Map<number, Record<string, number>>();
    for (const s of series) for (const q of sunPathForDay(loc.latitude, loc.longitude, s.doy, loc.utcOffsetHours, 15)) {
      const k = Math.round(q.azimuthDeg);
      rows.set(k, { ...(rows.get(k) ?? { az: k }), [s.label]: +q.elevationDeg.toFixed(2) });
    }
    return { data: [...rows.values()].sort((a, b) => a.az - b.az), series: series.map((s) => s.label) };
  }, [loc, sun.doy]);

  const runSeasonal = () => {
    const dims = moduleDims(p.panel);
    const casters = buildShadowCasters(p.obstacles, surfaces, parapetSegments(p.structure), p.structure.parapetHeightM, p.structure.eaveHeightM);
    const racked = Object.fromEntries(surfaces.map((s) => [s.id, mounts[s.id]?.racked ?? false]));
    const scene = buildShadingScene(p.layout.panels, dims, surfaces, casters, p.mounting.clearanceM, racked);
    const k = Math.max(1, Math.round(p.mounting.modulesHigh));
    const slant = k * orientedDims(dims, p.mounting.orientation).slant + (k - 1) * p.mounting.moduleGapM;
    const frontRow = new Map<string, number>();
    p.layout.panels.forEach((pn) => { if (pn.row >= 0) frontRow.set(pn.surfaceId, Math.min(frontRow.get(pn.surfaceId) ?? Infinity, pn.row)); });
    const out = KEY_DAYS(loc.latitude).map((d) => ({
      label: d.label,
      cells: [9, 12, 15].map((solarH) => {
        const clock = solarToClock(solarH, loc.longitude, loc.utcOffsetHours, d.doy);
        const sp = calculateSolarPosition(loc.latitude, loc.longitude, d.doy, clock, loc.utcOffsetHours);
        if (sp.elevationDeg <= 0 || !p.layout.panels.length) return { t: formatClock(clock), pct: null };
        const f = computeObstacleShading(scene, sp.elevationDeg, sp.azimuthDeg);
        let sum = 0;
        p.layout.panels.forEach((pn, i) => {
          let s = f[i];
          if (racked[pn.surfaceId] && pn.row >= 0 && pn.row !== frontRow.get(pn.surfaceId)) {
            const fr = interRowShadedFraction(sp.elevationDeg, sp.azimuthDeg, pn.tiltDeg, pn.azimuthDeg, slant, p.layout.pitchBySurface[pn.surfaceId] ?? slant, mounts[pn.surfaceId]?.terrainSlopeDeg ?? 0);
            s = Math.max(s, Math.max(0, Math.min(1, fr * k - pn.stackIndex)));
          }
          sum += s;
        });
        return { t: formatClock(clock), pct: (sum / p.layout.panels.length) * 100 };
      }),
    }));
    setSeasonal(out);
  };

  return (
    <div className="space-y-3">
      <Toggle label="Show shadows on plan and 3D" checked={showShadows} onChange={(v) => set({ showShadows: v })} />
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="sun-month">Month</label>
          <select id="sun-month" className="input" value={month} onChange={(e) => setDoy(dayOfYear(2023, +e.target.value, Math.min(day, 28)))}>
            {MONTH_NAMES.map((m, i) => <option key={m} value={i}>{m}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="sun-day">Day</label>
          <input id="sun-day" className="input" type="number" min={1} max={31} value={day} onChange={(e) => setDoy(dayOfYear(2023, month, Math.max(1, Math.min(31, +e.target.value || 1))))} />
        </div>
      </div>
      <div>
        <label className="label" htmlFor="sun-time">Time (local standard) · {formatClock(sun.clockHour)}</label>
        <input id="sun-time" data-testid="sun-time" type="range" min={0} max={23.9} step={0.05} value={sun.clockHour} onChange={(e) => setClock(+e.target.value)} className="w-full accent-sun-500" />
      </div>
      <div className="flex flex-wrap gap-1.5">
        <button className="btn btn-secondary" onClick={() => setClock(solarToClock(9, loc.longitude, loc.utcOffsetHours, sun.doy))}>Morning (09:00 solar)</button>
        <button className="btn btn-secondary" onClick={() => setClock(times.solarNoon)}>Noon</button>
        <button className="btn btn-secondary" onClick={() => setClock(solarToClock(15, loc.longitude, loc.utcOffsetHours, sun.doy))}>Afternoon (15:00 solar)</button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {KEY_DAYS(loc.latitude).map((d) => <button key={d.label} className="btn btn-ghost border border-rule px-2 py-1 text-[12px]" onClick={() => setDoy(d.doy)}>{d.label}</button>)}
      </div>
      <button className={`btn w-full ${playing ? 'btn-dark' : 'btn-primary'}`} data-testid="play-sun" onClick={() => set({ playing: !playing })}>{playing ? 'Pause sun path' : 'Play sun path'}</button>

      <h3 className="subhead">Sun at selected time</h3>
      <KV label="Solar elevation" value={`${fmt(pos.elevationDeg, 2)}°`} tag="calculated">
        <HowCalculated formula={'sin(elev) = sin φ sin δ + cos φ cos δ cos H\nH = 15° × (true solar time − 12 h)'} lines={[{ label: 'Latitude φ', value: `${loc.latitude.toFixed(4)}°` }, { label: 'Declination δ', value: `${fmt(pos.declinationDeg, 3)}°` }, { label: 'Equation of time', value: `${fmt(pos.equationOfTimeMin, 2)} min` }, { label: 'Hour angle H', value: `${fmt(pos.hourAngleDeg, 2)}°` }]} result={`${fmt(pos.elevationDeg, 2)}° (apparent ${fmt(pos.apparentElevationDeg, 2)}°)`} note="NOAA general solar position equations." />
      </KV>
      <KV label="Solar azimuth" value={`${fmt(pos.azimuthDeg, 2)}°`} tag="calculated" />
      <KV label="Sunrise / sunset" value={`${formatClock(times.sunrise)} / ${formatClock(times.sunset)}`} tag="calculated" />
      <KV label="Solar noon" value={formatClock(times.solarNoon)} tag="calculated" />
      <KV label="Day length" value={formatDuration(times.dayLengthHours)} tag="calculated" />
      {pos.elevationDeg > 0 && <KV label="Shadow of a 1 m object" value={`${fmt(calculateShadowLength(1, pos.elevationDeg), 2)} m toward ${fmt(shadowDirectionDeg(pos.azimuthDeg), 0)}°`} tag="calculated" />}
      {times.polar && <Notice tone="info">Polar {times.polar} on this date.</Notice>}

      <h3 className="subhead">Sun path diagram</h3>
      <div className="h-56 rounded-[3px] border border-rule bg-white p-1" aria-label="Sun path: elevation against azimuth">
        <ResponsiveContainer>
          <LineChart data={chart.data} margin={{ top: 6, right: 8, bottom: 14, left: -8 }}>
            <CartesianGrid stroke="#e5e8ec" />
            <XAxis dataKey="az" type="number" domain={[0, 360]} ticks={[0, 90, 180, 270, 360]} tick={{ fontSize: 10 }} label={{ value: 'Azimuth (°)', position: 'insideBottom', offset: -6, fontSize: 10 }} />
            <YAxis domain={[0, 90]} tick={{ fontSize: 10 }} label={{ value: 'Elevation (°)', angle: -90, position: 'insideLeft', offset: 18, fontSize: 10 }} />
            <Tooltip formatter={(v: number) => `${v}°`} labelFormatter={(l) => `Azimuth ${l}°`} />
            <Legend wrapperStyle={{ fontSize: 10 }} />
            {chart.series.map((s, i) => <Line key={s} dataKey={s} dot={false} connectNulls stroke={['#1F3452', '#2E9E5B', '#D23B30', '#F5B700'][i]} strokeWidth={s === 'Selected date' ? 2.5 : 1.5} isAnimationActive={false} />)}
            {pos.elevationDeg > 0 && <ReferenceDot x={Math.round(pos.azimuthDeg)} y={pos.elevationDeg} r={5} fill="#F5B700" stroke="#0E1B2E" />}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <h3 className="subhead">Seasonal shading analysis</h3>
      <button className="btn btn-secondary w-full" disabled={!p.layout.panels.length} onClick={runSeasonal}>Analyse morning / noon / afternoon for four key dates</button>
      {seasonal && (
        <table className="table-eng bg-white">
          <thead><tr><th>Date</th><th className="num">09:00 solar</th><th className="num">12:00 solar</th><th className="num">15:00 solar</th></tr></thead>
          <tbody>
            {seasonal.map((r) => <tr key={r.label}><td>{r.label}</td>{r.cells.map((c, i) => <td key={i} className="num" title={`clock ${c.t}`}>{c.pct === null ? 'sun down' : `${fmt(c.pct, 1)} %`}</td>)}</tr>)}
          </tbody>
        </table>
      )}
      {seasonal && <p className="text-[11.5px] text-char-700">Average share of module area shaded by obstacles, parapets and the row in front (beam shading geometry only). Hover a cell for local clock time.</p>}
    </div>
  );
}
