import { useStore, type Tool } from '@/store/projectStore';
import { OBSTACLE_TYPES } from '@/data/obstacleTypes';
import { NumberField } from '@/components/ui';
import { polygonArea } from '@/calculations/geometry';
import { formatArea } from '@/calculations/units';

const DRAW_TOOLS: { tool: Tool; label: string; hint: string }[] = [
  { tool: 'select', label: 'Select / move', hint: 'Click to select, drag to move, drag empty space to box-select panels' },
  { tool: 'pan', label: 'Pan', hint: 'Drag to pan. Mouse wheel zooms.' },
  { tool: 'rect-boundary', label: 'Draw rectangle boundary', hint: 'Drag a rectangle for the roof or land outline' },
  { tool: 'poly-boundary', label: 'Draw polygon boundary', hint: 'Click corners; click the first point, double-click or press Enter to close. Esc cancels.' },
  { tool: 'rect-exclusion', label: 'Draw exclusion zone', hint: 'Drag a rectangle that must stay free of panels' },
  { tool: 'rect-walkway', label: 'Draw walkway', hint: 'Drag a maintenance walkway rectangle' },
];

export function RoofSection() {
  const tool = useStore((s) => s.tool);
  const obstacles = useStore((s) => s.project.obstacles);
  const boundary = useStore((s) => s.project.structure.boundary);
  const selection = useStore((s) => s.selection);
  const { set, update } = useStore.getState();
  const current = DRAW_TOOLS.find((t) => t.tool === tool);

  return (
    <div className="space-y-3">
      <div role="toolbar" aria-label="Drawing tools" className="grid grid-cols-2 gap-1.5">
        {DRAW_TOOLS.map((t) => (
          <button key={t.tool} data-testid={`tool-${t.tool}`} aria-pressed={tool === t.tool} className={`btn justify-start text-left ${tool === t.tool ? 'bg-navy-800 text-white' : 'btn-secondary'}`} onClick={() => set({ tool: t.tool })}>{t.label}</button>
        ))}
      </div>
      {current && <p className="text-[12px] text-char-700">{current.hint}</p>}
      <h3 className="subhead">Place obstacle</h3>
      <div className="grid grid-cols-2 gap-1.5">
        {OBSTACLE_TYPES.filter((o) => o.kind !== 'exclusion' && o.kind !== 'walkway').map((o) => (
          <button key={o.kind} data-testid={`place-${o.kind}`} aria-pressed={tool === `place:${o.kind}`} className={`btn justify-start ${tool === `place:${o.kind}` ? 'bg-navy-800 text-white' : 'btn-secondary'}`} onClick={() => set({ tool: `place:${o.kind}` as Tool })}>
            <span className={`h-2.5 w-2.5 shrink-0 ${o.kind === 'tree' ? 'rounded-full bg-leaf-500' : 'bg-alarm-600'}`} />{o.label}
          </button>
        ))}
      </div>
      <p className="text-[12px] text-char-700">Then click on the plan. Default sizes are placeholders - edit dimensions in the properties panel.</p>

      <h3 className="subhead">Boundary · {boundary.length} vertices · {formatArea(polygonArea(boundary), 'm')}</h3>
      <button className="btn btn-secondary w-full" onClick={() => set({ selection: { kind: 'boundary', ids: [] }, tool: 'select' })}>Edit boundary vertices</button>
      <div className="max-h-44 overflow-auto">
        <table className="table-eng">
          <thead><tr><th>#</th><th className="num">x (m, east)</th><th className="num">y (m, north)</th></tr></thead>
          <tbody>
            {boundary.map((pt, i) => (
              <tr key={i}>
                <td>{i + 1}</td>
                <td className="num"><VertexInput value={pt.x} onCommit={(x) => update((p) => ({ ...p, structure: { ...p.structure, boundary: p.structure.boundary.map((q, j) => (j === i ? { ...q, x } : q)) } }))} label={`Vertex ${i + 1} x`} /></td>
                <td className="num"><VertexInput value={pt.y} onCommit={(y) => update((p) => ({ ...p, structure: { ...p.structure, boundary: p.structure.boundary.map((q, j) => (j === i ? { ...q, y } : q)) } }))} label={`Vertex ${i + 1} y`} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h3 className="subhead">Obstacles and zones ({obstacles.length})</h3>
      {!obstacles.length && <p className="text-[13px] text-char-700">No obstacles yet. Add water tanks, HVAC, lift rooms, vents, trees or nearby buildings so the layout avoids them and shading is computed.</p>}
      <ul className="divide-y divide-rule rounded-[3px] border border-rule bg-white">
        {obstacles.map((o) => (
          <li key={o.id}>
            <button className={`flex w-full items-center justify-between px-2 py-1.5 text-left text-[13px] hover:bg-paper ${selection.ids.includes(o.id) ? 'bg-sun-100' : ''}`} onClick={() => set({ selection: { kind: 'obstacle', ids: [o.id] }, tool: 'select' })}>
              <span>{o.label}</span><span className="text-char-700">{o.widthM.toFixed(1)} × {o.depthM.toFixed(1)} × {o.heightM.toFixed(1)} m</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function VertexInput({ value, onCommit, label }: { value: number; onCommit: (v: number) => void; label: string }) {
  return <div className="w-24 ml-auto"><NumberField hideLabel label={label} value={+value.toFixed(3)} onCommit={(v) => v !== null && onCommit(v)} /></div>;
}
