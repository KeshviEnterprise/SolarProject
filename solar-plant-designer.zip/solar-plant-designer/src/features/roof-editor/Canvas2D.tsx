import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useStore, type Tool } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import type { Vec2, PlacedPanel, Obstacle, ObstacleKind } from '@/types';
import { bbox, obstacleFootprint, pointInPolygon, distPointSegment, offsetPolygonInward, rectPolygon, v, isSimplePolygon, azimuthVector } from '@/calculations/geometry';
import { panelFootprint, moduleDims } from '@/calculations/panelLayout';
import { buildShadowCasters, buildShadingScene, computeObstacleShading, interRowShadedFraction, receiverPlane, shadowOnPlane, surfaceAt, type ShadowCaster } from '@/calculations/shading';
import { parapetSegments, compass } from '@/calculations/structure';
import { calculateSolarPosition } from '@/calculations/solarPosition';
import { formatLength } from '@/calculations/units';
import { makeObstacle } from '@/utils/projectFactory';
import { uid } from '@/utils/id';

type Drag =
  | { mode: 'pan'; sx: number; sy: number; cx: number; cy: number }
  | { mode: 'move-obstacle'; id: string; start: Vec2; orig: Vec2 }
  | { mode: 'move-panels'; start: Vec2; orig: Map<string, Vec2> }
  | { mode: 'resize'; id: string }
  | { mode: 'rotate'; id: string }
  | { mode: 'vertex'; index: number }
  | { mode: 'marquee'; start: Vec2; additive: boolean }
  | { mode: 'draw-rect'; start: Vec2; target: 'boundary' | 'exclusion' | 'walkway' };

const pts = (poly: Vec2[]) => poly.map((p) => `${p.x.toFixed(4)},${(-p.y).toFixed(4)}`).join(' ');
const pathOf = (poly: Vec2[]) => `M${poly.map((p) => `${p.x.toFixed(3)} ${(-p.y).toFixed(3)}`).join('L')}Z`;

export const PLAN_SVG_ID = 'plan-svg';

export function Canvas2D() {
  const { project: p, surfaces, mounts, invalidPanels } = useDerived();
  const tool = useStore((s) => s.tool);
  const selection = useStore((s) => s.selection);
  const sun = useStore((s) => s.sun);
  const showShadows = useStore((s) => s.showShadows);
  const { set, update, checkpoint, undo, redo } = useStore.getState();

  const wrap = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ w: 800, h: 600 });
  const [view, setView] = useState({ cx: 25, cy: 15, s: 12 });
  const drag = useRef<Drag | null>(null);
  const [draftRect, setDraftRect] = useState<[Vec2, Vec2] | null>(null);
  const [marquee, setMarquee] = useState<[Vec2, Vec2] | null>(null);
  const [poly, setPoly] = useState<Vec2[]>([]);
  const [cursor, setCursor] = useState<Vec2 | null>(null);
  const dims = useMemo(() => moduleDims(p.panel), [p.panel]);

  // --- sizing / fit ----------------------------------------------------------------------
  useEffect(() => {
    if (!wrap.current) return;
    const ro = new ResizeObserver(([e]) => setSize({ w: Math.max(200, e.contentRect.width), h: Math.max(200, e.contentRect.height) }));
    ro.observe(wrap.current);
    return () => ro.disconnect();
  }, []);

  const fit = useCallback(() => {
    const all = [...p.structure.boundary, ...p.obstacles.map((o) => o.center)];
    if (!all.length) return;
    const b = bbox(all);
    const w = Math.max(1, b.maxX - b.minX), h = Math.max(1, b.maxY - b.minY);
    const s = Math.min((size.w - 120) / w, (size.h - 120) / h);
    setView({ cx: (b.minX + b.maxX) / 2, cy: (b.minY + b.maxY) / 2, s: Math.max(0.5, Math.min(400, s)) });
  }, [p.structure.boundary, p.obstacles, size]);

  const fittedFor = useRef<string>('');
  useEffect(() => {
    const key = `${p.id}|${size.w > 200}`;
    if (fittedFor.current !== key && size.w > 200) { fittedFor.current = key; fit(); }
  }, [p.id, size, fit]);

  const x0 = view.cx - size.w / (2 * view.s);
  const y0 = -view.cy - size.h / (2 * view.s);
  const px = 1 / view.s; // one screen pixel in metres

  const toWorld = useCallback((clientX: number, clientY: number): Vec2 => {
    const r = svgRef.current!.getBoundingClientRect();
    return v(x0 + (clientX - r.left) / view.s, -(y0 + (clientY - r.top) / view.s));
  }, [x0, y0, view.s]);

  // wheel zoom (non-passive)
  useEffect(() => {
    const el = svgRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      setView((vw) => {
        const wx = vw.cx + (mx - size.w / 2) / vw.s, wy = vw.cy - (my - size.h / 2) / vw.s;
        const s = Math.max(0.3, Math.min(600, vw.s * Math.exp(-e.deltaY * 0.0015)));
        return { s, cx: wx - (mx - size.w / 2) / s, cy: wy + (my - size.h / 2) / s };
      });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [size]);

  // --- derived drawing data --------------------------------------------------------------
  const fps = useMemo(() => p.layout.panels.map((pn) => panelFootprint(pn, dims)), [p.layout.panels, dims]);
  const fpBoxes = useMemo(() => fps.map((f) => bbox(f)), [fps]);
  const obstacleFps = useMemo(() => p.obstacles.map((o) => ({ o, fp: obstacleFootprint(o, 0), buf: o.bufferM > 0 ? obstacleFootprint(o, o.bufferM) : null })), [p.obstacles]);
  const setbackLine = useMemo(() => (p.structure.setbackM > 0 ? offsetPolygonInward(p.structure.boundary, p.structure.setbackM) : []), [p.structure.boundary, p.structure.setbackM]);
  const casters = useMemo(() => buildShadowCasters(p.obstacles, surfaces, parapetSegments(p.structure), p.structure.parapetHeightM, p.structure.eaveHeightM), [p.obstacles, surfaces, p.structure]);
  const sunPos = useMemo(() => calculateSolarPosition(p.location.latitude, p.location.longitude, sun.doy, sun.clockHour, p.location.utcOffsetHours), [p.location, sun]);
  const racked = useMemo(() => Object.fromEntries(surfaces.map((s) => [s.id, mounts[s.id]?.racked ?? false])), [surfaces, mounts]);
  const scene = useMemo(() => (showShadows && p.layout.panels.length ? buildShadingScene(p.layout.panels, dims, surfaces, casters, p.mounting.clearanceM, racked) : null), [showShadows, p.layout.panels, dims, surfaces, casters, p.mounting.clearanceM, racked]);
  const shade = useMemo(() => {
    if (!scene || sunPos.elevationDeg <= 0) return null;
    const f = computeObstacleShading(scene, sunPos.elevationDeg, sunPos.azimuthDeg);
    const rows = new Map<string, number>();
    p.layout.panels.forEach((pn) => { if (pn.row >= 0) rows.set(pn.surfaceId, Math.min(rows.get(pn.surfaceId) ?? Infinity, pn.row)); });
    const k = Math.max(1, Math.round(p.mounting.modulesHigh));
    const slant = k * (p.mounting.orientation === 'portrait' ? dims.lengthM : dims.widthM) + (k - 1) * p.mounting.moduleGapM;
    p.layout.panels.forEach((pn, i) => {
      if (!racked[pn.surfaceId] || pn.row < 0 || pn.row === rows.get(pn.surfaceId)) return;
      const fr = interRowShadedFraction(sunPos.elevationDeg, sunPos.azimuthDeg, pn.tiltDeg, pn.azimuthDeg, slant, p.layout.pitchBySurface[pn.surfaceId] ?? slant, mounts[pn.surfaceId]?.terrainSlopeDeg ?? 0);
      // bottom modules of a table are shaded first
      const share = Math.max(0, Math.min(1, fr * k - pn.stackIndex));
      f[i] = Math.max(f[i], share);
    });
    return f;
  }, [scene, sunPos, p.layout.panels, p.layout.pitchBySurface, p.mounting, dims, racked, mounts]);

  const shadowPolys = useMemo(() => {
    if (!showShadows || sunPos.elevationDeg <= 0.5) return { ground: [] as Vec2[][], roof: [] as { sid: string; poly: Vec2[] }[] };
    const ground: Vec2[][] = [];
    const flatPlane = { a: 0, gx: 0, gy: 0 };
    const buildingCaster: ShadowCaster[] = p.structure.roofType !== 'ground' && surfaces.length ? [{ id: 'bldg', label: 'Building', footprint: p.structure.boundary, baseZ: 0, topZ: p.structure.eaveHeightM }] : [];
    for (const c of [...buildingCaster, ...casters]) {
      const sh = shadowOnPlane(c.footprint, c.topZ, flatPlane, sunPos.elevationDeg, sunPos.azimuthDeg, 200);
      if (sh) ground.push(sh);
    }
    const roof: { sid: string; poly: Vec2[] }[] = [];
    for (const s of surfaces) {
      if (s.kind === 'ground') continue;
      const pl = receiverPlane(s, 0.02);
      for (const c of casters) {
        const sh = shadowOnPlane(c.footprint, c.topZ, pl, sunPos.elevationDeg, sunPos.azimuthDeg, 200);
        if (sh) roof.push({ sid: s.id, poly: sh });
      }
    }
    return { ground, roof };
  }, [showShadows, sunPos, casters, surfaces, p.structure]);

  const panelPaths = useMemo(() => {
    let normal = '', partial = '', heavy = '';
    fps.forEach((f, i) => {
      const s = shade?.[i] ?? 0;
      const d = pathOf(f);
      if (s >= 0.6) heavy += d; else if (s > 0) partial += d; else normal += d;
    });
    return { normal, partial, heavy };
  }, [fps, shade]);

  const selectedSet = useMemo(() => new Set(selection.kind === 'panel' ? selection.ids : []), [selection]);
  const selObstacle = selection.kind === 'obstacle' && selection.ids.length === 1 ? p.obstacles.find((o) => o.id === selection.ids[0]) ?? null : null;

  // --- hit testing -----------------------------------------------------------------------
  const hitPanel = (w: Vec2): number => {
    for (let i = fps.length - 1; i >= 0; i--) {
      const b = fpBoxes[i];
      if (w.x < b.minX || w.x > b.maxX || w.y < b.minY || w.y > b.maxY) continue;
      if (pointInPolygon(w, fps[i])) return i;
    }
    return -1;
  };
  const hitObstacle = (w: Vec2): Obstacle | null => {
    for (let i = obstacleFps.length - 1; i >= 0; i--) if (pointInPolygon(w, obstacleFps[i].fp)) return obstacleFps[i].o;
    return null;
  };
  const handles = (o: Obstacle) => {
    const r = (o.rotationDeg * Math.PI) / 180;
    const loc = (lx: number, ly: number) => v(o.center.x + lx * Math.cos(r) - ly * Math.sin(r), o.center.y + lx * Math.sin(r) + ly * Math.cos(r));
    return { resize: loc(o.widthM / 2, -o.depthM / 2), rotate: loc(0, o.depthM / 2 + 22 * px) };
  };

  // --- pointer handlers ------------------------------------------------------------------
  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button === 2) return;
    (e.target as Element).setPointerCapture?.(e.pointerId);
    wrap.current?.focus();
    const w = toWorld(e.clientX, e.clientY);
    const near = (a: Vec2) => Math.hypot(a.x - w.x, a.y - w.y) < 9 * px;

    if (tool === 'pan' || e.button === 1) { drag.current = { mode: 'pan', sx: e.clientX, sy: e.clientY, cx: view.cx, cy: view.cy }; return; }
    if (tool === 'rect-boundary' || tool === 'rect-exclusion' || tool === 'rect-walkway') {
      drag.current = { mode: 'draw-rect', start: w, target: tool === 'rect-boundary' ? 'boundary' : tool === 'rect-exclusion' ? 'exclusion' : 'walkway' };
      setDraftRect([w, w]);
      return;
    }
    if (tool === 'poly-boundary') {
      if (poly.length >= 3 && near(poly[0])) { finishPolygon(); return; }
      setPoly((q) => [...q, w]);
      return;
    }
    if (tool.startsWith('place:')) {
      const kind = tool.slice(6) as ObstacleKind;
      const o = makeObstacle(kind, w);
      if (kind !== 'tree' && kind !== 'nearby-structure' && !pointInPolygon(w, p.structure.boundary)) o.base = 'ground';
      update((q) => ({ ...q, obstacles: [...q.obstacles, o], analysis: null }));
      set({ selection: { kind: 'obstacle', ids: [o.id] }, tool: 'select' });
      return;
    }
    if (tool === 'add-panel') {
      const s = surfaceAt(surfaces, w) ?? surfaces[0];
      if (!s) return;
      const m = mounts[s.id];
      const pn: PlacedPanel = { id: uid('pm'), surfaceId: s.id, center: w, azimuthDeg: m.azimuthDeg, tiltDeg: m.tiltDeg, orientation: p.mounting.orientation, row: -1, stackIndex: 0, locked: false, manual: true };
      update((q) => ({ ...q, layout: { ...q.layout, panels: [...q.layout.panels, pn] }, analysis: null }));
      set({ selection: { kind: 'panel', ids: [pn.id] } });
      return;
    }
    // select tool
    if (selObstacle) {
      const h = handles(selObstacle);
      if (near(h.resize)) { checkpoint(); drag.current = { mode: 'resize', id: selObstacle.id }; return; }
      if (near(h.rotate)) { checkpoint(); drag.current = { mode: 'rotate', id: selObstacle.id }; return; }
    }
    if (selection.kind === 'boundary') {
      const idx = p.structure.boundary.findIndex((q) => near(q));
      if (idx >= 0) { checkpoint(); drag.current = { mode: 'vertex', index: idx }; return; }
    }
    const ob = hitObstacle(w);
    const pi = hitPanel(w);
    if (pi >= 0 && (!ob || ob.kind === 'walkway' || ob.kind === 'exclusion' || ob.kind === 'skylight')) {
      const pn = p.layout.panels[pi];
      let ids = selection.kind === 'panel' ? [...selection.ids] : [];
      if (e.shiftKey) ids = ids.includes(pn.id) ? ids.filter((x) => x !== pn.id) : [...ids, pn.id];
      else if (!ids.includes(pn.id)) ids = [pn.id];
      set({ selection: { kind: 'panel', ids } });
      const orig = new Map<string, Vec2>();
      for (const q of p.layout.panels) if (ids.includes(q.id) && !q.locked) orig.set(q.id, q.center);
      if (orig.size) { checkpoint(); drag.current = { mode: 'move-panels', start: w, orig }; }
      return;
    }
    if (ob) {
      set({ selection: { kind: 'obstacle', ids: [ob.id] } });
      checkpoint();
      drag.current = { mode: 'move-obstacle', id: ob.id, start: w, orig: ob.center };
      return;
    }
    const b = p.structure.boundary;
    const edgeHit = b.some((a, i) => distPointSegment(w, a, b[(i + 1) % b.length]) < 6 * px);
    if (edgeHit) { set({ selection: { kind: 'boundary', ids: [] } }); return; }
    drag.current = { mode: 'marquee', start: w, additive: e.shiftKey };
    setMarquee([w, w]);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const w = toWorld(e.clientX, e.clientY);
    setCursor(w);
    const d = drag.current;
    if (!d) return;
    switch (d.mode) {
      case 'pan':
        setView((vw) => ({ ...vw, cx: d.cx - (e.clientX - d.sx) / vw.s, cy: d.cy + (e.clientY - d.sy) / vw.s }));
        break;
      case 'move-obstacle': {
        const nc = v(d.orig.x + w.x - d.start.x, d.orig.y + w.y - d.start.y);
        update((q) => ({ ...q, obstacles: q.obstacles.map((o) => (o.id === d.id ? { ...o, center: nc } : o)), analysis: null }), false);
        break;
      }
      case 'move-panels': {
        const dx = w.x - d.start.x, dy = w.y - d.start.y;
        update((q) => ({ ...q, layout: { ...q.layout, panels: q.layout.panels.map((pn) => { const o = d.orig.get(pn.id); return o ? { ...pn, center: v(o.x + dx, o.y + dy) } : pn; }) }, analysis: null }), false);
        break;
      }
      case 'resize': {
        update((q) => ({ ...q, obstacles: q.obstacles.map((o) => {
          if (o.id !== d.id) return o;
          const r = (-o.rotationDeg * Math.PI) / 180;
          const lx = (w.x - o.center.x) * Math.cos(r) - (w.y - o.center.y) * Math.sin(r);
          const ly = (w.x - o.center.x) * Math.sin(r) + (w.y - o.center.y) * Math.cos(r);
          const nw = Math.max(0.1, 2 * Math.abs(lx)), nd = Math.max(0.1, 2 * Math.abs(ly));
          return o.shape === 'circle' ? { ...o, widthM: Math.max(nw, nd), depthM: Math.max(nw, nd) } : { ...o, widthM: nw, depthM: nd };
        }), analysis: null }), false);
        break;
      }
      case 'rotate': {
        update((q) => ({ ...q, obstacles: q.obstacles.map((o) => {
          if (o.id !== d.id) return o;
          let a = (Math.atan2(w.y - o.center.y, w.x - o.center.x) * 180) / Math.PI - 90;
          if (e.shiftKey) a = Math.round(a / 15) * 15;
          return { ...o, rotationDeg: +(((a % 360) + 360) % 360).toFixed(1) };
        }), analysis: null }), false);
        break;
      }
      case 'vertex':
        update((q) => ({ ...q, structure: { ...q.structure, boundary: q.structure.boundary.map((pt, i) => (i === d.index ? snap(w, e.shiftKey) : pt)) }, analysis: null }), false);
        break;
      case 'marquee':
        setMarquee([d.start, w]);
        break;
      case 'draw-rect':
        setDraftRect([d.start, w]);
        break;
    }
  };

  const onPointerUp = () => {
    const d = drag.current;
    drag.current = null;
    if (!d) return;
    if (d.mode === 'marquee' && marquee) {
      const [a, b] = marquee;
      const lo = v(Math.min(a.x, b.x), Math.min(a.y, b.y)), hi = v(Math.max(a.x, b.x), Math.max(a.y, b.y));
      if (hi.x - lo.x < 2 * px && hi.y - lo.y < 2 * px) set({ selection: { kind: null, ids: [] } });
      else {
        const ids = p.layout.panels.filter((pn) => pn.center.x >= lo.x && pn.center.x <= hi.x && pn.center.y >= lo.y && pn.center.y <= hi.y).map((pn) => pn.id);
        const prev = d.additive && selection.kind === 'panel' ? selection.ids : [];
        set({ selection: { kind: ids.length || prev.length ? 'panel' : null, ids: [...new Set([...prev, ...ids])] } });
      }
      setMarquee(null);
    }
    if (d.mode === 'draw-rect' && draftRect) {
      const [a, b] = draftRect;
      const w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
      setDraftRect(null);
      if (w < 0.2 || h < 0.2) return;
      const lo = v(Math.min(a.x, b.x), Math.min(a.y, b.y));
      if (d.target === 'boundary') {
        update((q) => ({ ...q, structure: { ...q.structure, boundary: [lo, v(lo.x + w, lo.y), v(lo.x + w, lo.y + h), v(lo.x, lo.y + h)], lengthM: +w.toFixed(3), widthM: +h.toFixed(3) }, layout: { ...q.layout, panels: [] }, analysis: null }));
        set({ tool: 'select' });
      } else {
        const o = makeObstacle(d.target, v(lo.x + w / 2, lo.y + h / 2), { widthM: +w.toFixed(3), depthM: +h.toFixed(3) });
        update((q) => ({ ...q, obstacles: [...q.obstacles, o], analysis: null }));
        set({ selection: { kind: 'obstacle', ids: [o.id] }, tool: 'select' });
      }
    }
  };

  const finishPolygon = () => {
    if (poly.length < 3) { setPoly([]); return; }
    if (!isSimplePolygon(poly)) { useStore.getState().notify('The polygon crosses itself. Draw it again without crossing edges.', 'error'); setPoly([]); return; }
    const b = bbox(poly);
    update((q) => ({ ...q, structure: { ...q.structure, boundary: poly, lengthM: +(b.maxX - b.minX).toFixed(3), widthM: +(b.maxY - b.minY).toFixed(3) }, layout: { ...q.layout, panels: [] }, analysis: null }));
    setPoly([]);
    set({ tool: 'select' });
  };

  // --- keyboard ---------------------------------------------------------------------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'SELECT' || t.tagName === 'TEXTAREA')) return;
      const st = useStore.getState();
      const sel = st.selection;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); st.save(); return; }
      if (st.view !== 'plan') return;
      if (e.key === 'Escape') { setPoly([]); setDraftRect(null); st.set({ tool: 'select', selection: { kind: null, ids: [] } }); return; }
      if (e.key === 'Enter' && poly.length) { finishPolygon(); return; }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (sel.kind === 'panel') { const ids = new Set(sel.ids); st.update((q) => ({ ...q, layout: { ...q.layout, panels: q.layout.panels.filter((pn) => !ids.has(pn.id) || pn.locked) }, analysis: null })); st.set({ selection: { kind: null, ids: [] } }); }
        if (sel.kind === 'obstacle') { const ids = new Set(sel.ids); st.update((q) => ({ ...q, obstacles: q.obstacles.filter((o) => !ids.has(o.id)), analysis: null })); st.set({ selection: { kind: null, ids: [] } }); }
        return;
      }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelection(); return; }
      const arrows: Record<string, Vec2> = { ArrowLeft: v(-1, 0), ArrowRight: v(1, 0), ArrowUp: v(0, 1), ArrowDown: v(0, -1) };
      if (arrows[e.key] && sel.ids.length) {
        e.preventDefault();
        const step = e.shiftKey ? 1 : 0.1;
        const dv = v(arrows[e.key].x * step, arrows[e.key].y * step);
        const ids = new Set(sel.ids);
        if (sel.kind === 'panel') st.update((q) => ({ ...q, layout: { ...q.layout, panels: q.layout.panels.map((pn) => (ids.has(pn.id) && !pn.locked ? { ...pn, center: v(pn.center.x + dv.x, pn.center.y + dv.y) } : pn)) }, analysis: null }));
        if (sel.kind === 'obstacle') st.update((q) => ({ ...q, obstacles: q.obstacles.map((o) => (ids.has(o.id) ? { ...o, center: v(o.center.x + dv.x, o.center.y + dv.y) } : o)), analysis: null }));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  // --- render helpers ---------------------------------------------------------------------
  const b = p.structure.boundary;
  const bb = b.length ? bbox(b) : { minX: 0, minY: 0, maxX: 1, maxY: 1 };
  const fs = 11 * px;
  const gridStep = view.s > 12 ? 1 : view.s > 3 ? 5 : 10;
  const u = p.settings.displayUnit;
  const surfaceFill = (az: number, kind: string) => (kind === 'ground' ? '#D9DDD0' : Math.cos(((az - 180) * Math.PI) / 180) > 0.3 ? '#C4CAD2' : Math.cos(((az - 180) * Math.PI) / 180) < -0.3 ? '#B3BAC4' : '#BCC2CB');
  const mountAz = surfaces[0] ? mounts[surfaces[0].id]?.azimuthDeg ?? p.mounting.azimuthDeg : p.mounting.azimuthDeg;
  const cursorClass = tool === 'pan' ? 'cursor-grab' : tool === 'select' ? 'cursor-default' : 'cursor-crosshair';

  return (
    <div ref={wrap} tabIndex={0} className="plan-canvas relative h-full w-full overflow-hidden outline-none" aria-label="2D roof and layout plan. Use the tools in the left panel; arrow keys nudge the selection.">
      <svg id={PLAN_SVG_ID} ref={svgRef} data-testid="plan-svg" width={size.w} height={size.h} viewBox={`${x0} ${y0} ${size.w / view.s} ${size.h / view.s}`} className={`block select-none ${cursorClass}`}
        onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerLeave={() => setCursor(null)}
        onDoubleClick={() => tool === 'poly-boundary' && finishPolygon()} onContextMenu={(e) => e.preventDefault()} role="img">
        <defs>
          <pattern id="grid" width={gridStep} height={gridStep} patternUnits="userSpaceOnUse"><path d={`M ${gridStep} 0 L 0 0 0 ${gridStep}`} fill="none" stroke="#DCE1E8" strokeWidth={px} /></pattern>
          <pattern id="hatch" width={0.6} height={0.6} patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width={0.6} height={0.6} fill="#F5B70033" /><line x1={0} y1={0} x2={0} y2={0.6} stroke="#C99400" strokeWidth={0.12} /></pattern>
          {surfaces.map((s) => <clipPath key={s.id} id={`clip-${s.id}`}><polygon points={pts(s.polygon)} /></clipPath>)}
        </defs>
        <rect x={x0} y={y0} width={size.w / view.s} height={size.h / view.s} fill="url(#grid)" />

        {/* ground shadows */}
        <g fill="#0E1B2E" opacity={0.16}>{shadowPolys.ground.map((sp, i) => <polygon key={i} points={pts(sp)} />)}</g>

        {/* surfaces */}
        {surfaces.map((s) => <polygon key={s.id} points={pts(s.polygon)} fill={surfaceFill(s.azimuthDeg, s.kind)} stroke="#6B7480" strokeWidth={px} />)}
        {/* roof shadows clipped to their plane */}
        {shadowPolys.roof.map((r, i) => <polygon key={i} points={pts(r.poly)} clipPath={`url(#clip-${r.sid})`} fill="#0E1B2E" opacity={0.22} />)}

        {/* boundary */}
        <polygon points={pts(b)} fill="none" stroke={selection.kind === 'boundary' ? '#F5B700' : '#2A2F36'} strokeWidth={(selection.kind === 'boundary' ? 2.5 : 1.5) * px} />
        {setbackLine.length > 2 && <polygon points={pts(setbackLine)} fill="none" stroke="#3A4049" strokeWidth={px} strokeDasharray={`${6 * px} ${4 * px}`} />}

        {/* obstacles */}
        {obstacleFps.map(({ o, fp, buf }) => {
          const isSel = selection.kind === 'obstacle' && selection.ids.includes(o.id);
          const style = o.kind === 'exclusion' ? { fill: 'url(#hatch)', stroke: '#C99400' } : o.kind === 'walkway' ? { fill: '#2E9E5B55', stroke: '#1F8A4C' } : { fill: o.kind === 'tree' ? '#D23B3033' : '#D23B3055', stroke: '#D23B30' };
          return (
            <g key={o.id}>
              {buf && <polygon points={pts(buf)} fill="none" stroke="#D23B30" strokeWidth={px} strokeDasharray={`${2 * px} ${3 * px}`} />}
              <polygon points={pts(fp)} fill={style.fill} stroke={isSel ? '#F5B700' : style.stroke} strokeWidth={(isSel ? 2.5 : 1.2) * px} />
              {view.s > 4 && <text x={o.center.x} y={-o.center.y} fontSize={fs} textAnchor="middle" dominantBaseline="middle" fill="#2A2F36" style={{ pointerEvents: 'none' }}>{o.label}</text>}
            </g>
          );
        })}

        {/* panels */}
        <path d={panelPaths.normal} fill="#2563EB" stroke="#DCE8FE" strokeWidth={0.6 * px} />
        <path d={panelPaths.partial} fill="#1D3F8F" stroke="#F5B700" strokeWidth={0.8 * px} />
        <path d={panelPaths.heavy} fill="#0F2352" stroke="#F5B700" strokeWidth={0.8 * px} />
        {p.layout.panels.map((pn, i) => (selectedSet.has(pn.id) || invalidPanels.has(pn.id) || pn.locked) && (
          <polygon key={pn.id} points={pts(fps[i])} fill={pn.locked ? '#0E1B2E44' : 'none'} stroke={selectedSet.has(pn.id) ? '#F5B700' : invalidPanels.has(pn.id) ? '#D23B30' : '#0E1B2E'} strokeWidth={2 * px} />
        ))}

        {/* dimension annotations */}
        {view.s > 1.5 && b.map((a, i) => {
          const c = b[(i + 1) % b.length];
          const L = Math.hypot(c.x - a.x, c.y - a.y);
          if (L * view.s < 40) return null;
          const mid = v((a.x + c.x) / 2, (a.y + c.y) / 2);
          const nx = -(c.y - a.y) / L, ny = (c.x - a.x) / L;
          const outward = pointInPolygon(v(mid.x + nx * 0.05, mid.y + ny * 0.05), b) ? -1 : 1;
          const off = 13 * px * outward;
          let ang = (-Math.atan2(c.y - a.y, c.x - a.x) * 180) / Math.PI;
          if (ang > 90) ang -= 180; if (ang < -90) ang += 180;
          const tx = mid.x + nx * off, ty = -(mid.y + ny * off);
          return <text key={i} x={tx} y={ty} fontSize={fs} fill="#1F3452" textAnchor="middle" dominantBaseline="middle" transform={`rotate(${ang} ${tx} ${ty})`} style={{ pointerEvents: 'none', fontWeight: 600 }}>{formatLength(L, u)}</text>;
        })}
        {/* overall dimension lines */}
        {view.s > 1.5 && b.length > 4 && <DimLine a={v(bb.minX, bb.maxY + 34 * px)} b={v(bb.maxX, bb.maxY + 34 * px)} px={px} label={formatLength(bb.maxX - bb.minX, u)} />}
        {view.s > 1.5 && b.length > 4 && <DimLine a={v(bb.minX - 34 * px, bb.minY)} b={v(bb.minX - 34 * px, bb.maxY)} px={px} label={formatLength(bb.maxY - bb.minY, u)} vertical />}

        {/* boundary vertex handles */}
        {selection.kind === 'boundary' && b.map((q, i) => <circle key={i} cx={q.x} cy={-q.y} r={5 * px} fill="#F5B700" stroke="#0E1B2E" strokeWidth={px} />)}
        {/* selected obstacle handles */}
        {selObstacle && (() => { const h = handles(selObstacle); return (
          <g>
            <line x1={selObstacle.center.x} y1={-selObstacle.center.y} x2={h.rotate.x} y2={-h.rotate.y} stroke="#F5B700" strokeWidth={px} />
            <circle cx={h.rotate.x} cy={-h.rotate.y} r={5 * px} fill="#fff" stroke="#0E1B2E" strokeWidth={1.5 * px}><title>Drag to rotate (Shift snaps 15°)</title></circle>
            <rect x={h.resize.x - 5 * px} y={-h.resize.y - 5 * px} width={10 * px} height={10 * px} fill="#F5B700" stroke="#0E1B2E" strokeWidth={px}><title>Drag to resize</title></rect>
            <text x={selObstacle.center.x} y={-selObstacle.center.y + (selObstacle.depthM / 2) + 14 * px} fontSize={fs} textAnchor="middle" fill="#0E1B2E">{formatLength(selObstacle.widthM, u)} × {formatLength(selObstacle.depthM, u)} · h {formatLength(selObstacle.heightM, u)}</text>
          </g>); })()}

        {/* drafts */}
        {draftRect && <polygon points={pts(rectPolygon(v((draftRect[0].x + draftRect[1].x) / 2, (draftRect[0].y + draftRect[1].y) / 2), Math.abs(draftRect[1].x - draftRect[0].x), Math.abs(draftRect[1].y - draftRect[0].y)))} fill="#2563EB22" stroke="#2563EB" strokeWidth={1.5 * px} strokeDasharray={`${5 * px} ${3 * px}`} />}
        {draftRect && <text x={draftRect[1].x} y={-draftRect[1].y - 8 * px} fontSize={fs} fill="#1D4FC4">{formatLength(Math.abs(draftRect[1].x - draftRect[0].x), u)} × {formatLength(Math.abs(draftRect[1].y - draftRect[0].y), u)}</text>}
        {poly.length > 0 && <polyline points={pts(cursor ? [...poly, cursor] : poly)} fill="none" stroke="#2563EB" strokeWidth={1.5 * px} />}
        {poly.map((q, i) => <circle key={i} cx={q.x} cy={-q.y} r={(i === 0 ? 6 : 4) * px} fill={i === 0 ? '#F5B700' : '#2563EB'} />)}
        {marquee && <rect x={Math.min(marquee[0].x, marquee[1].x)} y={-Math.max(marquee[0].y, marquee[1].y)} width={Math.abs(marquee[1].x - marquee[0].x)} height={Math.abs(marquee[1].y - marquee[0].y)} fill="#2563EB18" stroke="#2563EB" strokeWidth={px} strokeDasharray={`${4 * px} ${3 * px}`} />}
      </svg>

      {/* overlays */}
      <div className="pointer-events-none absolute right-3 top-3 flex flex-col items-center gap-2">
        <div className="flex h-14 w-14 flex-col items-center justify-center rounded-full border border-rule bg-white/90 text-navy-900" aria-label="North arrow: up is north">
          <svg width="26" height="30" viewBox="0 0 26 30" aria-hidden><path d="M13 2 L20 26 L13 20 L6 26 Z" fill="#0E1B2E" /><path d="M13 2 L13 20 L6 26 Z" fill="#F5B700" /></svg>
          <span className="-mt-1 text-[10px] font-bold">N</span>
        </div>
        <div className="rounded-[3px] border border-rule bg-white/90 px-2 py-1 text-center text-[11px] leading-tight" aria-label={`Array azimuth ${mountAz.toFixed(0)} degrees`}>
          <svg width="34" height="34" viewBox="-17 -17 34 34" aria-hidden className="mx-auto"><circle r="15" fill="none" stroke="#D5DAE1" /><line x1={0} y1={0} x2={13 * azimuthVector(mountAz).x} y2={-13 * azimuthVector(mountAz).y} stroke="#2563EB" strokeWidth="2.5" /><circle r="2.5" fill="#2563EB" /></svg>
          Array {mountAz.toFixed(0)}° {compass(mountAz)}
        </div>
      </div>
      <div className="absolute bottom-3 left-3 flex items-center gap-3 rounded-[3px] border border-rule bg-white/90 px-2 py-1 text-[11.5px]">
        <ScaleBar s={view.s} />
        <span className="text-char-700">{cursor ? `x ${cursor.x.toFixed(2)} m · y ${cursor.y.toFixed(2)} m` : 'Wheel to zoom · Pan tool or middle-drag to pan'}</span>
      </div>
      <div className="absolute bottom-3 right-3 flex gap-1">
        <button className="btn btn-secondary px-2 py-1 text-[12px]" onClick={fit} aria-label="Fit drawing to view">Fit</button>
        <button className="btn btn-secondary px-2 py-1 text-[12px]" onClick={() => setView((vw) => ({ ...vw, s: vw.s * 1.25 }))} aria-label="Zoom in">+</button>
        <button className="btn btn-secondary px-2 py-1 text-[12px]" onClick={() => setView((vw) => ({ ...vw, s: vw.s / 1.25 }))} aria-label="Zoom out">−</button>
      </div>
      {showShadows && (
        <div className="absolute left-3 top-3 rounded-[3px] border border-rule bg-white/90 px-2 py-1 text-[11.5px]">
          Sun {sunPos.elevationDeg > 0 ? `elev ${sunPos.elevationDeg.toFixed(1)}° · az ${sunPos.azimuthDeg.toFixed(1)}°` : 'below horizon'} · {fmtClock(sun.clockHour)} · day {sun.doy}
          <span className="ml-2 inline-flex items-center gap-1"><i className="inline-block h-2.5 w-3 bg-[#1D3F8F] outline outline-1 outline-sun-500" /> shaded</span>
        </div>
      )}
      <Legend />
    </div>
  );

  function duplicateSelection() {
    const st = useStore.getState();
    const sel = st.selection;
    const off = v(1, -1);
    if (sel.kind === 'panel') {
      const ids = new Set(sel.ids);
      const copies = st.project.layout.panels.filter((pn) => ids.has(pn.id)).map((pn) => ({ ...pn, id: uid('pm'), center: v(pn.center.x + off.x, pn.center.y + off.y), manual: true, locked: false, row: -1 }));
      st.update((q) => ({ ...q, layout: { ...q.layout, panels: [...q.layout.panels, ...copies] }, analysis: null }));
      st.set({ selection: { kind: 'panel', ids: copies.map((c) => c.id) } });
    }
    if (sel.kind === 'obstacle') {
      const ids = new Set(sel.ids);
      const copies = st.project.obstacles.filter((o) => ids.has(o.id)).map((o) => ({ ...o, id: uid('ob'), label: `${o.label} copy`, center: v(o.center.x + off.x, o.center.y + off.y) }));
      st.update((q) => ({ ...q, obstacles: [...q.obstacles, ...copies], analysis: null }));
      st.set({ selection: { kind: 'obstacle', ids: copies.map((c) => c.id) } });
    }
  }
}

function snap(w: Vec2, on: boolean): Vec2 {
  return on ? v(Math.round(w.x * 4) / 4, Math.round(w.y * 4) / 4) : w;
}

function fmtClock(h: number) {
  const hh = Math.floor(h), mm = Math.round((h - hh) * 60);
  return `${String(hh).padStart(2, '0')}:${String(mm === 60 ? 0 : mm).padStart(2, '0')}`;
}

function DimLine({ a, b, px, label, vertical }: { a: Vec2; b: Vec2; px: number; label: string; vertical?: boolean }) {
  const t = 6 * px;
  const mid = v((a.x + b.x) / 2, (a.y + b.y) / 2);
  return (
    <g stroke="#1F3452" strokeWidth={px} style={{ pointerEvents: 'none' }}>
      <line x1={a.x} y1={-a.y} x2={b.x} y2={-b.y} markerEnd="" />
      {vertical ? (<>
        <line x1={a.x - t} y1={-a.y} x2={a.x + t} y2={-a.y} /><line x1={b.x - t} y1={-b.y} x2={b.x + t} y2={-b.y} />
        <path d={`M${a.x} ${-a.y} l${-t / 2} ${-t} l${t} 0 Z M${b.x} ${-b.y} l${-t / 2} ${t} l${t} 0 Z`} fill="#1F3452" />
        <text x={mid.x - 6 * px} y={-mid.y} fontSize={11 * px} stroke="none" fill="#1F3452" textAnchor="middle" transform={`rotate(-90 ${mid.x - 6 * px} ${-mid.y})`} style={{ fontWeight: 600 }}>{label}</text>
      </>) : (<>
        <line x1={a.x} y1={-a.y - t} x2={a.x} y2={-a.y + t} /><line x1={b.x} y1={-b.y - t} x2={b.x} y2={-b.y + t} />
        <path d={`M${a.x} ${-a.y} l${t} ${-t / 2} l0 ${t} Z M${b.x} ${-b.y} l${-t} ${-t / 2} l0 ${t} Z`} fill="#1F3452" />
        <text x={mid.x} y={-mid.y - 5 * px} fontSize={11 * px} stroke="none" fill="#1F3452" textAnchor="middle" style={{ fontWeight: 600 }}>{label}</text>
      </>)}
    </g>
  );
}

function ScaleBar({ s }: { s: number }) {
  const targets = [0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500];
  const m = targets.find((t) => t * s >= 60) ?? 500;
  return <span className="flex items-center gap-1"><span className="block h-1.5 border-x-2 border-b-2 border-navy-900" style={{ width: m * s }} />{m} m</span>;
}

function Legend() {
  const items: [string, string][] = [['#2563EB', 'Panel'], ['#C4CAD2', 'Roof'], ['#D23B30', 'Obstacle'], ['#F5B700', 'Exclusion'], ['#2E9E5B', 'Walkway']];
  return (
    <div className="pointer-events-none absolute bottom-12 left-3 hidden gap-2 rounded-[3px] border border-rule bg-white/90 px-2 py-1 text-[11px] md:flex">
      {items.map(([c, l]) => <span key={l} className="flex items-center gap-1"><i className="inline-block h-2.5 w-3" style={{ background: c }} />{l}</span>)}
      <span className="flex items-center gap-1"><i className="inline-block w-4 border-t border-dashed border-char-700" />Setback</span>
    </div>
  );
}

export type { Tool };
