import type { SolarResource } from '@/types';
import { fetchJson, ProviderError, assertTwelve, type SolarDataProvider } from './solarDataProvider';

/**
 * PVGIS v5.3 monthly radiation (MRcalc) from the EU JRC
 * (https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/getting-started-pvgis/api-non-interactive-service_en).
 * PVGIS blocks browser CORS, so requests go through a proxy (Vite dev/preview proxy by default).
 */
export class PVGISProvider implements SolarDataProvider {
  id = 'pvgis' as const;
  label = 'PVGIS (EU JRC)';
  description = 'PVGIS SARAH/ERA5 monthly radiation, multi-year average (via proxy).';
  constructor(private baseUrl = (import.meta.env?.VITE_PVGIS_BASE_URL as string | undefined) || '/api/pvgis') {}

  buildUrl(lat: number, lon: number) {
    return `${this.baseUrl}/v5_3/MRcalc?lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}&horirrad=1&avtemp=1&outputformat=json`;
  }

  parse(json: unknown, lat: number, lon: number, url: string | null): SolarResource {
    const j = json as { outputs?: { monthly?: { year: number; month: number; 'H(h)_m'?: number; T2m?: number }[] }; inputs?: { location?: { elevation?: number }; meteo_data?: { radiation_db?: string; year_min?: number; year_max?: number } } };
    const rows = j?.outputs?.monthly;
    if (!rows?.length) throw new ProviderError('PVGIS response did not contain monthly data.', this.label, 'parse');
    const sumH = new Array(12).fill(0), nH = new Array(12).fill(0), sumT = new Array(12).fill(0), nT = new Array(12).fill(0);
    const daysIn = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();
    for (const r of rows) {
      const i = r.month - 1;
      if (r['H(h)_m'] !== undefined) { sumH[i] += r['H(h)_m'] / daysIn(r.year, r.month); nH[i]++; }
      if (r.T2m !== undefined) { sumT[i] += r.T2m; nT[i]++; }
    }
    const ghi = sumH.map((s, i) => (nH[i] ? s / nH[i] : NaN));
    const t = sumT.map((s, i) => (nT[i] ? s / nT[i] : NaN));
    assertTwelve(ghi, 'irradiance', this.label);
    assertTwelve(t, 'temperature', this.label);
    const md = j.inputs?.meteo_data;
    return {
      provider: 'pvgis', providerLabel: `PVGIS ${md?.radiation_db ?? ''}`.trim(), isDemo: false, fetchedAt: new Date().toISOString(),
      latitude: lat, longitude: lon,
      monthly: ghi.map((g, i) => ({ ghiKwhM2Day: g, tMeanC: t[i], tMaxC: null, tMinC: null })),
      elevationM: j.inputs?.location?.elevation ?? null,
      period: md?.year_min ? `${md.year_min}-${md.year_max}` : 'Multi-year average',
      notes: ['PVGIS monthly horizontal irradiation averaged over all available years.', 'PVGIS MRcalc supplies monthly mean temperature only; daily range assumed.'],
      requestUrl: url,
    };
  }

  async fetch(lat: number, lon: number, signal?: AbortSignal) {
    const url = this.buildUrl(lat, lon);
    return this.parse(await fetchJson(url, this.label, undefined, signal), lat, lon, url);
  }
}
