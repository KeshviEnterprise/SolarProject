import type { SolarResource } from '@/types';
import { fetchJson, ProviderError, assertTwelve, type SolarDataProvider } from './solarDataProvider';

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

/**
 * NASA POWER climatology API (https://power.larc.nasa.gov/docs/services/api/temporal/climatology/).
 * ALLSKY_SFC_SW_DWN = all-sky surface shortwave downward irradiance, kWh/m²/day.
 * T2M / T2M_MAX / T2M_MIN = 2 m air temperature, °C. Browser CORS is supported.
 */
export class NASAProvider implements SolarDataProvider {
  id = 'nasa-power' as const;
  label = 'NASA POWER';
  description = 'NASA POWER long-term climatology (satellite-derived, ~0.5° grid).';

  buildUrl(lat: number, lon: number) {
    return `https://power.larc.nasa.gov/api/temporal/climatology/point?parameters=ALLSKY_SFC_SW_DWN,T2M,T2M_MAX,T2M_MIN&community=RE&longitude=${lon.toFixed(4)}&latitude=${lat.toFixed(4)}&format=JSON`;
  }

  parse(json: unknown, lat: number, lon: number, url: string | null): SolarResource {
    const j = json as { properties?: { parameter?: Record<string, Record<string, number>> }; geometry?: { coordinates?: number[] }; header?: { range?: string; fill_value?: number } };
    const par = j?.properties?.parameter;
    if (!par?.ALLSKY_SFC_SW_DWN || !par?.T2M) throw new ProviderError('NASA POWER response did not contain the expected parameters.', this.label, 'parse');
    const fill = j.header?.fill_value ?? -999;
    const pick = (k: string) => MONTHS.map((m) => par[k]?.[m]).map((x) => (x === undefined || x === fill ? NaN : Number(x)));
    const ghi = pick('ALLSKY_SFC_SW_DWN');
    const tm = pick('T2M');
    assertTwelve(ghi, 'irradiance', this.label);
    assertTwelve(tm, 'temperature', this.label);
    const tx = par.T2M_MAX ? pick('T2M_MAX') : null;
    const tn = par.T2M_MIN ? pick('T2M_MIN') : null;
    const elev = j.geometry?.coordinates?.[2];
    return {
      provider: 'nasa-power', providerLabel: 'NASA POWER climatology', isDemo: false, fetchedAt: new Date().toISOString(),
      latitude: lat, longitude: lon,
      monthly: ghi.map((g, i) => ({ ghiKwhM2Day: g, tMeanC: tm[i], tMaxC: tx && Number.isFinite(tx[i]) ? tx[i] : null, tMinC: tn && Number.isFinite(tn[i]) ? tn[i] : null })),
      elevationM: Number.isFinite(elev) ? Number(elev) : null,
      period: j.header?.range ?? 'Long-term climatology',
      notes: ['Satellite-derived all-sky GHI (CERES/GEWEX); grid cell average, not a site measurement.'],
      requestUrl: url,
    };
  }

  async fetch(lat: number, lon: number, signal?: AbortSignal) {
    const url = this.buildUrl(lat, lon);
    return this.parse(await fetchJson(url, this.label, undefined, signal), lat, lon, url);
  }
}
