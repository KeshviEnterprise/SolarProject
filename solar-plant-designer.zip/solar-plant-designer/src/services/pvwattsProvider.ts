import type { SolarResource } from '@/types';
import { fetchJson, ProviderError, assertTwelve, type SolarDataProvider } from './solarDataProvider';

const DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

/**
 * NREL PVWatts v8 (https://developer.nrel.gov/docs/solar/pvwatts/v8/).
 * Queried with tilt = 0 so that `solrad_monthly` equals horizontal irradiation (kWh/m²/day).
 * Hourly ambient temperature (`tamb`) is aggregated to monthly mean / mean daily max / min.
 */
export class PVWattsProvider implements SolarDataProvider {
  id = 'pvwatts' as const;
  label = 'NREL PVWatts v8';
  description = 'NREL PVWatts TMY weather (requires an NREL API key; DEMO_KEY is rate-limited).';
  constructor(private apiKey = (import.meta.env?.VITE_NREL_API_KEY as string | undefined) || 'DEMO_KEY') {}

  buildUrl(lat: number, lon: number) {
    return `https://developer.nrel.gov/api/pvwatts/v8.json?api_key=${encodeURIComponent(this.apiKey)}&lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}&system_capacity=1&azimuth=180&tilt=0&array_type=0&module_type=0&losses=14&timeframe=hourly`;
  }

  parse(json: unknown, lat: number, lon: number, url: string | null): SolarResource {
    const j = json as { errors?: string[]; outputs?: { solrad_monthly?: number[]; tamb?: number[] }; station_info?: { elev?: number; weather_data_source?: string } };
    if (j?.errors?.length) throw new ProviderError(`PVWatts: ${j.errors.join('; ')}`, this.label, 'http');
    const ghi = j?.outputs?.solrad_monthly ?? [];
    assertTwelve(ghi, 'irradiance', this.label);
    const tamb = j.outputs?.tamb ?? [];
    const monthly = ghi.map((g, m) => {
      if (tamb.length < 8760) return { ghiKwhM2Day: g, tMeanC: NaN, tMaxC: null, tMinC: null };
      const start = DAYS.slice(0, m).reduce((a, b) => a + b, 0) * 24;
      let sum = 0, sMax = 0, sMin = 0;
      for (let d = 0; d < DAYS[m]; d++) {
        const day = tamb.slice(start + d * 24, start + d * 24 + 24);
        sum += day.reduce((a, b) => a + b, 0);
        sMax += Math.max(...day);
        sMin += Math.min(...day);
      }
      return { ghiKwhM2Day: g, tMeanC: sum / (DAYS[m] * 24), tMaxC: sMax / DAYS[m], tMinC: sMin / DAYS[m] };
    });
    assertTwelve(monthly.map((m) => m.tMeanC), 'temperature', this.label);
    return {
      provider: 'pvwatts', providerLabel: `NREL PVWatts (${j.station_info?.weather_data_source ?? 'TMY'})`, isDemo: false, fetchedAt: new Date().toISOString(),
      latitude: lat, longitude: lon, monthly, elevationM: j.station_info?.elev ?? null, period: 'Typical meteorological year',
      notes: ['Horizontal irradiation from PVWatts run at 0° tilt; temperatures aggregated from hourly TMY data.'],
      requestUrl: url?.replace(this.apiKey, '***') ?? null,
    };
  }

  async fetch(lat: number, lon: number, signal?: AbortSignal) {
    const url = this.buildUrl(lat, lon);
    return this.parse(await fetchJson(url, this.label, undefined, signal), lat, lon, url);
  }
}
