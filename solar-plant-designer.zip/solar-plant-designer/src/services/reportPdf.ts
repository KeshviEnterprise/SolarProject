/** PDF design report (jsPDF + autotable). Text is kept to the WinAnsi character set of the built-in fonts. */
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Project } from '@/types';
import { buildSurfaces, calculateAreas, ridgeHeight, parapetSegments } from '@/calculations/structure';
import { mountsFor } from '@/calculations/pipeline';
import { calculateLayoutStats } from '@/calculations/panelLayout';
import { calculateSunriseSunset, formatClock, formatDuration, MONTH_NAMES, REPRESENTATIVE_DOY } from '@/calculations/solarPosition';
import { calculateStringConfiguration } from '@/calculations/electrical';
import { collectDesignIssues, systemWeightKg } from '@/calculations/validation';
import { STRUCTURE_BY_ID, ROOF_TYPE_LABELS } from '@/data/structureTypes';
import { renderPlanSvg } from '@/utils/planSvg';
import { svgStringToPng } from '@/features/solar-analysis/charts';
import { ENGINEERING_DISCLAIMER, ELECTRICAL_DISCLAIMER } from '@/utils/disclaimers';

const NAVY: [number, number, number] = [14, 27, 46];
const f = (n: number | null | undefined, d = 2) => (n === null || n === undefined || !Number.isFinite(n) ? '-' : n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }));
const clean = (s: string) => s.replace(/[−–]/g, '-').replace(/≈/g, '~').replace(/β/g, 'beta').replace(/φ/g, 'lat').replace(/δ/g, 'decl').replace(/η/g, 'eta').replace(/[^\x20-\x7E\u00A0-\u00FF]/g, '');

export async function generateReportPdf(p: Project): Promise<Blob> {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 14;
  const surfaces = buildSurfaces(p.structure, p.mounting);
  const mounts = mountsFor(surfaces, p.mounting);
  const areas = calculateAreas(p.structure, surfaces, p.obstacles);
  const stats = calculateLayoutStats(p.layout.panels, p.panel, areas.roofPlanAreaM2, areas.usableAreaM2);
  const a = p.analysis;
  const demo = !!(a?.isDemoData || p.solarResource?.isDemo);
  let y = 0;
  const lastY = () => (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  const heading = (t: string) => {
    if (y > H - 40) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(...NAVY);
    doc.text(clean(t), M, y); doc.setDrawColor(...NAVY); doc.setLineWidth(0.4); doc.line(M, y + 1.5, W - M, y + 1.5);
    y += 5;
  };
  const table = (head: string[] | null, body: (string | number)[][], opts: { colRight?: number[] } = {}) => {
    autoTable(doc, {
      startY: y, head: head ? [head.map(clean)] : undefined, body: body.map((r) => r.map((c) => clean(String(c)))), margin: { left: M, right: M },
      styles: { fontSize: 8.5, cellPadding: 1.3, lineColor: [213, 218, 225], lineWidth: 0.1 },
      headStyles: { fillColor: NAVY, textColor: 255, fontStyle: 'bold' },
      columnStyles: Object.fromEntries((opts.colRight ?? []).map((i) => [i, { halign: 'right' }])),
      theme: head ? 'striped' : 'plain',
    });
    y = lastY() + 7;
  };

  // --- cover header ----------------------------------------------------------------------
  doc.setFillColor(...NAVY); doc.rect(0, 0, W, 30, 'F');
  doc.setFillColor(245, 183, 0); doc.rect(0, 30, W, 1.5, 'F');
  doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(17);
  doc.text('Solar PV Preliminary Design Report', M, 13);
  doc.setFontSize(11); doc.setFont('helvetica', 'normal');
  doc.text(clean(p.name), M, 21);
  doc.setFontSize(8.5); doc.text(`Generated ${new Date().toLocaleString('en-GB')}  |  Solar Plant Designer`, M, 26.5);
  y = 40;
  if (demo) {
    doc.setFillColor(252, 232, 230); doc.setDrawColor(210, 59, 48); doc.rect(M, y - 5, W - 2 * M, 12, 'FD');
    doc.setTextColor(160, 30, 20); doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5);
    doc.text('DEMO DATA: energy results use synthetic solar data and are illustrative only.', M + 3, y + 2.5);
    y += 13;
  }

  heading('1. Project and location');
  const loc = p.location;
  table(null, [
    ['Project', p.name], ['Address', [loc.address, loc.city, loc.state, loc.country, loc.postalCode].filter(Boolean).join(', ') || '-'],
    ['Coordinates', `${loc.latitude.toFixed(5)}, ${loc.longitude.toFixed(5)}`], ['Time zone', `${loc.timezone ?? '-'} (UTC${loc.utcOffsetHours >= 0 ? '+' : ''}${loc.utcOffsetHours} h, ${loc.utcOffsetSource})`],
    ['Elevation', loc.elevationM !== null ? `${f(loc.elevationM, 0)} m (${loc.elevationSource})` : 'Not available'],
  ]);

  heading('2. Structure');
  const st = p.structure;
  table(null, [
    ['Structure type', STRUCTURE_BY_ID[st.type].label], ['Roof geometry', ROOF_TYPE_LABELS[st.roofType]], ['Material / condition', `${st.material} / ${st.condition}`],
    ['Plan area / sloped area', `${f(areas.roofPlanAreaM2, 1)} m2 / ${f(areas.roofSurfaceAreaM2, 1)} m2`], ['Usable area', `${f(areas.usableAreaM2, 1)} m2 (setback ${st.setbackM} m, keep-outs ${f(areas.keepoutAreaM2, 1)} m2)`],
    ['Eave / ridge height', st.roofType === 'ground' ? 'Ground mount' : `${f(st.eaveHeightM, 2)} m / ${f(ridgeHeight(surfaces), 2)} m`], ['Slope / azimuth', `${st.slopeDeg} deg / ${st.roofAzimuthDeg} deg`],
    ['Parapet', st.parapetHeightM > 0 ? `${st.parapetHeightM} m (${parapetSegments(st).length} edges)` : 'None'], ['Obstacles', `${p.obstacles.length}: ${p.obstacles.map((o) => o.label).join(', ') || '-'}`],
    ['Estimated system weight', `${f(systemWeightKg(p), 0)} kg (estimate)`], ['Structural capacity', st.structuralCapacityKgM2 !== null ? `${st.structuralCapacityKgM2} kg/m2 (user input)` : 'Structural suitability has not been verified.'],
  ]);

  heading('3. Roof and layout diagram');
  const png = await svgStringToPng(renderPlanSvg(p, 1600, 1100), 1600, 1100, 1);
  if (png) {
    const url = await blobToDataUrl(png);
    const iw = W - 2 * M, ih = (iw * 1100) / 1600;
    if (y + ih > H - 20) { doc.addPage(); y = 20; }
    doc.addImage(url, 'PNG', M, y, iw, ih);
    y += ih + 6;
  } else {
    doc.setFontSize(9); doc.text('Plan image could not be rendered in this browser.', M, y); y += 8;
  }

  heading('4. Panel and array');
  table(null, [
    ['Panel', `${p.panel.manufacturer} ${p.panel.model} (${p.panel.technology})`], ['Rated power / size', `${p.panel.powerW} W / ${p.panel.lengthMm} x ${p.panel.widthMm} x ${p.panel.thicknessMm} mm, ${p.panel.weightKg} kg`],
    ['Efficiency', `${f(p.panel.efficiencyPct, 2)} %`], ['Panel data source', p.panel.sourceNote],
    ['Number of panels', String(stats.panelCount)], ['Installed DC capacity', `${f(stats.dcKwp, 2)} kWp`],
    ['Mounting', `${p.mounting.type}, ${p.mounting.orientation}, ${p.mounting.modulesHigh} module(s) per table`],
    ['Tilt / azimuth', surfaces.map((s) => `${s.name}: ${f(mounts[s.id].tiltDeg, 1)} deg / ${f(mounts[s.id].azimuthDeg, 0)} deg`).join('; ')],
    ['Rows / row pitch', `${stats.rows} / ${Object.values(p.layout.pitchBySurface).map((x) => `${f(x, 2)} m`).join(', ') || '-'}`],
    ['Roof utilisation', `${f(stats.utilizationPct, 1)} % of plan area`], ['Layout configuration', p.layout.configLabel || 'Manual'],
  ]);

  heading('5. Inverter and electrical (preliminary)');
  if (p.electrical.enabled) {
    const e = p.electrical;
    const r = calculateStringConfiguration({ panel: p.panel, inverter: e.inverter, inverterQty: e.inverterQty, modulesPerString: e.modulesPerString, stringsTotal: e.stringsTotal, minAmbientC: e.minAmbientC, maxAmbientC: e.maxAmbientC, layoutPanelCount: stats.panelCount });
    table(null, [
      ['Inverter', `${e.inverterQty} x ${e.inverter.model} (${e.inverter.acPowerKw} kW AC)`], ['Strings', `${e.stringsTotal} x ${e.modulesPerString} modules`],
      ['String Voc (cold) / limit', `${f(r.stringVocColdV, 0)} V / ${e.inverter.maxDcVoltageV} V`], ['String Vmp (hot) / MPPT', `${f(r.stringVmpHotV, 0)} V / ${e.inverter.mpptMinV}-${e.inverter.mpptMaxV} V`],
      ['DC/AC ratio', f(r.dcAcRatio, 2)], ['Checks', r.warnings.map((w) => w.message).join(' ') || 'No issues found by the preliminary checks.'],
    ]);
  } else {
    table(null, [['Status', 'Inverter and string design not configured; energy results are not limited by inverter AC capacity.']]);
  }
  doc.setFontSize(8.5); doc.setTextColor(160, 30, 20); doc.text(ELECTRICAL_DISCLAIMER, M, y - 3); doc.setTextColor(0); y += 3;

  heading('6. Solar resource');
  const res = p.solarResource;
  if (res) {
    table(null, [['Source', `${res.providerLabel}${res.isDemo ? ' - DEMO (synthetic)' : ''}`], ['Period', res.period], ['Retrieved', new Date(res.fetchedAt).toLocaleString('en-GB')],
      ['Annual GHI', `${f(res.monthly.reduce((s, m, i) => s + m.ghiKwhM2Day * [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][i], 0), 0)} kWh/m2`]]);
  } else table(null, [['Status', 'No solar resource data loaded.']]);

  if (a) {
    heading('7. Monthly energy analysis');
    table(['Month', 'GHI kWh/m2', 'POA kWh/m2', 'PSH h/d', 'Temp C', 'Energy kWh', 'kWh/day', 'Losses kWh', 'Shading %', 'PR %'],
      [...a.months.map((m, i) => [MONTH_NAMES[i], f(m.ghiKwhM2, 1), f(m.poaKwhM2, 1), f(m.peakSunHours, 2), f(m.tMeanC, 1), f(m.acKwh, 0), f(m.avgDailyKwh, 1), f(m.lossesKwh, 0), f(m.shadingLossPct, 1), f(m.performanceRatio * 100, 1)]),
        ['Year', f(a.annualGhiKwhM2, 0), f(a.annualPoaKwhM2, 0), f(a.annualPoaKwhM2 / 365, 2), '', f(a.annualAcKwh, 0), f(a.annualAcKwh / 365, 1), '', f(a.lossStages[1].lossPct, 1), f(a.performanceRatio * 100, 1)]],
      { colRight: [1, 2, 3, 4, 5, 6, 7, 8, 9] });

    heading('8. Annual results');
    table(null, [['Annual AC generation', `${f(a.annualAcKwh, 0)} kWh${demo ? ' (DEMO)' : ''}`], ['Specific yield', `${f(a.specificYield, 0)} kWh/kWp/yr`], ['Performance ratio', `${f(a.performanceRatio * 100, 1)} %`], ['Capacity factor (DC)', `${f(a.capacityFactorDc * 100, 1)} %`], ['Solar data', a.providerLabel], ['Computed', new Date(a.computedAt).toLocaleString('en-GB')]]);

    heading('9. Loss breakdown');
    table(['Stage', 'Loss %', 'Loss kWh', 'Energy after kWh', 'Basis'], a.lossStages.map((s) => [s.label, s.key === 'nominal' ? '' : f(s.lossPct, 2), s.key === 'nominal' ? '' : f(s.lossKwh, 0), f(s.energyAfterKwh, 0), s.source]), { colRight: [1, 2, 3] });
  } else {
    heading('7. Energy analysis');
    table(null, [['Status', 'The energy analysis has not been run for this design.']]);
  }

  heading('10. Sunlight table (15th of each month, local standard time)');
  table(['Month', 'Sunrise', 'Solar noon', 'Sunset', 'Day length', 'Max. elevation'], MONTH_NAMES.map((mn, i) => {
    const t = calculateSunriseSunset(loc.latitude, loc.longitude, [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349][i], loc.utcOffsetHours);
    return [mn, formatClock(t.sunrise), formatClock(t.solarNoon), formatClock(t.sunset), formatDuration(t.dayLengthHours), `${f(t.maxElevationDeg, 1)} deg`];
  }));
  void REPRESENTATIVE_DOY;

  heading('11. Assumptions');
  const assumptions = a?.assumptions ?? ['Energy analysis not run.'];
  table(null, assumptions.map((x) => ['-', x]));

  heading('12. Warnings and open items');
  const issues = collectDesignIssues(p);
  table(['Level', 'Area', 'Message'], issues.length ? issues.map((i) => [i.level.toUpperCase(), i.area, i.message]) : [['-', '-', 'No issues detected by the automatic checks.']]);

  heading('13. Engineering disclaimer');
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(40);
  const lines = doc.splitTextToSize(`${ENGINEERING_DISCLAIMER} ${ELECTRICAL_DISCLAIMER}`, W - 2 * M);
  doc.text(lines, M, y); y += lines.length * 4.5;

  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5); doc.setTextColor(110);
    doc.text(`${clean(p.name)} - preliminary design, not for construction${demo ? ' - DEMO DATA' : ''}`, M, H - 7);
    doc.text(`Page ${i} of ${pages}`, W - M, H - 7, { align: 'right' });
    if (demo) { doc.setTextColor(230, 170, 165); doc.setFontSize(46); doc.text('DEMO', W / 2, H / 2, { align: 'center', angle: 35 }); }
  }
  return doc.output('blob');
}

function blobToDataUrl(b: Blob): Promise<string> {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(r.error); r.readAsDataURL(b); });
}
