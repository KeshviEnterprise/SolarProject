import type { Project } from '@/types';
import { MONTH_NAMES } from '@/calculations/solarPosition';
import { moduleDims, panelFootprint } from '@/calculations/panelLayout';
import { toCsv, svgStringToPng } from '@/features/solar-analysis/charts';
import { renderPlanSvg } from '@/utils/planSvg';

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function monthlyCsv(p: Project): string {
  const a = p.analysis;
  if (!a) throw new Error('Run the energy analysis first.');
  const rows = a.months.map((m, i) => [MONTH_NAMES[i], m.ghiKwhM2.toFixed(2), m.poaKwhM2.toFixed(2), m.peakSunHours.toFixed(3), m.tMeanC.toFixed(1), m.acKwh.toFixed(1), m.avgDailyKwh.toFixed(2), m.lossesKwh.toFixed(1), m.shadingLossPct.toFixed(2), (m.performanceRatio * 100).toFixed(2)]);
  rows.push(['Year', a.annualGhiKwhM2.toFixed(1), a.annualPoaKwhM2.toFixed(1), (a.annualPoaKwhM2 / 365).toFixed(3), '', a.annualAcKwh.toFixed(1), (a.annualAcKwh / 365).toFixed(2), '', '', (a.performanceRatio * 100).toFixed(2)]);
  const head = `# ${p.name} - monthly energy analysis. Solar data: ${a.providerLabel}${a.isDemoData ? ' (DEMO - synthetic)' : ''}. Computed ${a.computedAt}.\n`;
  return head + toCsv(['Month', 'GHI kWh/m2', 'POA kWh/m2', 'Peak sun hours h/d', 'Avg temperature C', 'AC energy kWh', 'Avg daily kWh', 'Losses kWh', 'Shading %', 'PR %'], rows);
}

export function panelsCsv(p: Project): string {
  const dims = moduleDims(p.panel);
  return toCsv(['id', 'surface', 'row', 'stack', 'center_x_m', 'center_y_m', 'tilt_deg', 'azimuth_deg', 'orientation', 'manual', 'locked', 'footprint_plan_m'],
    p.layout.panels.map((pn) => [pn.id, pn.surfaceId, pn.row, pn.stackIndex, pn.center.x.toFixed(3), pn.center.y.toFixed(3), pn.tiltDeg, pn.azimuthDeg, pn.orientation, String(pn.manual), String(pn.locked), panelFootprint(pn, dims).map((q) => `${q.x.toFixed(3)} ${q.y.toFixed(3)}`).join('; ')]));
}

export async function planPng(p: Project, width = 1600, height = 1100): Promise<Blob | null> {
  return svgStringToPng(renderPlanSvg(p, width, height), width, height, 1);
}
