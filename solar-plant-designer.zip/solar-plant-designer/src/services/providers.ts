import type { SolarProviderId } from '@/types';
import type { SolarDataProvider } from './solarDataProvider';
import { NASAProvider } from './nasaProvider';
import { PVGISProvider } from './pvgisProvider';
import { PVWattsProvider } from './pvwattsProvider';
import { MockSolarDataProvider } from './mockSolarProvider';

export const PROVIDERS: Record<SolarProviderId, SolarDataProvider> = {
  'nasa-power': new NASAProvider(),
  pvgis: new PVGISProvider(),
  pvwatts: new PVWattsProvider(),
  demo: new MockSolarDataProvider(),
};

const envPref = (import.meta.env?.VITE_SOLAR_PROVIDER as string | undefined) ?? 'nasa';
const PREF: Record<string, SolarProviderId> = { nasa: 'nasa-power', pvgis: 'pvgis', pvwatts: 'pvwatts' };

/** Real providers in fallback order, starting with the chosen one. Demo is never in the chain. */
export function providerChain(first?: SolarProviderId): SolarDataProvider[] {
  const primary = first && first !== 'demo' ? first : PREF[envPref] ?? 'nasa-power';
  const order: SolarProviderId[] = [primary, ...(['nasa-power', 'pvgis', 'pvwatts'] as SolarProviderId[]).filter((x) => x !== primary)];
  return order.map((id) => PROVIDERS[id]);
}
