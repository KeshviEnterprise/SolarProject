import type { SolarResource } from '@/types';
import type { SolarDataProvider } from './solarDataProvider';
import { dailyExtraterrestrialHorizontal } from '@/calculations/irradiance';
import { REPRESENTATIVE_DOY } from '@/calculations/solarPosition';

/**
 * DEMO provider for development / offline use. NOT measured data.
 * GHI = H0 (extraterrestrial, computed) × an assumed constant clearness index 0.50.
 * Temperature = an assumed flat 25 °C with ±5 °C daily swing.
 * Every result derived from it is marked DEMO in the UI and reports.
 */
export const DEMO_CLEARNESS_INDEX = 0.5;
export const DEMO_TEMPERATURE_C = 25;

export class MockSolarDataProvider implements SolarDataProvider {
  id = 'demo' as const;
  label = 'Demo data (synthetic)';
  description = 'Synthetic values for testing only: extraterrestrial irradiation × assumed clearness 0.50, 25 °C.';

  build(lat: number, lon: number): SolarResource {
    return {
      provider: 'demo', providerLabel: 'DEMO - synthetic, not measured', isDemo: true, fetchedAt: new Date().toISOString(),
      latitude: lat, longitude: lon,
      monthly: REPRESENTATIVE_DOY.map((doy) => ({
        ghiKwhM2Day: dailyExtraterrestrialHorizontal(doy, lat) * DEMO_CLEARNESS_INDEX,
        tMeanC: DEMO_TEMPERATURE_C, tMaxC: DEMO_TEMPERATURE_C + 5, tMinC: DEMO_TEMPERATURE_C - 5,
      })),
      elevationM: null,
      period: 'Synthetic',
      notes: [`DEMO: GHI = extraterrestrial × assumed clearness index ${DEMO_CLEARNESS_INDEX}; temperature fixed at ${DEMO_TEMPERATURE_C} °C ± 5 °C. Not measured data.`],
      requestUrl: null,
    };
  }

  async fetch(lat: number, lon: number) {
    return this.build(lat, lon);
  }
}
