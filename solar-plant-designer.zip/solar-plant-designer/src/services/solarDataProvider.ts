/**
 * Solar resource provider abstraction. Every provider returns long-term monthly mean
 * daily GHI (kWh/m²/day) and air temperature for a location.
 */
import type { SolarResource, SolarProviderId } from '@/types';

export interface SolarDataProvider {
  id: SolarProviderId;
  label: string;
  description: string;
  fetch(lat: number, lon: number, signal?: AbortSignal): Promise<SolarResource>;
}

export class ProviderError extends Error {
  constructor(message: string, public provider: string, public kind: 'timeout' | 'network' | 'http' | 'parse' | 'config') {
    super(message);
  }
}

export const TIMEOUT_MS = Number(import.meta.env?.VITE_SOLAR_TIMEOUT_MS ?? 20000) || 20000;

/** fetch with timeout that maps failures to ProviderError. */
export async function fetchJson(url: string, provider: string, timeoutMs = TIMEOUT_MS, outer?: AbortSignal): Promise<unknown> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort('timeout'), timeoutMs);
  const onAbort = () => ctl.abort('aborted');
  outer?.addEventListener('abort', onAbort);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) throw new ProviderError(`${provider} responded with HTTP ${res.status}.`, provider, 'http');
    try { return await res.json(); } catch { throw new ProviderError(`${provider} returned data that could not be read.`, provider, 'parse'); }
  } catch (e) {
    if (e instanceof ProviderError) throw e;
    if (ctl.signal.aborted && ctl.signal.reason === 'timeout') throw new ProviderError(`${provider} did not respond within ${Math.round(timeoutMs / 1000)} s.`, provider, 'timeout');
    throw new ProviderError(`${provider} could not be reached (network or CORS error).`, provider, 'network');
  } finally {
    clearTimeout(timer);
    outer?.removeEventListener('abort', onAbort);
  }
}

export function assertTwelve(values: number[], what: string, provider: string) {
  if (values.length !== 12 || values.some((x) => !Number.isFinite(x))) throw new ProviderError(`${provider}: ${what} is incomplete.`, provider, 'parse');
}

export interface ChainAttempt { provider: string; ok: boolean; error?: string }

/** Try providers in order; return first success plus a log of attempts. */
export async function fetchWithFallback(providers: SolarDataProvider[], lat: number, lon: number, signal?: AbortSignal): Promise<{ resource: SolarResource | null; attempts: ChainAttempt[] }> {
  const attempts: ChainAttempt[] = [];
  for (const p of providers) {
    try {
      const resource = await p.fetch(lat, lon, signal);
      attempts.push({ provider: p.label, ok: true });
      return { resource, attempts };
    } catch (e) {
      attempts.push({ provider: p.label, ok: false, error: e instanceof Error ? e.message : String(e) });
      if (signal?.aborted) break;
    }
  }
  return { resource: null, attempts };
}
