import { useStore } from '@/store/projectStore';
import { providerChain, PROVIDERS } from './providers';
import { fetchWithFallback } from './solarDataProvider';
import { runAnalysisAsync, layoutOptionsAsync } from './workerClient';
import { generateLayout, analysisSignature, type LayoutOption } from '@/calculations/pipeline';
import type { SolarProviderId } from '@/types';

const S = () => useStore.getState();

let solarAbort: AbortController | null = null;

/** Fetch real solar resource data, trying providers in order. Never substitutes demo data. */
export async function fetchSolarData(first?: SolarProviderId): Promise<boolean> {
  const { project } = S();
  solarAbort?.abort();
  solarAbort = new AbortController();
  S().set({ solarStatus: 'loading', solarAttempts: [] });
  const { resource, attempts } = await fetchWithFallback(providerChain(first), project.location.latitude, project.location.longitude, solarAbort.signal);
  if (!resource) {
    S().set({ solarStatus: 'error', solarAttempts: attempts });
    return false;
  }
  S().update((p) => ({ ...p, solarResource: resource, analysis: null, location: resource.elevationM !== null && p.location.elevationM === null ? { ...p.location, elevationM: resource.elevationM, elevationSource: 'external' } : p.location }));
  S().set({ solarStatus: 'ok', solarAttempts: attempts });
  S().notify(`Solar data loaded from ${resource.providerLabel}`, 'ok');
  return true;
}

export function useDemoSolarData() {
  const { project } = S();
  const r = (PROVIDERS.demo as unknown as { build: (a: number, b: number) => import('@/types').SolarResource }).build(project.location.latitude, project.location.longitude);
  S().update((p) => ({ ...p, solarResource: r, analysis: null }));
  S().set({ solarStatus: 'ok' });
  S().notify('DEMO solar data in use - results are illustrative only', 'info');
}

export async function runAnalysisAction(): Promise<void> {
  const st = S();
  if (!st.project.layout.panels.length) { st.notify('Generate or place panels before running the analysis.', 'error'); return; }
  if (!st.project.solarResource) {
    const ok = await fetchSolarData();
    if (!ok) { S().set({ section: 'energy' }); S().notify('Solar resource data is currently unavailable.', 'error'); return; }
  }
  S().set({ analysisStatus: 'running', analysisError: null });
  try {
    const result = await runAnalysisAsync(S().project);
    S().update((p) => ({ ...p, analysis: result }), false);
    S().set({ analysisStatus: 'idle', view: 'analysis' });
    S().notify('Analysis complete', 'ok');
  } catch (e) {
    S().set({ analysisStatus: 'error', analysisError: e instanceof Error ? e.message : String(e) });
    S().notify('Analysis failed', 'error');
  }
}

export function isAnalysisStale(): boolean {
  const p = S().project;
  return !!p.analysis && p.analysis.inputSignature !== analysisSignature(p);
}

export function autoLayoutNow(label = 'Auto layout') {
  const p = S().project;
  const r = generateLayout(p);
  S().update((q) => ({ ...q, layout: { panels: r.panels, pitchBySurface: r.pitchBySurface, configLabel: label, generatedAt: new Date().toISOString() }, analysis: null }));
  S().set({ selection: { kind: null, ids: [] } });
  S().notify(`${r.panels.length} panels placed`, 'ok');
}

export async function generateOptionsAction() {
  S().set({ optionsStatus: 'running', layoutOptions: null });
  try {
    const opts = await layoutOptionsAsync(S().project);
    S().set({ layoutOptions: opts, optionsStatus: 'idle' });
  } catch (e) {
    S().set({ optionsStatus: 'error' });
    S().notify(`Layout evaluation failed: ${e instanceof Error ? e.message : String(e)}`, 'error');
  }
}

export function applyOption(o: LayoutOption) {
  S().update((p) => ({
    ...p,
    mounting: { ...p.mounting, ...o.overrides },
    layout: { panels: o.layout.panels, pitchBySurface: o.layout.pitchBySurface, configLabel: o.label, generatedAt: new Date().toISOString() },
    analysis: null,
  }));
  S().notify(`Applied: ${o.label}`, 'ok');
}
