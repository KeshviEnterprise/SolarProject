/**
 * Project persistence in localStorage with a versioned schema and migration hook.
 */
import type { Project } from '@/types';
import { SCHEMA_VERSION } from '@/types';

const INDEX_KEY = 'spd:index';
const KEY = (id: string) => `spd:project:${id}`;

export interface ProjectIndexEntry { id: string; name: string; updatedAt: string; isDemo: boolean }

function getStore(): Storage | null {
  try { return typeof localStorage !== 'undefined' ? localStorage : null; } catch { return null; }
}

export function listProjects(): ProjectIndexEntry[] {
  const s = getStore();
  if (!s) return [];
  try { return JSON.parse(s.getItem(INDEX_KEY) ?? '[]'); } catch { return []; }
}

function writeIndex(list: ProjectIndexEntry[]) {
  getStore()?.setItem(INDEX_KEY, JSON.stringify(list));
}

export function saveProject(p: Project): void {
  const s = getStore();
  if (!s) throw new Error('Browser storage is not available.');
  const updated = { ...p, metadata: { ...p.metadata, updatedAt: new Date().toISOString() } };
  s.setItem(KEY(p.id), JSON.stringify(updated));
  const list = listProjects().filter((e) => e.id !== p.id);
  list.unshift({ id: p.id, name: p.name, updatedAt: updated.metadata.updatedAt, isDemo: p.metadata.isDemo });
  writeIndex(list);
}

export function loadProject(id: string): Project | null {
  const raw = getStore()?.getItem(KEY(id));
  if (!raw) return null;
  return migrateProject(JSON.parse(raw));
}

export function deleteProject(id: string) {
  getStore()?.removeItem(KEY(id));
  writeIndex(listProjects().filter((e) => e.id !== id));
}

/** Upgrade older schema versions. Throws for unknown/invalid files. */
export function migrateProject(raw: unknown): Project {
  const p = raw as Partial<Project> & { schemaVersion?: number };
  if (!p || typeof p !== 'object' || !p.id || !p.structure || !p.panel || !p.location) throw new Error('This file is not a Solar Plant Designer project.');
  if (p.schemaVersion !== SCHEMA_VERSION) {
    if ((p.schemaVersion ?? 0) > SCHEMA_VERSION) throw new Error(`Project schema v${p.schemaVersion} is newer than this app supports (v${SCHEMA_VERSION}).`);
    // Future migrations go here.
  }
  return p as Project;
}

export const LAST_OPEN_KEY = 'spd:last';
export function setLastOpen(id: string) { getStore()?.setItem(LAST_OPEN_KEY, id); }
export function getLastOpen(): string | null { return getStore()?.getItem(LAST_OPEN_KEY) ?? null; }
