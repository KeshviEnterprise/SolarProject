/**
 * Location services:
 *  - Geocoding: OpenStreetMap Nominatim search (usage policy: ≤1 request/s, attribution).
 *  - Time zone + elevation: Open-Meteo forecast endpoint with timezone=auto.
 * Both are optional; the app falls back to manual coordinates and an estimated offset.
 */
import { fetchJson } from './solarDataProvider';

export interface GeocodeResult {
  displayName: string;
  lat: number;
  lon: number;
  city: string;
  state: string;
  country: string;
  postalCode: string;
}

export async function searchPlaces(q: string, signal?: AbortSignal): Promise<GeocodeResult[]> {
  const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=6&q=${encodeURIComponent(q)}`;
  const data = (await fetchJson(url, 'Location search', 12000, signal)) as { display_name: string; lat: string; lon: string; address?: Record<string, string> }[];
  return data.map((d) => ({
    displayName: d.display_name,
    lat: Number(d.lat),
    lon: Number(d.lon),
    city: d.address?.city ?? d.address?.town ?? d.address?.village ?? d.address?.county ?? '',
    state: d.address?.state ?? '',
    country: d.address?.country ?? '',
    postalCode: d.address?.postcode ?? '',
  }));
}

export interface SiteInfo { timezone: string; utcOffsetHours: number; elevationM: number | null }

export async function fetchSiteInfo(lat: number, lon: number, signal?: AbortSignal): Promise<SiteInfo> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&timezone=auto&forecast_days=1&daily=sunrise`;
  const d = (await fetchJson(url, 'Open-Meteo', 12000, signal)) as { timezone: string; utc_offset_seconds: number; elevation?: number };
  return { timezone: d.timezone, utcOffsetHours: d.utc_offset_seconds / 3600, elevationM: typeof d.elevation === 'number' ? d.elevation : null };
}

/** Offset estimated from longitude (nearest 0.5 h). Labelled ESTIMATED. */
export function estimateUtcOffset(lon: number): number {
  return Math.round((lon / 15) * 2) / 2;
}
