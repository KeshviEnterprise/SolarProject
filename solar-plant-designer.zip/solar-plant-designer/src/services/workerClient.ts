/**
 * Runs heavy calculations in a Web Worker; falls back to the main thread if workers are unavailable.
 */
import type { Project, AnalysisResult } from '@/types';
import { runAnalysis, generateLayoutOptions, optimiseTilt, type LayoutOption } from '@/calculations/pipeline';

let worker: Worker | null = null;
let seq = 0;
const pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void }>();

function getWorker(): Worker | null {
  if (worker) return worker;
  try {
    worker = new Worker(new URL('../workers/analysis.worker.ts', import.meta.url), { type: 'module' });
    worker.onmessage = (ev: MessageEvent<{ id: number; ok: boolean; result?: unknown; error?: string }>) => {
      const p = pending.get(ev.data.id);
      if (!p) return;
      pending.delete(ev.data.id);
      if (ev.data.ok) p.resolve(ev.data.result); else p.reject(new Error(ev.data.error));
    };
    worker.onerror = (e) => {
      for (const [, p] of pending) p.reject(new Error(e.message || 'Calculation worker failed.'));
      pending.clear();
      worker = null;
    };
    return worker;
  } catch {
    return null;
  }
}

async function call<T>(type: 'analysis' | 'options' | 'tilt', project: Project): Promise<T> {
  const w = getWorker();
  if (!w) {
    return (type === 'analysis' ? runAnalysis(project) : type === 'options' ? generateLayoutOptions(project) : optimiseTilt(project)) as T;
  }
  const id = ++seq;
  return new Promise<T>((resolve, reject) => {
    pending.set(id, { resolve: resolve as (v: unknown) => void, reject });
    w.postMessage({ id, type, project });
  });
}

export const runAnalysisAsync = (p: Project) => call<AnalysisResult>('analysis', p);
export const layoutOptionsAsync = (p: Project) => call<LayoutOption[]>('options', p);
export const optimiseTiltAsync = (p: Project) => call<{ tiltDeg: number; poaKwhM2: number } | null>('tilt', p);
