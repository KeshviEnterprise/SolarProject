/** Standalone SVG plan drawing used for PNG export and the PDF report. */
import type { Project, Vec2 } from '@/types';
import { buildSurfaces } from '@/calculations/structure';
import { bbox, obstacleFootprint, offsetPolygonInward } from '@/calculations/geometry';
import { moduleDims, panelFootprint } from '@/calculations/panelLayout';

export function renderPlanSvg(p: Project, W: number, H: number): string {
  const surfaces = buildSurfaces(p.structure, p.mounting);
  const all: Vec2[] = [...p.structure.boundary, ...p.obstacles.flatMap((o) => obstacleFootprint(o, 0))];
  const b = all.length ? bbox(all) : { minX: 0, minY: 0, maxX: 10, maxY: 10 };
  const margin = 70;
  const s = Math.min((W - 2 * margin) / Math.max(1, b.maxX - b.minX), (H - 2 * margin - 40) / Math.max(1, b.maxY - b.minY));
  const X = (x: number) => margin + (x - b.minX) * s;
  const Y = (y: number) => H - margin - (y - b.minY) * s;
  const pts = (poly: Vec2[]) => poly.map((q) => `${X(q.x).toFixed(1)},${Y(q.y).toFixed(1)}`).join(' ');
  const dims = moduleDims(p.panel);
  const out: string[] = [];
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" font-family="Helvetica, Arial, sans-serif">`);
  out.push(`<rect width="${W}" height="${H}" fill="#F2F4F7"/>`);
  for (const sf of surfaces) out.push(`<polygon points="${pts(sf.polygon)}" fill="${sf.kind === 'ground' ? '#D9DDD0' : '#C4CAD2'}" stroke="#6B7480" stroke-width="1"/>`);
  out.push(`<polygon points="${pts(p.structure.boundary)}" fill="none" stroke="#2A2F36" stroke-width="2"/>`);
  if (p.structure.setbackM > 0) {
    const sb = offsetPolygonInward(p.structure.boundary, p.structure.setbackM);
    if (sb.length > 2) out.push(`<polygon points="${pts(sb)}" fill="none" stroke="#3A4049" stroke-dasharray="6 4"/>`);
  }
  for (const o of p.obstacles) {
    const fill = o.kind === 'exclusion' ? '#F5B70066' : o.kind === 'walkway' ? '#2E9E5B66' : '#D23B3066';
    const stroke = o.kind === 'exclusion' ? '#C99400' : o.kind === 'walkway' ? '#1F8A4C' : '#D23B30';
    out.push(`<polygon points="${pts(obstacleFootprint(o, 0))}" fill="${fill}" stroke="${stroke}" stroke-width="1.2"/>`);
    out.push(`<text x="${X(o.center.x)}" y="${Y(o.center.y)}" font-size="11" text-anchor="middle" dominant-baseline="middle" fill="#2A2F36">${esc(o.label)}</text>`);
  }
  const d = p.layout.panels.map((pn) => `M${panelFootprint(pn, dims).map((q) => `${X(q.x).toFixed(1)} ${Y(q.y).toFixed(1)}`).join('L')}Z`).join('');
  out.push(`<path d="${d}" fill="#2563EB" stroke="#DCE8FE" stroke-width="0.5"/>`);
  // overall dimensions
  const w = b.maxX - b.minX, h = b.maxY - b.minY;
  out.push(`<g stroke="#1F3452" fill="#1F3452"><line x1="${X(b.minX)}" y1="${margin - 30}" x2="${X(b.maxX)}" y2="${margin - 30}"/><line x1="${X(b.minX)}" y1="${margin - 36}" x2="${X(b.minX)}" y2="${margin - 24}"/><line x1="${X(b.maxX)}" y1="${margin - 36}" x2="${X(b.maxX)}" y2="${margin - 24}"/></g>`);
  out.push(`<text x="${(X(b.minX) + X(b.maxX)) / 2}" y="${margin - 36}" font-size="13" font-weight="bold" text-anchor="middle" fill="#1F3452">${w.toFixed(2)} m</text>`);
  out.push(`<g stroke="#1F3452"><line x1="${margin - 30}" y1="${Y(b.minY)}" x2="${margin - 30}" y2="${Y(b.maxY)}"/><line x1="${margin - 36}" y1="${Y(b.minY)}" x2="${margin - 24}" y2="${Y(b.minY)}"/><line x1="${margin - 36}" y1="${Y(b.maxY)}" x2="${margin - 24}" y2="${Y(b.maxY)}"/></g>`);
  out.push(`<text x="${margin - 40}" y="${(Y(b.minY) + Y(b.maxY)) / 2}" font-size="13" font-weight="bold" text-anchor="middle" fill="#1F3452" transform="rotate(-90 ${margin - 40} ${(Y(b.minY) + Y(b.maxY)) / 2})">${h.toFixed(2)} m</text>`);
  // north arrow
  out.push(`<g transform="translate(${W - 50},50)"><circle r="26" fill="#fff" stroke="#D5DAE1"/><path d="M0 -20 L8 14 L0 7 L-8 14 Z" fill="#0E1B2E"/><path d="M0 -20 L0 7 L-8 14 Z" fill="#F5B700"/><text y="24" font-size="11" font-weight="bold" text-anchor="middle">N</text></g>`);
  // scale bar
  const targets = [1, 2, 5, 10, 20, 50, 100, 200, 500];
  const m = targets.find((t) => t * s >= 80) ?? 500;
  out.push(`<g transform="translate(${margin},${H - 22})"><rect width="${m * s}" height="6" fill="#0E1B2E"/><rect width="${(m * s) / 2}" height="6" fill="#fff" stroke="#0E1B2E"/><text x="${m * s + 6}" y="7" font-size="12">${m} m</text></g>`);
  out.push(`<text x="${W - margin}" y="${H - 16}" font-size="12" text-anchor="end" fill="#3A4049">${esc(p.name)} · ${p.layout.panels.length} panels · plan view, north up</text>`);
  out.push('</svg>');
  return out.join('');
}

const esc = (s: string) => s.replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c]!);
