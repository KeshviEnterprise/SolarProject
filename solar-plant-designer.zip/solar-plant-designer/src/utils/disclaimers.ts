export const ENGINEERING_DISCLAIMER =
  'This application provides preliminary solar PV design and energy production estimates. Final structural, electrical, civil, mechanical, code-compliance, installation, shading, and energy-yield decisions must be verified using site-specific measurements and qualified professionals.';
export const ELECTRICAL_DISCLAIMER = 'This is a preliminary design calculation and must be verified by a qualified electrical engineer.';
export const STRUCTURAL_NOTICE = 'Structural suitability has not been verified.';
