import type { Project, Obstacle, ObstacleKind, StructureTypeId, Vec2 } from '@/types';
import { SCHEMA_VERSION } from '@/types';
import { PANEL_LIBRARY } from '@/data/panelLibrary';
import { INVERTER_LIBRARY } from '@/data/inverterLibrary';
import { STRUCTURE_BY_ID } from '@/data/structureTypes';
import { OBSTACLE_BY_KIND } from '@/data/obstacleTypes';
import { DEFAULT_LOSSES } from '@/calculations/losses';
import { rectangleBoundary } from '@/calculations/structure';
import { suggestTiltFromLatitude, equatorFacingAzimuth } from '@/calculations/panelLayout';
import { uid } from './id';

export const APP_VERSION = '1.0.0';

export function makeObstacle(kind: ObstacleKind, center: Vec2, overrides: Partial<Obstacle> = {}): Obstacle {
  const d = OBSTACLE_BY_KIND[kind];
  return { id: uid('ob'), kind, label: d.label, center, widthM: d.w, depthM: d.d, rotationDeg: 0, heightM: d.h, base: d.base, shape: d.shape, bufferM: d.buffer, ...overrides };
}

export function applyStructureType(p: Project, id: StructureTypeId): Project {
  const d = STRUCTURE_BY_ID[id];
  const lat = p.location.latitude;
  const eq = equatorFacingAzimuth(lat);
  return {
    ...p,
    structure: {
      ...p.structure,
      type: id, roofType: d.roofType, material: d.material, eaveHeightM: d.eaveHeightM, slopeDeg: d.slopeDeg,
      parapetHeightM: d.parapetHeightM, setbackM: d.setbackM, lengthM: d.lengthM, widthM: d.widthM,
      boundary: rectangleBoundary(d.lengthM, d.widthM),
      roofAzimuthDeg: eq,
      terrainSlopeDeg: 0,
    },
    mounting: {
      ...p.mounting,
      type: d.mountingType,
      tiltDeg: d.roofType === 'canopy' ? d.slopeDeg : d.mountingType === 'roof-following' ? p.mounting.tiltDeg : Math.round(suggestTiltFromLatitude(lat)),
      modulesHigh: d.roofType === 'ground' ? 2 : 1,
      clearanceM: d.roofType === 'ground' ? 0.6 : 0.3,
      walkwayEveryRows: 0,
    },
    layout: { panels: [], pitchBySurface: {}, configLabel: '', generatedAt: null },
    analysis: null,
  };
}

export function createProject(name = 'Untitled project'): Project {
  const now = new Date().toISOString();
  const base: Project = {
    schemaVersion: SCHEMA_VERSION,
    id: uid('prj'),
    name,
    location: {
      address: '', city: '', state: '', country: '', postalCode: '',
      latitude: 21.1702, longitude: 72.8311, timezone: null, utcOffsetHours: 5.5, utcOffsetSource: 'estimated',
      elevationM: null, elevationSource: null,
    },
    structure: {
      type: 'flat-roof', roofType: 'flat', material: 'membrane', roofAgeYears: null, condition: 'unknown', structuralCapacityKgM2: null,
      lengthM: 30, widthM: 20, boundary: rectangleBoundary(30, 20), eaveHeightM: 8, slopeDeg: 0, roofAzimuthDeg: 180,
      parapetHeightM: 0.6, setbackM: 1, terrainSlopeDeg: 0,
    },
    obstacles: [],
    panel: { ...PANEL_LIBRARY[0] },
    mounting: {
      type: 'fixed-tilt', tiltDeg: 20, azimuthDeg: 180, orientation: 'portrait', modulesHigh: 1, moduleGapM: 0.02,
      rowSpacingMode: 'shade-free', shadeFreeStartHour: 9, shadeFreeEndHour: 15, gcr: 0.5, manualPitchM: 4, clearanceM: 0.3,
      walkwayEveryRows: 0, walkwayWidthM: 0.8, seasonalTiltsDeg: null,
    },
    layout: { panels: [], pitchBySurface: {}, configLabel: '', generatedAt: null },
    electrical: {
      enabled: false, inverter: { ...INVERTER_LIBRARY[3] }, inverterQty: 1, modulesPerString: 18, stringsTotal: 4, minAmbientC: 10, maxAmbientC: 45,
    },
    losses: { ...DEFAULT_LOSSES },
    solarResource: null,
    analysis: null,
    settings: { displayUnit: 'm' },
    metadata: { createdAt: now, updatedAt: now, notes: '', isDemo: false, appVersion: APP_VERSION },
  };
  return base;
}

/**
 * Demo project: Surat, Gujarat - industrial shed, 30 m × 50 m roof, 550 W modules.
 * Roof slope, eave height, obstacles and the nearby tree are illustrative assumptions
 * (marked in the project notes); the solar resource must be loaded from a provider.
 */
export function createDemoProject(): Project {
  let p = createProject('Demo · Surat industrial shed');
  p.location = { ...p.location, address: 'Surat, Gujarat, India', city: 'Surat', state: 'Gujarat', country: 'India', postalCode: '', latitude: 21.1702, longitude: 72.8311, utcOffsetHours: 5.5, utcOffsetSource: 'user', timezone: 'Asia/Kolkata' };
  p = applyStructureType(p, 'industrial-shed');
  p.structure = { ...p.structure, lengthM: 50, widthM: 30, boundary: rectangleBoundary(50, 30), eaveHeightM: 8, slopeDeg: 10, roofAzimuthDeg: 180, setbackM: 0.6 };
  p.obstacles = [
    makeObstacle('vent', { x: 12, y: 22 }, { label: 'Turbo ventilator 1' }),
    makeObstacle('vent', { x: 25, y: 22 }, { label: 'Turbo ventilator 2' }),
    makeObstacle('vent', { x: 38, y: 22 }, { label: 'Turbo ventilator 3' }),
    makeObstacle('skylight', { x: 25, y: 7.5 }, { label: 'Skylight', widthM: 2, depthM: 6 }),
    makeObstacle('tree', { x: 56, y: 5 }, { label: 'Neem tree (east)', heightM: 11, widthM: 7, depthM: 7 }),
  ];
  p.metadata = { ...p.metadata, isDemo: true, notes: 'Demo project. Roof size (30 m × 50 m) and 550 W module are the given inputs. Eave height 8 m, slope 10°, vents, skylight and tree are illustrative assumptions - replace with site measurements.' };
  return p;
}
