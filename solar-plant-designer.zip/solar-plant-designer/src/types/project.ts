/**
 * Solar Plant Designer - versioned project schema.
 * All geometry is stored in SI units: metres, in a local plan frame where
 * +x = east and +y = north, origin at an arbitrary site datum.
 * Azimuths are degrees clockwise from true north (0 = N, 90 = E, 180 = S, 270 = W).
 */
import type { AnalysisResult } from './analysis';

export const SCHEMA_VERSION = 1 as const;

export interface Vec2 { x: number; y: number }

/** Where a value came from. Rendered as a tag next to every important number. */
export type Provenance = 'user' | 'calculated' | 'estimated' | 'external' | 'demo' | 'assumption';

export type LengthUnit = 'mm' | 'cm' | 'm' | 'in' | 'ft';

export type StructureTypeId =
  | 'bungalow' | 'independent-house' | 'residential-building' | 'apartment-building'
  | 'commercial-building' | 'office-building' | 'industrial-shed' | 'factory' | 'warehouse'
  | 'rcc-rooftop' | 'concrete-roof' | 'metal-sheet-roof' | 'flat-roof' | 'sloped-roof'
  | 'gable-roof' | 'shed-roof' | 'ground-mounted' | 'solar-carport' | 'parking-structure'
  | 'custom-rooftop' | 'custom-polygon' | 'user-defined-area';

/** Geometric roof model used by the engine. */
export type RoofType = 'flat' | 'shed' | 'gable' | 'ground' | 'canopy';
export type RoofMaterial = 'rcc' | 'concrete' | 'metal-sheet' | 'tile' | 'membrane' | 'soil' | 'other';
export type RoofCondition = 'unknown' | 'good' | 'fair' | 'poor';

export interface Location {
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  latitude: number;
  longitude: number;
  timezone: string | null;
  /** Standard UTC offset used for clock times (DST not modelled). */
  utcOffsetHours: number;
  utcOffsetSource: Provenance;
  elevationM: number | null;
  elevationSource: Provenance | null;
}

export interface Structure {
  type: StructureTypeId;
  roofType: RoofType;
  material: RoofMaterial;
  roofAgeYears: number | null;
  condition: RoofCondition;
  /** Additional permissible load, kg/m². null = unknown (not verified). */
  structuralCapacityKgM2: number | null;
  /** Rectangle helper dimensions (m). Boundary may be any polygon. */
  lengthM: number;
  widthM: number;
  /** Plan polygon of the roof / land. */
  boundary: Vec2[];
  /** Eave / roof-deck height above ground (m). For ground mount = 0. */
  eaveHeightM: number;
  /** Roof slope (deg). flat = 0, shed/gable/canopy use it. */
  slopeDeg: number;
  /** Azimuth the (primary) roof plane faces, i.e. downslope direction (deg). */
  roofAzimuthDeg: number;
  parapetHeightM: number;
  /** Perimeter setback from boundary (m). */
  setbackM: number;
  /** Ground terrain slope (deg), descending toward the array azimuth (ground mount). */
  terrainSlopeDeg: number;
}

export type ObstacleKind =
  | 'water-tank' | 'hvac' | 'lift-room' | 'staircase' | 'vent' | 'skylight' | 'chimney'
  | 'nearby-structure' | 'tree' | 'exclusion' | 'walkway' | 'other';

export interface Obstacle {
  id: string;
  kind: ObstacleKind;
  label: string;
  center: Vec2;
  /** Size along local x before rotation (m). For circles this is the diameter. */
  widthM: number;
  /** Size along local y before rotation (m). */
  depthM: number;
  rotationDeg: number;
  /** Height above its base (m). */
  heightM: number;
  base: 'roof' | 'ground';
  shape: 'rect' | 'circle';
  /** Clearance kept free of panels around the object (m). */
  bufferM: number;
}

export type PanelTechnology = 'mono-PERC' | 'TOPCon' | 'HJT' | 'IBC' | 'poly' | 'thin-film' | 'other';

export interface PanelSpec {
  id: string;
  manufacturer: string;
  model: string;
  powerW: number;
  lengthMm: number;
  widthMm: number;
  thicknessMm: number;
  efficiencyPct: number;
  vocV: number;
  iscA: number;
  vmpV: number;
  impA: number;
  /** Pmax temperature coefficient, %/°C (negative). */
  tempCoeffPmaxPctPerC: number;
  /** Voc temperature coefficient, %/°C (negative). */
  tempCoeffVocPctPerC: number;
  technology: PanelTechnology;
  bifacial: boolean;
  weightKg: number;
  sourceNote: string;
}

export type MountingType = 'fixed-tilt' | 'roof-following' | 'adjustable-tilt';
export type PanelOrientation = 'portrait' | 'landscape';
export type RowSpacingMode = 'shade-free' | 'gcr' | 'manual';

export interface Mounting {
  type: MountingType;
  tiltDeg: number;
  azimuthDeg: number;
  orientation: PanelOrientation;
  /** Modules stacked up-slope per table (1-4). */
  modulesHigh: number;
  /** Gap between adjacent modules (m). */
  moduleGapM: number;
  rowSpacingMode: RowSpacingMode;
  /** Shade-free window on the winter solstice, solar time hours. */
  shadeFreeStartHour: number;
  shadeFreeEndHour: number;
  gcr: number;
  /** Plan row pitch when mode = manual (m). */
  manualPitchM: number;
  /** Lowest edge clearance above roof/ground (m). */
  clearanceM: number;
  /** Insert a maintenance walkway after every N table rows (0 = none). */
  walkwayEveryRows: number;
  walkwayWidthM: number;
  /** Adjustable tilt: tilt per month (deg). */
  seasonalTiltsDeg: number[] | null;
}

export interface PlacedPanel {
  id: string;
  surfaceId: string;
  center: Vec2;
  azimuthDeg: number;
  tiltDeg: number;
  orientation: PanelOrientation;
  /** Table row index within its surface (for inter-row shading). -1 = manual. */
  row: number;
  stackIndex: number;
  locked: boolean;
  manual: boolean;
}

export interface Layout {
  panels: PlacedPanel[];
  /** Plan row pitch used (m) per surface. */
  pitchBySurface: Record<string, number>;
  configLabel: string;
  generatedAt: string | null;
}

export interface InverterSpec {
  id: string;
  manufacturer: string;
  model: string;
  acPowerKw: number;
  maxDcVoltageV: number;
  mpptMinV: number;
  mpptMaxV: number;
  mpptCount: number;
  maxInputCurrentPerMpptA: number;
  maxEfficiencyPct: number;
  sourceNote: string;
}

export interface Electrical {
  enabled: boolean;
  inverter: InverterSpec;
  inverterQty: number;
  modulesPerString: number;
  stringsTotal: number;
  minAmbientC: number;
  maxAmbientC: number;
}

/** Loss assumptions in percent. Temperature, shading, IAM and clipping are computed by the model. */
export interface Losses {
  soilingPct: number;
  mismatchPct: number;
  dcWiringPct: number;
  acWiringPct: number;
  inverterPct: number;
  availabilityPct: number;
  otherPct: number;
  shadingOverridePct: number | null;
  albedo: number;
}

export type SolarProviderId = 'nasa-power' | 'pvgis' | 'pvwatts' | 'demo';

export interface MonthlyClimate {
  /** Mean daily global horizontal irradiation, kWh/m²/day. */
  ghiKwhM2Day: number;
  tMeanC: number;
  tMaxC: number | null;
  tMinC: number | null;
}

export interface SolarResource {
  provider: SolarProviderId;
  providerLabel: string;
  isDemo: boolean;
  fetchedAt: string;
  latitude: number;
  longitude: number;
  monthly: MonthlyClimate[];
  elevationM: number | null;
  period: string;
  notes: string[];
  requestUrl: string | null;
}

export interface ProjectSettings { displayUnit: LengthUnit }

export interface ProjectMetadata {
  createdAt: string;
  updatedAt: string;
  notes: string;
  isDemo: boolean;
  appVersion: string;
}

export interface Project {
  schemaVersion: typeof SCHEMA_VERSION;
  id: string;
  name: string;
  location: Location;
  structure: Structure;
  obstacles: Obstacle[];
  panel: PanelSpec;
  mounting: Mounting;
  layout: Layout;
  electrical: Electrical;
  losses: Losses;
  solarResource: SolarResource | null;
  analysis: AnalysisResult | null;
  settings: ProjectSettings;
  metadata: ProjectMetadata;
}
