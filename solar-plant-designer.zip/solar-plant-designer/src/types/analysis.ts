import type { Provenance } from './project';

export interface HourlyPoint {
  hour: number; // solar time
  ghiW: number;
  poaW: number;
  acKw: number;
  cellTempC: number;
  shadedFraction: number;
}

export interface MonthResult {
  month: number;
  days: number;
  ghiKwhM2: number;
  poaKwhM2: number;
  beamFraction: number;
  peakSunHours: number;
  tMeanC: number;
  nominalKwh: number;
  dcKwh: number;
  acKwh: number;
  avgDailyKwh: number;
  lossesKwh: number;
  performanceRatio: number;
  shadingLossPct: number;
  temperatureLossPct: number;
  iamLossPct: number;
  hourly: HourlyPoint[];
}

export interface LossStage {
  key: string;
  label: string;
  energyAfterKwh: number;
  lossKwh: number;
  lossPct: number;
  source: Provenance;
}

export interface SurfaceSummary {
  surfaceId: string;
  name: string;
  panelCount: number;
  kWp: number;
  tiltDeg: number;
  azimuthDeg: number;
  annualPoaKwhM2: number;
}

export interface AnalysisResult {
  computedAt: string;
  inputSignature: string;
  isDemoData: boolean;
  providerLabel: string;
  dcKwp: number;
  acKw: number | null;
  months: MonthResult[];
  daily: number[];
  annualGhiKwhM2: number;
  annualPoaKwhM2: number;
  annualAcKwh: number;
  specificYield: number;
  performanceRatio: number;
  capacityFactorDc: number;
  lossStages: LossStage[];
  surfaces: SurfaceSummary[];
  warnings: string[];
  assumptions: string[];
}
