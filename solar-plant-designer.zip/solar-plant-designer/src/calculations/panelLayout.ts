/**
 * Panel layout engine.
 *
 * Algorithm (per installation surface):
 *  1. Work in a local frame aligned to the array: u along the rows, w toward the facing azimuth.
 *  2. Rows ("tables" of `modulesHigh` stacked modules) are bands of plan depth D spaced at pitch P.
 *  3. For each band (grown by the setback) the exact set of u-intervals that lie inside the surface
 *     polygon is found by intersecting the polygon crossing intervals on every critical line
 *     (band edges + polygon vertices inside the band). Intervals are then shrunk by the setback.
 *  4. Keep-out polygons (obstacles + buffer, walkways, exclusions) are clipped to the band and
 *     their u-extent subtracted.
 *  5. Tables are packed into each free interval and centred. Several row phase offsets are tried
 *     and the one placing the most modules is kept.
 */
import type { Vec2, PlacedPanel, PanelOrientation, Mounting, PanelSpec, Obstacle } from '@/types';
import { azimuthVector, clipHalfPlane, dot, v, bbox, rectPolygon, obstacleFootprint } from './geometry';
import { deg2rad, rad2deg } from './units';
import { solarPositionAtSolarTime, winterSolsticeDoy } from './solarPosition';
import type { InstallSurface, SurfaceMount } from './structure';

export interface ModuleDims { lengthM: number; widthM: number }

export function moduleDims(p: PanelSpec): ModuleDims {
  return { lengthM: p.lengthMm / 1000, widthM: p.widthMm / 1000 };
}

/** Dimensions of a module in array coordinates. */
export function orientedDims(d: ModuleDims, o: PanelOrientation) {
  return o === 'portrait' ? { alongRow: d.widthM, slant: d.lengthM } : { alongRow: d.lengthM, slant: d.widthM };
}

/** Plan (horizontal projection) footprint of one module as a polygon. */
export function panelFootprint(p: PlacedPanel, d: ModuleDims): Vec2[] {
  const od = orientedDims(d, p.orientation);
  const depth = od.slant * Math.cos(deg2rad(p.tiltDeg));
  // rectPolygon's local x axis → along-row direction. Facing vector f = (sin az, cos az);
  // row vector r = (cos az, -sin az), whose angle from +x is -az.
  return rectPolygon(p.center, od.alongRow, depth, -p.azimuthDeg);
}

export interface RowSpacingInput {
  latitudeDeg: number;
  tiltDeg: number;
  /** Up-slope length of the table (m). */
  slantM: number;
  azimuthDeg: number;
  terrainSlopeDeg?: number;
  startHour?: number;
  endHour?: number;
}

export interface RowSpacingResult {
  pitchPlanM: number;
  gapPlanM: number;
  tableDepthPlanM: number;
  gcr: number;
  criticalSolarHour: number | null;
  criticalElevationDeg: number | null;
  criticalAzimuthDeg: number | null;
  designDoy: number;
  lowSun: boolean;
}

/**
 * calculateRowSpacing - minimum plan row pitch so that the row in front casts no shadow on
 * the next row during [startHour, endHour] (apparent solar time) on the winter solstice.
 *
 *   tan αp = tan(elevation) / cos(sunAz − arrayAz)              (profile angle)
 *   pitch_ground = L · [cos(β−s) + sin(β−s) / tan(αp + s)]       (s = terrain slope toward array)
 *   pitch_plan   = pitch_ground · cos(s)
 */
export function calculateRowSpacing(inp: RowSpacingInput): RowSpacingResult {
  const s = inp.terrainSlopeDeg ?? 0;
  const start = inp.startHour ?? 9, end = inp.endHour ?? 15;
  const doy = winterSolsticeDoy(inp.latitudeDeg);
  const betaR = deg2rad(inp.tiltDeg - s);
  const depth = inp.slantM * Math.cos(deg2rad(inp.tiltDeg));
  let best = depth, crit: { h: number; e: number; a: number } | null = null, lowSun = false;
  if (betaR > 1e-6) {
    for (let h = start; h <= end + 1e-9; h += 0.25) {
      const pos = solarPositionAtSolarTime(inp.latitudeDeg, doy, h);
      if (pos.elevationDeg <= 2) { lowSun = true; continue; }
      const cd = Math.cos(deg2rad(pos.azimuthDeg - inp.azimuthDeg));
      if (cd <= 0.02) continue; // sun behind or parallel to rows: front row cannot shade next row
      const ap = Math.atan(Math.tan(deg2rad(pos.elevationDeg)) / cd) + deg2rad(s);
      if (ap <= deg2rad(1)) { lowSun = true; continue; }
      const ground = inp.slantM * (Math.cos(betaR) + Math.sin(betaR) / Math.tan(ap));
      const plan = ground * Math.cos(deg2rad(s));
      if (plan > best) { best = plan; crit = { h, e: pos.elevationDeg, a: pos.azimuthDeg }; }
    }
  }
  // Cap unreasonable pitches at very high latitudes.
  best = Math.min(best, depth * 8);
  return {
    pitchPlanM: best,
    gapPlanM: best - depth,
    tableDepthPlanM: depth,
    gcr: inp.slantM / (best / Math.cos(deg2rad(s))),
    criticalSolarHour: crit?.h ?? null,
    criticalElevationDeg: crit?.e ?? null,
    criticalAzimuthDeg: crit?.a ?? null,
    designDoy: doy,
    lowSun,
  };
}

/**
 * Initial tilt suggestion for fixed arrays when no solar data is loaded:
 * Jacobson & Jadhav (2018) polynomial fit of optimal tilt vs latitude (Solar Energy 169).
 * Labelled ESTIMATED in the UI. When solar data is loaded, the energy model is used instead.
 */
export function suggestTiltFromLatitude(latDeg: number): number {
  const p = Math.abs(latDeg);
  const t = latDeg >= 0
    ? 1.3793 + p * (1.2011 + p * (-0.014404 + p * 0.000080509))
    : -0.41657 + p * (1.4216 + p * (0.024051 + p * 0.00021828));
  return Math.max(0, Math.min(60, t));
}

export const equatorFacingAzimuth = (latDeg: number) => (latDeg >= 0 ? 180 : 0);

export interface LayoutSettings {
  orientation: PanelOrientation;
  modulesHigh: number;
  moduleGapM: number;
  rowSpacingMode: Mounting['rowSpacingMode'];
  shadeFreeStartHour: number;
  shadeFreeEndHour: number;
  gcr: number;
  manualPitchM: number;
  walkwayEveryRows: number;
  walkwayWidthM: number;
  setbackM: number;
  latitudeDeg: number;
}

export interface SurfaceLayoutResult {
  surfaceId: string;
  panels: PlacedPanel[];
  pitchPlanM: number;
  rows: number;
  tablesPerRow: number[];
  spacing: RowSpacingResult | null;
}

export interface LayoutResult {
  panels: PlacedPanel[];
  surfaces: SurfaceLayoutResult[];
  pitchBySurface: Record<string, number>;
}

type Interval = [number, number];

function intersectIntervals(a: Interval[], b: Interval[]): Interval[] {
  const out: Interval[] = [];
  let i = 0, j = 0;
  while (i < a.length && j < b.length) {
    const lo = Math.max(a[i][0], b[j][0]);
    const hi = Math.min(a[i][1], b[j][1]);
    if (hi > lo) out.push([lo, hi]);
    if (a[i][1] < b[j][1]) i++; else j++;
  }
  return out;
}

function subtractInterval(list: Interval[], cut: Interval): Interval[] {
  const out: Interval[] = [];
  for (const [lo, hi] of list) {
    if (cut[1] <= lo || cut[0] >= hi) { out.push([lo, hi]); continue; }
    if (cut[0] > lo) out.push([lo, cut[0]]);
    if (cut[1] < hi) out.push([cut[1], hi]);
  }
  return out;
}

/** u-intervals where the line w = const lies inside polygon (local coords). */
function lineCrossings(local: Vec2[], w: number): Interval[] {
  const xs: number[] = [];
  for (let i = 0; i < local.length; i++) {
    const a = local[i], b = local[(i + 1) % local.length];
    if ((a.y > w) !== (b.y > w)) xs.push(a.x + ((w - a.y) * (b.x - a.x)) / (b.y - a.y));
  }
  xs.sort((p, q) => p - q);
  const out: Interval[] = [];
  for (let i = 0; i + 1 < xs.length; i += 2) out.push([xs[i], xs[i + 1]]);
  return out;
}

/** Intervals of u for which the whole segment w∈[wa,wb] lies inside polygon. */
export function bandIntervals(local: Vec2[], wa: number, wb: number): Interval[] {
  const eps = 1e-7;
  const lo = wa + eps, hi = wb - eps;
  const lines = [lo, hi];
  for (const p of local) if (p.y > lo && p.y < hi) { lines.push(Math.max(lo, p.y - eps), Math.min(hi, p.y + eps)); }
  let acc: Interval[] | null = null;
  for (const w of lines) {
    const c = lineCrossings(local, w);
    acc = acc === null ? c : intersectIntervals(acc, c);
    if (!acc.length) return [];
  }
  return acc ?? [];
}

let idCounter = 0;
const pid = () => `p${Date.now().toString(36)}${(idCounter++).toString(36)}`;

/**
 * calculatePanelLayout - place modules on every surface.
 */
export function calculatePanelLayout(
  surfaces: InstallSurface[],
  mounts: Record<string, SurfaceMount>,
  keepouts: Vec2[][],
  dims: ModuleDims,
  st: LayoutSettings,
): LayoutResult {
  const results: SurfaceLayoutResult[] = [];
  for (const s of surfaces) results.push(layoutSurface(s, mounts[s.id], keepouts, dims, st));
  const panels = results.flatMap((r) => r.panels);
  const pitchBySurface: Record<string, number> = {};
  for (const r of results) pitchBySurface[r.surfaceId] = r.pitchPlanM;
  return { panels, surfaces: results, pitchBySurface };
}

export function layoutSurface(s: InstallSurface, m: SurfaceMount, keepouts: Vec2[][], dims: ModuleDims, st: LayoutSettings): SurfaceLayoutResult {
  const k = Math.max(1, Math.min(4, Math.round(st.modulesHigh)));
  const od = orientedDims(dims, st.orientation);
  const gap = Math.max(0, st.moduleGapM);
  const tableSlant = k * od.slant + (k - 1) * gap;
  const cosT = Math.cos(deg2rad(m.tiltDeg));
  const depth = tableSlant * cosT;
  let spacing: RowSpacingResult | null = null;
  let pitch: number;
  if (m.racked) {
    if (st.rowSpacingMode === 'shade-free') {
      spacing = calculateRowSpacing({ latitudeDeg: st.latitudeDeg, tiltDeg: m.tiltDeg, slantM: tableSlant, azimuthDeg: m.azimuthDeg, terrainSlopeDeg: m.terrainSlopeDeg, startHour: st.shadeFreeStartHour, endHour: st.shadeFreeEndHour });
      pitch = spacing.pitchPlanM;
    } else if (st.rowSpacingMode === 'gcr') {
      pitch = (tableSlant / Math.max(0.1, Math.min(1, st.gcr))) * Math.cos(deg2rad(m.terrainSlopeDeg));
    } else pitch = st.manualPitchM;
    pitch = Math.max(pitch, depth + 0.02);
  } else {
    pitch = depth + gap * cosT;
  }

  const f = azimuthVector(m.azimuthDeg);
  const r = v(f.y, -f.x);
  const toLocal = (p: Vec2) => v(dot(p, r), dot(p, f));
  const toWorld = (u: number, w: number) => v(r.x * u + f.x * w, r.y * u + f.y * w);
  const local = s.polygon.map(toLocal);
  const lb = bbox(local);
  const kLocal = keepouts.map((kp) => kp.map(toLocal)).map((kp) => ({ kp, b: bbox(kp) }));
  const setback = Math.max(0, st.setbackM);
  const cell = od.alongRow + gap;

  const runPhase = (phase: number) => {
    const placed: { u: number; wFront: number; row: number }[] = [];
    const tablesPerRow: number[] = [];
    let wFront = lb.maxY - setback - phase;
    let row = 0;
    while (wFront - depth >= lb.minY + setback - 1e-9) {
      const wa = wFront - depth - setback, wb = wFront + setback;
      let iv = bandIntervals(local, wa, wb).map(([lo, hi]) => [lo + setback, hi - setback] as Interval).filter(([lo, hi]) => hi - lo >= od.alongRow);
      if (iv.length) {
        for (const { kp, b } of kLocal) {
          if (b.maxY <= wFront - depth || b.minY >= wFront) continue;
          let c = clipHalfPlane(kp, v(0, 1), wFront - depth);
          c = clipHalfPlane(c, v(0, -1), -wFront);
          if (c.length < 2) continue;
          const xs = c.map((p) => p.x);
          iv = subtractInterval(iv, [Math.min(...xs), Math.max(...xs)]);
        }
      }
      let count = 0;
      for (const [lo, hi] of iv) {
        const n = Math.floor((hi - lo + gap + 1e-9) / cell);
        if (n <= 0) continue;
        const used = n * cell - gap;
        const start = lo + (hi - lo - used) / 2;
        for (let i = 0; i < n; i++) placed.push({ u: start + i * cell, wFront, row });
        count += n;
      }
      tablesPerRow.push(count);
      row++;
      wFront -= pitch;
      if (st.walkwayEveryRows > 0 && row % st.walkwayEveryRows === 0) wFront -= st.walkwayWidthM;
    }
    return { placed, tablesPerRow };
  };

  const phases = 8;
  let best = runPhase(0);
  for (let i = 1; i < phases; i++) {
    const res = runPhase((pitch * i) / phases);
    if (res.placed.length > best.placed.length) best = res;
  }

  const panels: PlacedPanel[] = [];
  const modDepth = od.slant * cosT;
  const gapPlan = gap * cosT;
  for (const t of best.placed) {
    for (let j = 0; j < k; j++) {
      const wc = t.wFront - j * (modDepth + gapPlan) - modDepth / 2;
      const uc = t.u + od.alongRow / 2;
      panels.push({
        id: pid(), surfaceId: s.id, center: toWorld(uc, wc), azimuthDeg: m.azimuthDeg, tiltDeg: m.tiltDeg,
        orientation: st.orientation, row: t.row, stackIndex: j, locked: false, manual: false,
      });
    }
  }
  const rowsUsed = best.tablesPerRow.filter((n) => n > 0).length;
  return { surfaceId: s.id, panels, pitchPlanM: pitch, rows: rowsUsed, tablesPerRow: best.tablesPerRow.filter((n) => n > 0), spacing };
}

export interface LayoutStats {
  panelCount: number;
  dcKwp: number;
  moduleAreaM2: number;
  footprintAreaM2: number;
  rows: number;
  utilizationPct: number;
  usableUtilizationPct: number;
  remainingAreaM2: number;
  maxPerRow: number;
}

export function calculateLayoutStats(panels: PlacedPanel[], spec: PanelSpec, roofPlanAreaM2: number, usableAreaM2: number): LayoutStats {
  const d = moduleDims(spec);
  let footprint = 0;
  const rowKeys = new Map<string, number>();
  for (const p of panels) {
    footprint += d.lengthM * d.widthM * Math.cos(deg2rad(p.tiltDeg));
    if (p.row >= 0) {
      const key = `${p.surfaceId}:${p.row}`;
      rowKeys.set(key, (rowKeys.get(key) ?? 0) + 1);
    }
  }
  const moduleArea = panels.length * d.lengthM * d.widthM;
  return {
    panelCount: panels.length,
    dcKwp: (panels.length * spec.powerW) / 1000,
    moduleAreaM2: moduleArea,
    footprintAreaM2: footprint,
    rows: rowKeys.size,
    utilizationPct: roofPlanAreaM2 > 0 ? (footprint / roofPlanAreaM2) * 100 : 0,
    usableUtilizationPct: usableAreaM2 > 0 ? (footprint / usableAreaM2) * 100 : 0,
    remainingAreaM2: Math.max(0, usableAreaM2 - footprint),
    maxPerRow: Math.max(0, ...rowKeys.values()),
  };
}

/** Panels whose footprint leaves the boundary or hits a keep-out (for manual-edit validation). */
export function findInvalidPanels(panels: PlacedPanel[], dims: ModuleDims, boundary: Vec2[], obstacles: Obstacle[], convexInside: (a: Vec2[], b: Vec2[]) => boolean, overlap: (a: Vec2[], b: Vec2[]) => boolean): Set<string> {
  const bad = new Set<string>();
  const keep = obstacles.map((o) => obstacleFootprint(o, o.bufferM));
  const kb = keep.map((k) => bbox(k));
  for (const p of panels) {
    const fp = panelFootprint(p, dims);
    if (!convexInside(fp, boundary)) { bad.add(p.id); continue; }
    const b = bbox(fp);
    for (let i = 0; i < keep.length; i++) {
      if (b.maxX < kb[i].minX || b.minX > kb[i].maxX || b.maxY < kb[i].minY || b.minY > kb[i].maxY) continue;
      if (overlap(fp, keep[i])) { bad.add(p.id); break; }
    }
  }
  return bad;
}

export const angleBetween = (a: number, b: number) => rad2deg(Math.acos(Math.cos(deg2rad(a - b))));
