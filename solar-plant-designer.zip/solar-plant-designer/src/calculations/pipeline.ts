/**
 * End-to-end pipeline:
 * STRUCTURE → GEOMETRY → AVAILABLE AREA → PANEL LAYOUT → SOLAR POSITION → IRRADIANCE
 * → SHADOW → LOSSES → ENERGY MODEL → MONTHLY / ANNUAL GENERATION.
 * Pure functions of a Project; run inside a Web Worker for large layouts.
 */
import type { Project, AnalysisResult, PlacedPanel, Mounting, PanelOrientation, RowSpacingMode } from '@/types';
import { buildSurfaces, surfaceMount, keepoutPolygons, parapetSegments, type InstallSurface, type SurfaceMount } from './structure';
import { calculatePanelLayout, moduleDims, orientedDims, type LayoutResult } from './panelLayout';
import { buildShadowCasters, buildShadingScene } from './shading';
import { calculateMonthlyEnergy, calculateDailySeries, calculateSpecificYield, calculatePerformanceRatio, calculateCapacityFactor, type EnergyInput, type EnergySurfaceInput } from './energy';
import { polygonArea, pointInPolygon } from './geometry';

export function mountsFor(surfaces: InstallSurface[], m: Mounting): Record<string, SurfaceMount> {
  const out: Record<string, SurfaceMount> = {};
  for (const s of surfaces) out[s.id] = surfaceMount(s, m);
  return out;
}

export function layoutSettingsFor(p: Project, overrides: Partial<Mounting> = {}) {
  const m = { ...p.mounting, ...overrides };
  return {
    orientation: m.orientation, modulesHigh: m.modulesHigh, moduleGapM: m.moduleGapM,
    rowSpacingMode: m.rowSpacingMode, shadeFreeStartHour: m.shadeFreeStartHour, shadeFreeEndHour: m.shadeFreeEndHour,
    gcr: m.gcr, manualPitchM: m.manualPitchM, walkwayEveryRows: m.walkwayEveryRows, walkwayWidthM: m.walkwayWidthM,
    setbackM: p.structure.setbackM, latitudeDeg: p.location.latitude,
  };
}

/** Generate an automatic layout for the project (optionally overriding mounting settings). */
export function generateLayout(p: Project, overrides: Partial<Mounting> = {}): LayoutResult {
  const m = { ...p.mounting, ...overrides };
  const surfaces = buildSurfaces(p.structure, m);
  const inside = p.obstacles.filter((o) => pointInPolygon(o.center, p.structure.boundary) || o.kind === 'walkway' || o.kind === 'exclusion');
  return calculatePanelLayout(surfaces, mountsFor(surfaces, m), keepoutPolygons(inside), moduleDims(p.panel), layoutSettingsFor(p, overrides));
}

function rowStats(panels: PlacedPanel[], surfaceId: string) {
  const rows = new Map<number, number>();
  for (const pnl of panels) if (pnl.surfaceId === surfaceId && pnl.row >= 0) rows.set(pnl.row, (rows.get(pnl.row) ?? 0) + 1);
  if (!rows.size) return { frontShare: 1 };
  const minRow = Math.min(...rows.keys());
  const total = [...rows.values()].reduce((a, b) => a + b, 0);
  return { frontShare: (rows.get(minRow) ?? 0) / total };
}

export function buildEnergyInput(p: Project, panels: PlacedPanel[], pitchBySurface: Record<string, number>, withShading = true): EnergyInput {
  if (!p.solarResource) throw new Error('Solar resource data is not loaded.');
  const surfaces = buildSurfaces(p.structure, p.mounting);
  const mounts = mountsFor(surfaces, p.mounting);
  const dims = moduleDims(p.panel);
  const casters = buildShadowCasters(p.obstacles, surfaces, parapetSegments(p.structure), p.structure.parapetHeightM, p.structure.eaveHeightM);
  const racked: Record<string, boolean> = {};
  for (const s of surfaces) racked[s.id] = mounts[s.id].racked;
  const scene = withShading && casters.length && panels.length ? buildShadingScene(panels, dims, surfaces, casters, p.mounting.clearanceM, racked) : null;
  const k = Math.max(1, Math.min(4, Math.round(p.mounting.modulesHigh)));
  const od = orientedDims(dims, p.mounting.orientation);
  const tableSlant = k * od.slant + (k - 1) * p.mounting.moduleGapM;
  const sInputs: EnergySurfaceInput[] = [];
  // Group panels by surface + actual facing/tilt (manual panels may differ)
  const groups = new Map<string, number[]>();
  panels.forEach((pn, i) => {
    const key = `${pn.surfaceId}|${pn.tiltDeg.toFixed(1)}|${pn.azimuthDeg.toFixed(1)}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(i);
  });
  for (const [key, idx] of groups) {
    const [sid, tilt, az] = key.split('|');
    const s = surfaces.find((x) => x.id === sid);
    const mt = mounts[sid] ?? { racked: false, terrainSlopeDeg: 0 };
    const rs = rowStats(panels, sid);
    sInputs.push({
      id: key, name: s ? s.name : sid, tiltDeg: Number(tilt), azimuthDeg: Number(az), panelIndices: idx,
      kWp: (idx.length * p.panel.powerW) / 1000, uValue: mt.racked || s?.kind === 'ground' ? 29 : 20,
      racked: mt.racked, tableSlantM: tableSlant, pitchPlanM: pitchBySurface[sid] ?? tableSlant,
      terrainSlopeDeg: mt.terrainSlopeDeg, frontRowShare: rs.frontShare,
      seasonalTiltsDeg: p.mounting.type === 'adjustable-tilt' && p.mounting.seasonalTiltsDeg && mt.racked ? p.mounting.seasonalTiltsDeg : null,
    });
  }
  const acLimit = p.electrical.enabled ? p.electrical.inverter.acPowerKw * p.electrical.inverterQty : null;
  return {
    latitudeDeg: p.location.latitude, resource: p.solarResource, surfaces: sInputs,
    moduleEfficiency: p.panel.efficiencyPct / 100, gammaPctPerC: p.panel.tempCoeffPmaxPctPerC,
    losses: p.losses, acLimitKw: acLimit, scene,
  };
}

/** Stable signature of everything that affects the analysis. */
export function analysisSignature(p: Project): string {
  const s = JSON.stringify([p.location.latitude, p.location.longitude, p.structure, p.obstacles, p.panel, p.mounting, p.layout.panels.length, p.layout.panels.slice(0, 50).map((x) => [x.center.x, x.center.y, x.tiltDeg, x.azimuthDeg]), p.layout.pitchBySurface, p.electrical, p.losses, p.solarResource?.fetchedAt, p.solarResource?.provider]);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0).toString(16);
}

/** runAnalysis - full energy analysis of the current layout. */
export function runAnalysis(p: Project): AnalysisResult {
  const panels = p.layout.panels;
  const input = buildEnergyInput(p, panels, p.layout.pitchBySurface, true);
  const out = calculateMonthlyEnergy(input);
  const dcKwp = (panels.length * p.panel.powerW) / 1000;
  const annualAc = out.months.reduce((a, m) => a + m.acKwh, 0);
  const annualGhi = out.months.reduce((a, m) => a + m.ghiKwhM2, 0);
  const annualPoa = out.months.reduce((a, m) => a + m.poaKwhM2, 0);
  const daily = calculateDailySeries(input, out.months);
  const stages = out.stages.map((s, i) => {
    const before = i === 0 ? s.after : out.stages[i - 1].after;
    return { key: s.key, label: s.label, energyAfterKwh: s.after, lossKwh: before - s.after, lossPct: before > 0 ? ((before - s.after) / before) * 100 : 0, source: s.source };
  });
  const warnings: string[] = [];
  const assumptions: string[] = [
    'Typical-year model from long-term monthly mean daily GHI; representative day per month (Klein 1977).',
    'Hourly split: Erbs daily diffuse fraction, Collares-Pereira & Rabl and Liu & Jordan hourly ratios.',
    'Transposition: Hay-Davies sky diffuse; isotropic ground reflection with albedo ' + p.losses.albedo + '.',
    'Cell temperature: Faiman-type model, U = 29 W/m²K racked / 20 W/m²K flush, absorptance 0.9.',
    'Shading applied to beam irradiance only; electrical mismatch from partial shading not modelled.',
    'Clock times shown in standard time (UTC offset ' + p.location.utcOffsetHours + ' h); daylight saving is not modelled.',
  ];
  if (out.tempAmplitudeAssumed) assumptions.push('Daily ambient temperature range not supplied by the data source: ±5 °C diurnal swing assumed.');
  if (p.solarResource?.isDemo) warnings.push('DEMO solar data in use - results are illustrative and must not be used for decisions.');
  if (p.losses.shadingOverridePct !== null) warnings.push('Shading loss is a user override; computed shading was not applied.');
  if (!panels.length) warnings.push('The layout has no panels.');
  if (p.electrical.enabled) {
    const clip = stages.find((s) => s.key === 'clipping');
    if (clip && clip.lossPct > 0.01) assumptions.push('Clipping is estimated on average-day profiles and under-represents clear-day clipping.');
  }
  const surfaces = input.surfaces.map((s, i) => ({ surfaceId: s.id, name: s.name, panelCount: s.panelIndices.length, kWp: s.kWp, tiltDeg: s.tiltDeg, azimuthDeg: s.azimuthDeg, annualPoaKwhM2: out.surfacePoa[i] }));
  return {
    computedAt: new Date().toISOString(),
    inputSignature: analysisSignature(p),
    isDemoData: !!p.solarResource?.isDemo,
    providerLabel: p.solarResource?.providerLabel ?? '',
    dcKwp,
    acKw: p.electrical.enabled ? p.electrical.inverter.acPowerKw * p.electrical.inverterQty : null,
    months: out.months,
    daily,
    annualGhiKwhM2: annualGhi,
    annualPoaKwhM2: annualPoa,
    annualAcKwh: annualAc,
    specificYield: calculateSpecificYield(annualAc, dcKwp),
    performanceRatio: calculatePerformanceRatio(annualAc, dcKwp, annualPoa),
    capacityFactorDc: calculateCapacityFactor(annualAc, dcKwp),
    lossStages: stages,
    surfaces,
    warnings,
    assumptions,
  };
}

export interface LayoutOption {
  id: string;
  label: string;
  orientation: PanelOrientation;
  spacingMode: RowSpacingMode;
  spacingNote: string;
  panelCount: number;
  dcKwp: number;
  pitchM: number | null;
  utilizationPct: number;
  maintenanceAreaM2: number;
  annualKwh: number | null;
  specificYield: number | null;
  shadingLossPct: number | null;
  layout: LayoutResult;
  overrides: Partial<Mounting>;
}

/** Evaluate alternative configurations. No option is labelled "best"; the user chooses. */
export function generateLayoutOptions(p: Project): LayoutOption[] {
  const surfaces = buildSurfaces(p.structure, p.mounting);
  const anyRacked = surfaces.some((s) => surfaceMount(s, p.mounting).racked);
  const variants: { label: string; o: Partial<Mounting>; note: string }[] = [];
  const orients: PanelOrientation[] = ['portrait', 'landscape'];
  for (const orientation of orients) {
    if (anyRacked) {
      variants.push({ label: `${cap(orientation)} · shade-free 09-15`, o: { orientation, rowSpacingMode: 'shade-free', shadeFreeStartHour: 9, shadeFreeEndHour: 15 }, note: 'No row shading 09:00-15:00 solar time on winter solstice' });
      variants.push({ label: `${cap(orientation)} · shade-free 10-14`, o: { orientation, rowSpacingMode: 'shade-free', shadeFreeStartHour: 10, shadeFreeEndHour: 14 }, note: 'No row shading 10:00-14:00 solar time on winter solstice' });
      variants.push({ label: `${cap(orientation)} · GCR 0.60`, o: { orientation, rowSpacingMode: 'gcr', gcr: 0.6 }, note: 'Ground coverage ratio 0.60 (denser, more row shading)' });
    } else {
      variants.push({ label: `${cap(orientation)} · flush`, o: { orientation }, note: 'Roof-following, no inter-row spacing' });
    }
  }
  const roofArea = polygonArea(p.structure.boundary);
  const dims = moduleDims(p.panel);
  return variants.map((vv, i) => {
    const layout = generateLayout(p, vv.o);
    const n = layout.panels.length;
    const dcKwp = (n * p.panel.powerW) / 1000;
    let footprint = 0;
    for (const pn of layout.panels) footprint += dims.lengthM * dims.widthM * Math.cos((pn.tiltDeg * Math.PI) / 180);
    let annualKwh: number | null = null, sy: number | null = null, shade: number | null = null;
    if (p.solarResource && n > 0) {
      const proj: Project = { ...p, mounting: { ...p.mounting, ...vv.o } };
      const input = buildEnergyInput(proj, layout.panels, layout.pitchBySurface, true);
      const out = calculateMonthlyEnergy(input);
      annualKwh = out.months.reduce((a, m) => a + m.acKwh, 0);
      sy = dcKwp > 0 ? annualKwh / dcKwp : null;
      const nom = out.stages[0].after, sh = out.stages[1].after;
      shade = nom > 0 ? (1 - sh / nom) * 100 : 0;
    }
    const pitches = Object.values(layout.pitchBySurface);
    return {
      id: `opt-${i}`, label: vv.label, orientation: vv.o.orientation ?? p.mounting.orientation,
      spacingMode: vv.o.rowSpacingMode ?? p.mounting.rowSpacingMode, spacingNote: vv.note,
      panelCount: n, dcKwp, pitchM: pitches.length ? pitches[0] : null,
      utilizationPct: roofArea > 0 ? (footprint / roofArea) * 100 : 0,
      maintenanceAreaM2: Math.max(0, roofArea - footprint),
      annualKwh, specificYield: sy, shadingLossPct: shade, layout, overrides: vv.o,
    };
  });
}

const cap = (s: string) => s[0].toUpperCase() + s.slice(1);

/**
 * Tilt that maximises annual POA irradiation for an unshaded equator-facing plane
 * (energy-model based). Returns null without solar data.
 */
export function optimiseTilt(p: Project): { tiltDeg: number; poaKwhM2: number } | null {
  if (!p.solarResource) return null;
  let best = { tiltDeg: 0, poaKwhM2: -1 };
  for (let t = 0; t <= 60; t += 1) {
    const input: EnergyInput = {
      latitudeDeg: p.location.latitude, resource: p.solarResource, moduleEfficiency: 0.2, gammaPctPerC: 0, losses: p.losses, acLimitKw: null, scene: null, stepHours: 1,
      surfaces: [{ id: 't', name: 't', tiltDeg: t, azimuthDeg: p.mounting.azimuthDeg, panelIndices: [], kWp: 1, uValue: 29, racked: false, tableSlantM: 1, pitchPlanM: 1, terrainSlopeDeg: 0, frontRowShare: 1, seasonalTiltsDeg: null }],
    };
    const out = calculateMonthlyEnergy(input);
    const poa = out.surfacePoa[0];
    if (poa > best.poaKwhM2) best = { tiltDeg: t, poaKwhM2: poa };
  }
  return best;
}
