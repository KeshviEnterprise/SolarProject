/**
 * Preliminary string sizing. Temperature-corrected module voltages:
 *   Voc(Tmin)  = Voc_STC · [1 + βVoc·(Tmin − 25)]           (cold morning, cell ≈ ambient)
 *   Vmp(Thot)  = Vmp_STC · [1 + βVoc·(Tcell_hot − 25)]      (βVoc used as proxy for βVmp)
 *   Tcell_hot  = Tamb_max + 30 °C                            (assumed irradiance heating)
 * This is a preliminary design calculation and must be verified by a qualified electrical engineer.
 */
import type { PanelSpec, InverterSpec } from '@/types';

export const HOT_CELL_RISE_C = 30;

export interface StringInput {
  panel: PanelSpec;
  inverter: InverterSpec;
  inverterQty: number;
  modulesPerString: number;
  stringsTotal: number;
  minAmbientC: number;
  maxAmbientC: number;
  layoutPanelCount: number;
}

export interface StringResult {
  vocColdModuleV: number;
  vmpHotModuleV: number;
  vmpColdModuleV: number;
  stringVocColdV: number;
  stringVocStcV: number;
  stringVmpStcV: number;
  stringVmpHotV: number;
  stringIscA: number;
  stringImpA: number;
  modulesInStrings: number;
  dcKwp: number;
  acKw: number;
  dcAcRatio: number;
  stringsPerInverter: number;
  stringsPerMppt: number;
  mpptInputCurrentA: number;
  minModulesPerString: number;
  maxModulesPerString: number;
  warnings: { level: 'error' | 'warning'; message: string }[];
}

export function moduleVoltageAt(vStc: number, betaPctPerC: number, cellTempC: number) {
  return vStc * (1 + (betaPctPerC / 100) * (cellTempC - 25));
}

/** calculateStringConfiguration - string voltages/currents and validation warnings. */
export function calculateStringConfiguration(i: StringInput): StringResult {
  const { panel: p, inverter: inv } = i;
  const vocCold = moduleVoltageAt(p.vocV, p.tempCoeffVocPctPerC, i.minAmbientC);
  const vmpHot = moduleVoltageAt(p.vmpV, p.tempCoeffVocPctPerC, i.maxAmbientC + HOT_CELL_RISE_C);
  const vmpCold = moduleVoltageAt(p.vmpV, p.tempCoeffVocPctPerC, i.minAmbientC);
  const n = Math.max(0, Math.round(i.modulesPerString));
  const strings = Math.max(0, Math.round(i.stringsTotal));
  const qty = Math.max(1, Math.round(i.inverterQty));
  const modulesInStrings = n * strings;
  const dcKwp = (modulesInStrings * p.powerW) / 1000;
  const acKw = qty * inv.acPowerKw;
  const stringsPerInverter = strings / qty;
  const stringsPerMppt = Math.ceil(stringsPerInverter / Math.max(1, inv.mpptCount));
  const mpptCurrent = stringsPerMppt * p.iscA;
  const maxN = vocCold > 0 ? Math.floor(inv.maxDcVoltageV / vocCold) : 0;
  const minN = vmpHot > 0 ? Math.ceil(inv.mpptMinV / vmpHot) : 0;
  const w: StringResult['warnings'] = [];
  if (n * vocCold > inv.maxDcVoltageV) w.push({ level: 'error', message: `String Voc at ${i.minAmbientC} °C (${(n * vocCold).toFixed(0)} V) exceeds inverter maximum DC voltage (${inv.maxDcVoltageV} V). Use at most ${maxN} modules per string.` });
  if (n * vmpHot < inv.mpptMinV) w.push({ level: 'warning', message: `String Vmp at hot cell temperature (${(n * vmpHot).toFixed(0)} V) is below MPPT minimum (${inv.mpptMinV} V). Use at least ${minN} modules per string.` });
  if (n * vmpCold > inv.mpptMaxV) w.push({ level: 'warning', message: `String Vmp when cold (${(n * vmpCold).toFixed(0)} V) is above the MPPT maximum (${inv.mpptMaxV} V).` });
  if (mpptCurrent > inv.maxInputCurrentPerMpptA) w.push({ level: 'warning', message: `${stringsPerMppt} string(s) per MPPT draw up to ${mpptCurrent.toFixed(1)} A Isc, above the ${inv.maxInputCurrentPerMpptA} A MPPT input limit.` });
  if (modulesInStrings > i.layoutPanelCount) w.push({ level: 'error', message: `Strings need ${modulesInStrings} modules but the layout has ${i.layoutPanelCount}.` });
  else if (modulesInStrings < i.layoutPanelCount) w.push({ level: 'warning', message: `${i.layoutPanelCount - modulesInStrings} module(s) in the layout are not assigned to any string.` });
  const ratio = acKw > 0 ? dcKwp / acKw : 0;
  if (ratio > 1.4) w.push({ level: 'warning', message: `DC/AC ratio ${ratio.toFixed(2)} is high; expect significant clipping.` });
  if (ratio > 0 && ratio < 0.9) w.push({ level: 'warning', message: `DC/AC ratio ${ratio.toFixed(2)} is low; the inverter is oversized for the array.` });
  if (!Number.isInteger(stringsPerInverter)) w.push({ level: 'warning', message: `${strings} strings do not divide evenly across ${qty} inverter(s).` });
  return {
    vocColdModuleV: vocCold, vmpHotModuleV: vmpHot, vmpColdModuleV: vmpCold,
    stringVocColdV: n * vocCold, stringVocStcV: n * p.vocV, stringVmpStcV: n * p.vmpV, stringVmpHotV: n * vmpHot,
    stringIscA: p.iscA, stringImpA: p.impA,
    modulesInStrings, dcKwp, acKw, dcAcRatio: ratio,
    stringsPerInverter, stringsPerMppt, mpptInputCurrentA: mpptCurrent,
    minModulesPerString: minN, maxModulesPerString: maxN, warnings: w,
  };
}

/**
 * Suggest a string configuration: modules per string in [minN, maxN] that leaves the fewest
 * modules unassigned (ties → longer strings), strings rounded to a multiple of inverter count.
 */
export function suggestStringConfiguration(panel: PanelSpec, inverter: InverterSpec, inverterQty: number, panelCount: number, minAmbientC: number, maxAmbientC: number) {
  const vocCold = moduleVoltageAt(panel.vocV, panel.tempCoeffVocPctPerC, minAmbientC);
  const vmpHot = moduleVoltageAt(panel.vmpV, panel.tempCoeffVocPctPerC, maxAmbientC + HOT_CELL_RISE_C);
  const vmpCold = moduleVoltageAt(panel.vmpV, panel.tempCoeffVocPctPerC, minAmbientC);
  const maxN = Math.min(Math.floor(inverter.maxDcVoltageV / vocCold), Math.floor(inverter.mpptMaxV / vmpCold));
  const minN = Math.ceil(inverter.mpptMinV / vmpHot);
  const qty = Math.max(1, inverterQty);
  let best: { n: number; strings: number; left: number } | null = null;
  for (let n = maxN; n >= minN; n--) {
    let strings = Math.floor(panelCount / n);
    strings -= strings % qty;
    if (strings <= 0) continue;
    const left = panelCount - n * strings;
    if (!best || left < best.left) best = { n, strings, left };
  }
  return best ? { modulesPerString: best.n, stringsTotal: best.strings, unassigned: best.left, minN, maxN } : null;
}
