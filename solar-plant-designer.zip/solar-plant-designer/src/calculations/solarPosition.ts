/**
 * Solar position using the NOAA General Solar Position equations
 * (Spencer 1971 Fourier series for declination and equation of time).
 * Accuracy: roughly ±0.5° in elevation/azimuth, ±1-2 min in sunrise/sunset,
 * which is adequate for preliminary PV design and shadow sketches.
 *
 * Conventions: azimuth in degrees clockwise from true north; elevation above horizon.
 */
import { deg2rad, rad2deg, norm360, clamp } from './units';

export interface SolarPosition {
  elevationDeg: number;
  /** Elevation including an approximate atmospheric refraction correction. */
  apparentElevationDeg: number;
  azimuthDeg: number;
  zenithDeg: number;
  declinationDeg: number;
  equationOfTimeMin: number;
  hourAngleDeg: number;
}

export function isLeapYear(y: number) {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
}

export function dayOfYear(year: number, month: number /* 0-11 */, day: number): number {
  const cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  return cum[month] + day + (month > 1 && isLeapYear(year) ? 1 : 0);
}

export const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
export const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const MONTH_SHORT = MONTH_NAMES.map((m) => m.slice(0, 3));
/** Klein (1977) recommended mean day of each month (day of year). */
export const REPRESENTATIVE_DOY = [17, 47, 75, 105, 135, 162, 198, 228, 258, 288, 318, 344];

/** Fractional year γ (rad) per NOAA. */
function fractionalYear(doy: number, hour: number, daysInYear = 365) {
  return ((2 * Math.PI) / daysInYear) * (doy - 1 + (hour - 12) / 24);
}

/** Solar declination (deg) - Spencer series. */
export function declinationDeg(doy: number, hour = 12): number {
  const g = fractionalYear(doy, hour);
  const d = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g)
    + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  return rad2deg(d);
}

/** Equation of time (minutes). */
export function equationOfTimeMin(doy: number, hour = 12): number {
  const g = fractionalYear(doy, hour);
  return 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
}

/** Approximate refraction correction (deg) - NOAA/Saemundsson form. */
export function refractionDeg(elevDeg: number): number {
  if (elevDeg > 85) return 0;
  const te = Math.tan(deg2rad(elevDeg));
  let r: number;
  if (elevDeg > 5) r = 58.1 / te - 0.07 / te ** 3 + 0.000086 / te ** 5;
  else if (elevDeg > -0.575) r = 1735 + elevDeg * (-518.2 + elevDeg * (103.4 + elevDeg * (-12.79 + elevDeg * 0.711)));
  else r = -20.772 / te;
  return r / 3600;
}

/** Core: position from latitude, declination and hour angle. */
export function positionFromHourAngle(latDeg: number, declDeg: number, hourAngleDeg: number) {
  const phi = deg2rad(latDeg), d = deg2rad(declDeg), H = deg2rad(hourAngleDeg);
  const cosZ = clamp(Math.sin(phi) * Math.sin(d) + Math.cos(phi) * Math.cos(d) * Math.cos(H), -1, 1);
  const zen = Math.acos(cosZ);
  const az = norm360(rad2deg(Math.atan2(Math.sin(H), Math.cos(H) * Math.sin(phi) - Math.tan(d) * Math.cos(phi))) + 180);
  return { zenithDeg: rad2deg(zen), elevationDeg: 90 - rad2deg(zen), azimuthDeg: az };
}

/**
 * calculateSolarPosition - solar position for a local clock time.
 * @param latDeg latitude (deg, north positive)
 * @param lonDeg longitude (deg, east positive)
 * @param doy day of year (1-366)
 * @param clockHour local standard clock time (hours, decimal)
 * @param utcOffsetHours time-zone offset of that clock (e.g. +5.5 for IST)
 */
export function calculateSolarPosition(latDeg: number, lonDeg: number, doy: number, clockHour: number, utcOffsetHours: number): SolarPosition {
  const eot = equationOfTimeMin(doy, clockHour - utcOffsetHours);
  const decl = declinationDeg(doy, clockHour - utcOffsetHours);
  const timeOffset = eot + 4 * lonDeg - 60 * utcOffsetHours;
  const tst = clockHour * 60 + timeOffset;
  const ha = tst / 4 - 180;
  const p = positionFromHourAngle(latDeg, decl, ha);
  return {
    ...p,
    apparentElevationDeg: p.elevationDeg + refractionDeg(p.elevationDeg),
    declinationDeg: decl,
    equationOfTimeMin: eot,
    hourAngleDeg: ha,
  };
}

/** Solar position at a given apparent solar time (hours), used by the energy model. */
export function solarPositionAtSolarTime(latDeg: number, doy: number, solarHour: number) {
  const decl = declinationDeg(doy, solarHour);
  const ha = 15 * (solarHour - 12);
  return { ...positionFromHourAngle(latDeg, decl, ha), declinationDeg: decl, hourAngleDeg: ha };
}

/** Convert apparent solar time to local standard clock time. */
export function solarToClock(solarHour: number, lonDeg: number, utcOffsetHours: number, doy: number): number {
  return solarHour - (equationOfTimeMin(doy) + 4 * lonDeg - 60 * utcOffsetHours) / 60;
}
export function clockToSolar(clockHour: number, lonDeg: number, utcOffsetHours: number, doy: number): number {
  return clockHour + (equationOfTimeMin(doy) + 4 * lonDeg - 60 * utcOffsetHours) / 60;
}

export interface SunTimes {
  /** Local clock hours; null when the sun does not rise/set (polar day/night). */
  sunrise: number | null;
  sunset: number | null;
  solarNoon: number;
  dayLengthHours: number;
  polar: 'day' | 'night' | null;
  maxElevationDeg: number;
}

/**
 * calculateSunriseSunset - NOAA sunrise/sunset (zenith 90.833° incl. refraction and solar disc).
 */
export function calculateSunriseSunset(latDeg: number, lonDeg: number, doy: number, utcOffsetHours: number): SunTimes {
  const decl = deg2rad(declinationDeg(doy));
  const eot = equationOfTimeMin(doy);
  const phi = deg2rad(latDeg);
  const noonMinUtc = 720 - 4 * lonDeg - eot;
  const solarNoon = noonMinUtc / 60 + utcOffsetHours;
  const cosH = Math.cos(deg2rad(90.833)) / (Math.cos(phi) * Math.cos(decl)) - Math.tan(phi) * Math.tan(decl);
  const maxElevationDeg = 90 - Math.abs(latDeg - rad2deg(decl));
  if (cosH > 1) return { sunrise: null, sunset: null, solarNoon, dayLengthHours: 0, polar: 'night', maxElevationDeg };
  if (cosH < -1) return { sunrise: null, sunset: null, solarNoon, dayLengthHours: 24, polar: 'day', maxElevationDeg };
  const Hdeg = rad2deg(Math.acos(cosH));
  const sunrise = (720 - 4 * (lonDeg + Hdeg) - eot) / 60 + utcOffsetHours;
  const sunset = (720 - 4 * (lonDeg - Hdeg) - eot) / 60 + utcOffsetHours;
  return { sunrise, sunset, solarNoon, dayLengthHours: (8 * Hdeg) / 60, polar: null, maxElevationDeg };
}

export function formatClock(hours: number | null): string {
  if (hours === null || !isFinite(hours)) return '—';
  let h = ((hours % 24) + 24) % 24;
  let m = Math.round((h - Math.floor(h)) * 60);
  h = Math.floor(h);
  if (m === 60) { m = 0; h = (h + 1) % 24; }
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function formatDuration(hours: number): string {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  return `${h} h ${String(m).padStart(2, '0')} min`;
}

/** Sun path samples for a day (clock time), elevation > 0 only. */
export function sunPathForDay(latDeg: number, lonDeg: number, doy: number, utcOffsetHours: number, stepMin = 10) {
  const out: { clockHour: number; elevationDeg: number; azimuthDeg: number }[] = [];
  for (let m = 0; m <= 24 * 60; m += stepMin) {
    const h = m / 60;
    const p = calculateSolarPosition(latDeg, lonDeg, doy, h, utcOffsetHours);
    if (p.elevationDeg > 0) out.push({ clockHour: h, elevationDeg: p.elevationDeg, azimuthDeg: p.azimuthDeg });
  }
  return out;
}

/** Winter solstice day-of-year for the hemisphere of `latDeg`. */
export const winterSolsticeDoy = (latDeg: number) => (latDeg >= 0 ? 355 : 172);
export const summerSolsticeDoy = (latDeg: number) => (latDeg >= 0 ? 172 : 355);
