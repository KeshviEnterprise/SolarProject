/**
 * Shadow engine (planar approximation).
 *
 *  - Obstacles are vertical prisms (footprint polygon × height). Shadows are projected along the
 *    sun ray onto each receiver plane (roof plane + module offset), so sloped roofs are handled
 *    exactly for convex prisms. Horizontal-plane shadows (2D overlay) use shadowPolygon().
 *  - Row-to-row shading on racked arrays uses the analytic profile-angle formula.
 *  - A module is sampled at 5 points (corners + centre); shaded fraction = shaded samples / 5.
 * The engine is isolated behind these functions so it can be replaced by a ray-traced model.
 */
import type { Vec2, Obstacle, PlacedPanel } from '@/types';
import { add, scale, convexHull, pointInPolygon, bbox, type BBox, obstacleFootprint, azimuthVector } from './geometry';
import { deg2rad, clamp } from './units';
import { panelFootprint, type ModuleDims, orientedDims } from './panelLayout';
import { surfaceHeightAt, type InstallSurface } from './structure';

export const NON_SHADING_KINDS = new Set(['exclusion', 'walkway', 'skylight']);

export interface ShadowCaster {
  id: string;
  label: string;
  footprint: Vec2[];
  /** Absolute top height above ground (m). */
  topZ: number;
  baseZ: number;
}

/** Shadow length (m) on a horizontal plane for an object of height h (m). */
export function calculateShadowLength(heightM: number, elevationDeg: number): number {
  if (elevationDeg <= 0) return Infinity;
  return heightM / Math.tan(deg2rad(elevationDeg));
}

/** Direction (azimuth, deg) in which shadows point. */
export function shadowDirectionDeg(sunAzimuthDeg: number): number {
  return (sunAzimuthDeg + 180) % 360;
}

/** Shadow polygon of a prism footprint with height `h` above the receiver plane. */
export function shadowPolygon(footprint: Vec2[], h: number, elevationDeg: number, sunAzimuthDeg: number, maxLength = 500): Vec2[] | null {
  if (h <= 0 || elevationDeg <= 0.5) return null;
  const L = Math.min(maxLength, calculateShadowLength(h, elevationDeg));
  const dir = azimuthVector(shadowDirectionDeg(sunAzimuthDeg));
  const off = scale(dir, L);
  return convexHull([...footprint, ...footprint.map((p) => add(p, off))]);
}

/** Find the surface under a plan point (first match). */
export function surfaceAt(surfaces: InstallSurface[], p: Vec2): InstallSurface | null {
  for (const s of surfaces) if (pointInPolygon(p, s.polygon)) return s;
  return null;
}

export function buildShadowCasters(obstacles: Obstacle[], surfaces: InstallSurface[], parapets: Vec2[][], parapetHeight: number, roofBaseZ: number): ShadowCaster[] {
  const out: ShadowCaster[] = [];
  for (const o of obstacles) {
    if (NON_SHADING_KINDS.has(o.kind) || o.heightM <= 0) continue;
    const s = o.base === 'roof' ? surfaceAt(surfaces, o.center) : null;
    const baseZ = o.base === 'ground' ? 0 : s ? surfaceHeightAt(s, o.center) : roofBaseZ;
    out.push({ id: o.id, label: o.label, footprint: obstacleFootprint(o, 0), baseZ, topZ: baseZ + o.heightM });
  }
  parapets.forEach((fp, i) => out.push({ id: `parapet-${i}`, label: 'Parapet', footprint: fp, baseZ: roofBaseZ, topZ: roofBaseZ + parapetHeight }));
  return out;
}

/** Receiver plane: z(p) = a + gx·x + gy·y (m above ground). */
export interface ReceiverPlane { a: number; gx: number; gy: number }

export function receiverPlane(s: InstallSurface | undefined, offsetM: number): ReceiverPlane {
  if (!s) return { a: offsetM, gx: 0, gy: 0 };
  const t = Math.tan(deg2rad(s.slopeDeg));
  return { a: s.baseZ - s.riseRef * t + offsetM, gx: s.riseDir.x * t, gy: s.riseDir.y * t };
}

/**
 * Shadow of a vertical prism (footprint, top height) on a receiver plane.
 * Each top vertex T is projected along the sun ray until it meets the plane:
 *   t = (z_T − z_plane(p_T)) / (sin e − g·s_h),  shadow point = p_T − t·s_h
 * The shadow is the convex hull of the footprint and the projected vertices (exact for convex
 * prisms on a plane).
 */
export function shadowOnPlane(footprint: Vec2[], topZ: number, plane: ReceiverPlane, elevationDeg: number, sunAzimuthDeg: number, maxLength = 500): Vec2[] | null {
  if (elevationDeg <= 0.5) return null;
  const e = deg2rad(elevationDeg), az = deg2rad(sunAzimuthDeg);
  const sh = { x: Math.cos(e) * Math.sin(az), y: Math.cos(e) * Math.cos(az) };
  const sz = Math.sin(e);
  const denom = sz - (plane.gx * sh.x + plane.gy * sh.y);
  if (denom <= 1e-6) return null;
  const maxT = maxLength / Math.max(1e-6, Math.cos(e));
  const proj: Vec2[] = [];
  let any = false;
  for (const p of footprint) {
    const h = topZ - (plane.a + plane.gx * p.x + plane.gy * p.y);
    if (h <= 0) { proj.push(p); continue; }
    any = true;
    const t = Math.min(maxT, h / denom);
    proj.push({ x: p.x - t * sh.x, y: p.y - t * sh.y });
  }
  if (!any) return null;
  return convexHull([...footprint, ...proj]);
}

/** Receiver height of a module centre above its surface (m). */
export function panelReceiverOffset(p: PlacedPanel, dims: ModuleDims, clearanceM: number, racked: boolean): number {
  if (!racked) return 0.12;
  const od = orientedDims(dims, p.orientation);
  return clearanceM + (p.stackIndex + 0.5) * od.slant * Math.sin(deg2rad(p.tiltDeg));
}

/** Absolute receiver height of a module centre (m above ground). */
export function panelCentreHeight(p: PlacedPanel, s: InstallSurface | undefined, dims: ModuleDims, clearanceM: number, racked: boolean): number {
  return (s ? surfaceHeightAt(s, p.center) : 0) + panelReceiverOffset(p, dims, clearanceM, racked);
}

export interface ShadingScene {
  samples: Vec2[][];
  panelBoxes: BBox[];
  /** Receiver plane index per panel. */
  planeOf: number[];
  planes: ReceiverPlane[];
  casters: ShadowCaster[];
}

export function buildShadingScene(panels: PlacedPanel[], dims: ModuleDims, surfaces: InstallSurface[], casters: ShadowCaster[], clearanceM: number, rackedBySurface: Record<string, boolean>): ShadingScene {
  const sById = new Map(surfaces.map((s) => [s.id, s]));
  const samples: Vec2[][] = [];
  const panelBoxes: BBox[] = [];
  const planeOf: number[] = [];
  const planes: ReceiverPlane[] = [];
  const planeKey = new Map<string, number>();
  for (const p of panels) {
    const fp = panelFootprint(p, dims);
    const pts = fp.map((c) => add(p.center, scale({ x: c.x - p.center.x, y: c.y - p.center.y }, 0.9)));
    pts.push(p.center);
    samples.push(pts);
    panelBoxes.push(bbox(fp));
    const off = Math.round(panelReceiverOffset(p, dims, clearanceM, rackedBySurface[p.surfaceId] ?? false) * 10) / 10;
    const key = `${p.surfaceId}|${off}`;
    let idx = planeKey.get(key);
    if (idx === undefined) { idx = planes.length; planes.push(receiverPlane(sById.get(p.surfaceId), off)); planeKey.set(key, idx); }
    planeOf.push(idx);
  }
  return { samples, panelBoxes, planeOf, planes, casters };
}

/** Obstacle shading: fraction (0-1) of each module shaded at a given sun position. */
export function computeObstacleShading(scene: ShadingScene, elevationDeg: number, azimuthDeg: number): Float32Array {
  const n = scene.samples.length;
  const out = new Float32Array(n);
  if (elevationDeg <= 0.5 || !scene.casters.length) return out;
  const shadows: ({ poly: Vec2[]; b: BBox } | null)[][] = scene.planes.map((pl) => scene.casters.map((c) => {
    const poly = shadowOnPlane(c.footprint, c.topZ, pl, elevationDeg, azimuthDeg);
    return poly ? { poly, b: bbox(poly) } : null;
  }));
  for (let i = 0; i < n; i++) {
    const pb = scene.panelBoxes[i];
    const pts = scene.samples[i];
    const hit = new Array(pts.length).fill(false);
    for (const sh of shadows[scene.planeOf[i]]) {
      if (!sh) continue;
      if (pb.maxX < sh.b.minX || pb.minX > sh.b.maxX || pb.maxY < sh.b.minY || pb.minY > sh.b.maxY) continue;
      for (let k = 0; k < pts.length; k++) if (!hit[k] && pointInPolygon(pts[k], sh.poly)) hit[k] = true;
    }
    let shaded = 0;
    for (const h of hit) if (h) shaded++;
    out[i] = shaded / pts.length;
  }
  return out;
}

/**
 * Fraction of a back row's collector length shaded by the row in front
 * (profile-angle method):  f = 1 − P·sin(αp) / (L·sin(αp + β)),  clipped to [0,1].
 */
export function interRowShadedFraction(elevationDeg: number, sunAzDeg: number, tiltDeg: number, arrayAzDeg: number, slantM: number, pitchPlanM: number, terrainSlopeDeg = 0): number {
  if (elevationDeg <= 0 || tiltDeg - terrainSlopeDeg <= 0) return 0;
  const cd = Math.cos(deg2rad(sunAzDeg - arrayAzDeg));
  if (cd <= 0) return 0;
  const ap = Math.atan(Math.tan(deg2rad(elevationDeg)) / cd) + deg2rad(terrainSlopeDeg);
  const beta = deg2rad(tiltDeg - terrainSlopeDeg);
  const P = pitchPlanM / Math.cos(deg2rad(terrainSlopeDeg));
  const f = 1 - (P * Math.sin(ap)) / (slantM * Math.sin(ap + beta));
  return clamp(f, 0, 1);
}

/** Direction-of-sun unit vector in the 3D frame (x east, y up, z south = -north). */
export function sunVector3(elevationDeg: number, azimuthDeg: number): [number, number, number] {
  const e = deg2rad(elevationDeg), a = deg2rad(azimuthDeg);
  return [Math.cos(e) * Math.sin(a), Math.sin(e), -Math.cos(e) * Math.cos(a)];
}

/** Simple beam-shading loss for one instant: share of beam POA lost. */
export function calculateShadingLoss(beamPoa: number, totalPoa: number, shadedFraction: number): number {
  if (totalPoa <= 0) return 0;
  return (beamPoa * clamp(shadedFraction, 0, 1)) / totalPoa;
}

