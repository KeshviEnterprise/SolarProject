/**
 * Loss model. User-adjustable percentages combine multiplicatively:
 *   η_sys = Π (1 − L_i/100)
 * Temperature, shading, incidence-angle and clipping losses are computed hour-by-hour
 * in the energy model rather than assumed.
 */
import type { Losses } from '@/types';

/** Default assumptions (typical preliminary-design values; all editable, labelled ASSUMPTION). */
export const DEFAULT_LOSSES: Losses = {
  soilingPct: 3,
  mismatchPct: 1.5,
  dcWiringPct: 1.5,
  acWiringPct: 1,
  inverterPct: 2,
  availabilityPct: 99,
  otherPct: 1,
  shadingOverridePct: null,
  albedo: 0.2,
};

export interface LossFactor { key: string; label: string; pct: number; factor: number }

/** calculateSystemLosses - the fixed (non-modelled) loss factors in application order. */
export function calculateSystemLosses(l: Losses): { factors: LossFactor[]; combinedFactor: number; combinedLossPct: number } {
  const f: LossFactor[] = [
    { key: 'soiling', label: 'Soiling', pct: l.soilingPct, factor: 1 - l.soilingPct / 100 },
    { key: 'mismatch', label: 'Module mismatch', pct: l.mismatchPct, factor: 1 - l.mismatchPct / 100 },
    { key: 'dcWiring', label: 'DC wiring', pct: l.dcWiringPct, factor: 1 - l.dcWiringPct / 100 },
    { key: 'inverter', label: 'Inverter conversion', pct: l.inverterPct, factor: 1 - l.inverterPct / 100 },
    { key: 'acWiring', label: 'AC wiring', pct: l.acWiringPct, factor: 1 - l.acWiringPct / 100 },
    { key: 'availability', label: 'Availability', pct: 100 - l.availabilityPct, factor: l.availabilityPct / 100 },
    { key: 'other', label: 'Other (LID, degradation yr-1, etc.)', pct: l.otherPct, factor: 1 - l.otherPct / 100 },
  ];
  const combined = f.reduce((a, x) => a * x.factor, 1);
  return { factors: f, combinedFactor: combined, combinedLossPct: (1 - combined) * 100 };
}

/**
 * calculateTemperatureLoss - power factor from cell temperature.
 * @param cellTempC cell temperature (°C)
 * @param gammaPctPerC Pmax temperature coefficient (%/°C, negative)
 * @returns multiplicative factor relative to STC (25 °C)
 */
export function calculateTemperatureLoss(cellTempC: number, gammaPctPerC: number): number {
  return 1 + (gammaPctPerC / 100) * (cellTempC - 25);
}

/**
 * Cell temperature, Faiman-type steady-state model with wind folded into U:
 *   Tc = Ta + α · G_poa · (1 − η) / U
 * α = 0.9 absorptance; U (W/m²K): 29 free-standing racks, 20 flush roof / canopy (PVsyst defaults).
 */
export function cellTemperature(ambientC: number, poaW: number, efficiency: number, uValue: number, alpha = 0.9): number {
  return ambientC + (alpha * poaW * (1 - efficiency)) / uValue;
}

export function validateLosses(l: Losses): string[] {
  const e: string[] = [];
  const pcts: [string, number][] = [['Soiling', l.soilingPct], ['Mismatch', l.mismatchPct], ['DC wiring', l.dcWiringPct], ['AC wiring', l.acWiringPct], ['Inverter', l.inverterPct], ['Other', l.otherPct]];
  for (const [n, p] of pcts) if (!(p >= 0 && p < 50)) e.push(`${n} loss must be between 0 and 50 %.`);
  if (!(l.availabilityPct > 50 && l.availabilityPct <= 100)) e.push('Availability must be between 50 and 100 %.');
  if (!(l.albedo >= 0 && l.albedo <= 1)) e.push('Albedo must be between 0 and 1.');
  if (l.shadingOverridePct !== null && !(l.shadingOverridePct >= 0 && l.shadingOverridePct < 100)) e.push('Shading override must be between 0 and 100 %.');
  return e;
}
