/**
 * 2D computational geometry in the plan frame (metres, +x east, +y north).
 * Pure functions; no DOM or React.
 */
import type { Vec2, Obstacle } from '@/types';
import { deg2rad } from './units';

export const v = (x: number, y: number): Vec2 => ({ x, y });
export const add = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x + b.x, y: a.y + b.y });
export const sub = (a: Vec2, b: Vec2): Vec2 => ({ x: a.x - b.x, y: a.y - b.y });
export const scale = (a: Vec2, s: number): Vec2 => ({ x: a.x * s, y: a.y * s });
export const dot = (a: Vec2, b: Vec2) => a.x * b.x + a.y * b.y;
export const cross = (a: Vec2, b: Vec2) => a.x * b.y - a.y * b.x;
export const len = (a: Vec2) => Math.hypot(a.x, a.y);
export const dist = (a: Vec2, b: Vec2) => Math.hypot(a.x - b.x, a.y - b.y);

/** Signed area (m²) by the shoelace formula; positive for counter-clockwise. */
export function signedArea(poly: Vec2[]): number {
  let s = 0;
  for (let i = 0, n = poly.length; i < n; i++) {
    const a = poly[i], b = poly[(i + 1) % n];
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}

/** Polygon area (m²), always positive. */
export function polygonArea(poly: Vec2[]): number {
  return Math.abs(signedArea(poly));
}

export function polygonPerimeter(poly: Vec2[]): number {
  let p = 0;
  for (let i = 0; i < poly.length; i++) p += dist(poly[i], poly[(i + 1) % poly.length]);
  return p;
}

export function ensureCCW(poly: Vec2[]): Vec2[] {
  return signedArea(poly) < 0 ? [...poly].reverse() : poly;
}

export function centroid(poly: Vec2[]): Vec2 {
  const a = signedArea(poly);
  if (Math.abs(a) < 1e-12) {
    const s = poly.reduce((acc, p) => add(acc, p), v(0, 0));
    return scale(s, 1 / Math.max(1, poly.length));
  }
  let cx = 0, cy = 0;
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length];
    const f = p.x * q.y - q.x * p.y;
    cx += (p.x + q.x) * f;
    cy += (p.y + q.y) * f;
  }
  return v(cx / (6 * a), cy / (6 * a));
}

export interface BBox { minX: number; minY: number; maxX: number; maxY: number }

export function bbox(points: Vec2[]): BBox {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of points) {
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, minY, maxX, maxY };
}

export const bboxOverlap = (a: BBox, b: BBox) =>
  a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;

/** Even-odd ray casting point-in-polygon test. Points on the boundary may return either value. */
export function pointInPolygon(p: Vec2, poly: Vec2[]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.y > p.y) !== (b.y > p.y) && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
  }
  return inside;
}

export function distPointSegment(p: Vec2, a: Vec2, b: Vec2): number {
  const ab = sub(b, a);
  const l2 = dot(ab, ab);
  if (l2 === 0) return dist(p, a);
  const t = Math.max(0, Math.min(1, dot(sub(p, a), ab) / l2));
  return dist(p, add(a, scale(ab, t)));
}

export function distToPolygonEdges(p: Vec2, poly: Vec2[]): number {
  let d = Infinity;
  for (let i = 0; i < poly.length; i++) d = Math.min(d, distPointSegment(p, poly[i], poly[(i + 1) % poly.length]));
  return d;
}

function orient(a: Vec2, b: Vec2, c: Vec2) {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

/** Proper or touching intersection of segments ab and cd. */
export function segmentsIntersect(a: Vec2, b: Vec2, c: Vec2, d: Vec2): boolean {
  const d1 = orient(c, d, a), d2 = orient(c, d, b), d3 = orient(a, b, c), d4 = orient(a, b, d);
  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return true;
  const onSeg = (p: Vec2, q: Vec2, r: Vec2) =>
    Math.min(p.x, q.x) - 1e-12 <= r.x && r.x <= Math.max(p.x, q.x) + 1e-12 &&
    Math.min(p.y, q.y) - 1e-12 <= r.y && r.y <= Math.max(p.y, q.y) + 1e-12;
  if (Math.abs(d1) < 1e-12 && onSeg(c, d, a)) return true;
  if (Math.abs(d2) < 1e-12 && onSeg(c, d, b)) return true;
  if (Math.abs(d3) < 1e-12 && onSeg(a, b, c)) return true;
  if (Math.abs(d4) < 1e-12 && onSeg(a, b, d)) return true;
  return false;
}

/** True when polygon has no crossing non-adjacent edges and at least 3 distinct vertices. */
export function isSimplePolygon(poly: Vec2[]): boolean {
  const n = poly.length;
  if (n < 3) return false;
  if (polygonArea(poly) < 1e-9) return false;
  for (let i = 0; i < n; i++) {
    const a = poly[i], b = poly[(i + 1) % n];
    if (dist(a, b) < 1e-9) return false;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(i - j) <= 1 || (i === 0 && j === n - 1)) continue;
      if (segmentsIntersect(a, b, poly[j], poly[(j + 1) % n])) return false;
    }
  }
  return true;
}

/** Convex polygon from a rotated rectangle centred at c. */
export function rectPolygon(c: Vec2, w: number, h: number, rotationDeg = 0): Vec2[] {
  const r = deg2rad(rotationDeg);
  const cs = Math.cos(r), sn = Math.sin(r);
  const hw = w / 2, hh = h / 2;
  return [v(-hw, -hh), v(hw, -hh), v(hw, hh), v(-hw, hh)].map((p) => v(c.x + p.x * cs - p.y * sn, c.y + p.x * sn + p.y * cs));
}

/** Regular polygon approximation of a circle (used for trees, round tanks). */
export function circlePolygon(c: Vec2, radius: number, segments = 16): Vec2[] {
  const out: Vec2[] = [];
  for (let i = 0; i < segments; i++) {
    const a = (i / segments) * Math.PI * 2;
    out.push(v(c.x + radius * Math.cos(a), c.y + radius * Math.sin(a)));
  }
  return out;
}

/** Footprint polygon of an obstacle, optionally grown by `extra` metres. */
export function obstacleFootprint(o: Obstacle, extra = 0): Vec2[] {
  if (o.shape === 'circle') return circlePolygon(o.center, Math.max(0.01, o.widthM / 2 + extra), 16);
  return rectPolygon(o.center, o.widthM + 2 * extra, o.depthM + 2 * extra, o.rotationDeg);
}

/** Projection interval of polygon onto axis. */
function project(poly: Vec2[], axis: Vec2): [number, number] {
  let lo = Infinity, hi = -Infinity;
  for (const p of poly) {
    const d = p.x * axis.x + p.y * axis.y;
    if (d < lo) lo = d;
    if (d > hi) hi = d;
  }
  return [lo, hi];
}

/** Separating-axis test for two convex polygons (touching counts as overlap when eps <= 0). */
export function convexPolygonsOverlap(a: Vec2[], b: Vec2[], eps = 1e-9): boolean {
  for (const poly of [a, b]) {
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i], q = poly[(i + 1) % poly.length];
      const axis = v(q.y - p.y, p.x - q.x);
      const [a0, a1] = project(a, axis);
      const [b0, b1] = project(b, axis);
      if (a1 <= b0 + eps || b1 <= a0 + eps) return false;
    }
  }
  return true;
}

/** Does segment ab intersect (or lie inside) convex polygon `convex`? */
export function segmentIntersectsConvex(a: Vec2, b: Vec2, convex: Vec2[]): boolean {
  return convexPolygonsOverlap([a, b, a], convex, 0) || pointInPolygon(a, convex) || pointInPolygon(b, convex);
}

/**
 * True if convex polygon `inner` lies entirely inside (possibly concave) simple polygon `outer`,
 * i.e. its reference point is inside and no outer edge crosses it.
 */
export function convexInsidePolygon(inner: Vec2[], outer: Vec2[]): boolean {
  for (const p of inner) if (!pointInPolygon(p, outer)) return false;
  const ib = bbox(inner);
  for (let i = 0; i < outer.length; i++) {
    const a = outer[i], b = outer[(i + 1) % outer.length];
    if (Math.max(a.x, b.x) < ib.minX || Math.min(a.x, b.x) > ib.maxX || Math.max(a.y, b.y) < ib.minY || Math.min(a.y, b.y) > ib.maxY) continue;
    for (let k = 0; k < inner.length; k++) {
      if (segmentsIntersect(a, b, inner[k], inner[(k + 1) % inner.length])) return false;
    }
  }
  return true;
}

/** Andrew's monotone-chain convex hull. */
export function convexHull(points: Vec2[]): Vec2[] {
  const pts = [...points].sort((a, b) => (a.x === b.x ? a.y - b.y : a.x - b.x));
  if (pts.length < 3) return pts;
  const lower: Vec2[] = [];
  for (const p of pts) {
    while (lower.length >= 2 && orient(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper: Vec2[] = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && orient(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop();
    upper.push(p);
  }
  upper.pop();
  lower.pop();
  return lower.concat(upper);
}

/** Sutherland-Hodgman clip of polygon by half-plane {p : dot(p, n) >= c}. */
export function clipHalfPlane(poly: Vec2[], n: Vec2, c: number): Vec2[] {
  const out: Vec2[] = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const da = dot(a, n) - c, db = dot(b, n) - c;
    if (da >= 0) out.push(a);
    if ((da >= 0) !== (db >= 0)) {
      const t = da / (da - db);
      out.push(v(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t));
    }
  }
  return out;
}

/**
 * Inward offset of a polygon by d metres (mitred joins). Exact for convex polygons and
 * rectilinear shapes; for strongly concave shapes the result is approximate and only used
 * for display of the setback line. Returns [] if the polygon collapses.
 */
export function offsetPolygonInward(poly: Vec2[], d: number): Vec2[] {
  if (d <= 0) return poly;
  const p = ensureCCW(poly);
  const n = p.length;
  const lines: { a: Vec2; dir: Vec2 }[] = [];
  for (let i = 0; i < n; i++) {
    const a = p[i], b = p[(i + 1) % n];
    const e = sub(b, a);
    const L = len(e);
    if (L < 1e-9) continue;
    const dir = scale(e, 1 / L);
    const inward = v(-dir.y, dir.x); // left normal points inside for CCW
    lines.push({ a: add(a, scale(inward, d)), dir });
  }
  const out: Vec2[] = [];
  for (let i = 0; i < lines.length; i++) {
    const l1 = lines[(i - 1 + lines.length) % lines.length];
    const l2 = lines[i];
    const den = cross(l1.dir, l2.dir);
    if (Math.abs(den) < 1e-9) { out.push(l2.a); continue; }
    const t = cross(sub(l2.a, l1.a), l2.dir) / den;
    out.push(add(l1.a, scale(l1.dir, t)));
  }
  if (out.length < 3 || signedArea(out) <= 0 || polygonArea(out) > polygonArea(p)) return [];
  return out;
}

/** Rotate point about origin by angle (deg, counter-clockwise). */
export function rotate(p: Vec2, deg: number): Vec2 {
  const r = deg2rad(deg);
  return v(p.x * Math.cos(r) - p.y * Math.sin(r), p.x * Math.sin(r) + p.y * Math.cos(r));
}

/** Unit vector in plan for a compass azimuth (deg clockwise from north). */
export function azimuthVector(azDeg: number): Vec2 {
  const r = deg2rad(azDeg);
  const snap = (x: number) => (Math.abs(x) < 1e-12 ? 0 : x);
  return v(snap(Math.sin(r)), snap(Math.cos(r)));
}

/**
 * Numerically estimate the free area inside `poly` that is at least `setback` from its
 * edges and outside all `keepouts`. Grid sampling; resolution adapts to size.
 */
export function sampleFreeArea(poly: Vec2[], setback: number, keepouts: Vec2[][], maxSamples = 160_000): number {
  if (poly.length < 3) return 0;
  const b = bbox(poly);
  const W = b.maxX - b.minX, H = b.maxY - b.minY;
  if (W <= 0 || H <= 0) return 0;
  const step = Math.max(0.05, Math.sqrt((W * H) / maxSamples));
  const kb = keepouts.map((k) => ({ k, b: bbox(k) }));
  let count = 0;
  for (let y = b.minY + step / 2; y < b.maxY; y += step) {
    for (let x = b.minX + step / 2; x < b.maxX; x += step) {
      const p = v(x, y);
      if (!pointInPolygon(p, poly)) continue;
      if (setback > 0 && distToPolygonEdges(p, poly) < setback) continue;
      let blocked = false;
      for (const { k, b: kbb } of kb) {
        if (x < kbb.minX || x > kbb.maxX || y < kbb.minY || y > kbb.maxY) continue;
        if (pointInPolygon(p, k)) { blocked = true; break; }
      }
      if (!blocked) count++;
    }
  }
  return count * step * step;
}
