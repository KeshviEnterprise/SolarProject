/**
 * Unit conversion. Internally everything is SI (metres, watts, watt-hours).
 */
import type { LengthUnit } from '@/types';

export const LENGTH_FACTORS: Record<LengthUnit, number> = {
  mm: 0.001,
  cm: 0.01,
  m: 1,
  in: 0.0254,
  ft: 0.3048,
};

export const LENGTH_UNIT_LABELS: Record<LengthUnit, string> = { mm: 'mm', cm: 'cm', m: 'm', in: 'in', ft: 'ft' };

/** Convert a length value in `unit` to metres. */
export function toMetres(value: number, unit: LengthUnit): number {
  return value * LENGTH_FACTORS[unit];
}

/** Convert metres to `unit`. */
export function fromMetres(valueM: number, unit: LengthUnit): number {
  return valueM / LENGTH_FACTORS[unit];
}

export function convertLength(value: number, from: LengthUnit, to: LengthUnit): number {
  return fromMetres(toMetres(value, from), to);
}

/** Area in m² → display unit squared. */
export function areaFromM2(valueM2: number, unit: LengthUnit): number {
  const f = LENGTH_FACTORS[unit];
  return valueM2 / (f * f);
}

export type PowerUnit = 'W' | 'kW' | 'MW';
export type EnergyUnit = 'Wh' | 'kWh' | 'MWh';

/** Choose a readable power unit for a value in watts. */
export function formatPowerW(watts: number, digits = 2): string {
  const a = Math.abs(watts);
  if (a >= 1e6) return `${(watts / 1e6).toFixed(digits)} MW`;
  if (a >= 1e3) return `${(watts / 1e3).toFixed(digits)} kW`;
  return `${watts.toFixed(0)} W`;
}

/** Choose a readable energy unit for a value in kWh. */
export function formatEnergyKwh(kwh: number): string {
  const a = Math.abs(kwh);
  if (a >= 1e6) return `${(kwh / 1e6).toFixed(3)} GWh`;
  if (a >= 1e4) return `${(kwh / 1e3).toFixed(2)} MWh`;
  return `${Math.round(kwh).toLocaleString('en-US')} kWh`;
}

export function formatLength(valueM: number, unit: LengthUnit, digits?: number): string {
  const v = fromMetres(valueM, unit);
  const d = digits ?? (unit === 'mm' ? 0 : unit === 'cm' ? 1 : 2);
  return `${v.toFixed(d)} ${LENGTH_UNIT_LABELS[unit]}`;
}

export function formatArea(valueM2: number, unit: LengthUnit): string {
  const u = unit === 'mm' || unit === 'cm' ? 'm' : unit;
  const v = areaFromM2(valueM2, u);
  return `${v.toLocaleString('en-US', { maximumFractionDigits: 1 })} ${u}²`;
}

export const deg2rad = (d: number) => (d * Math.PI) / 180;
export const rad2deg = (r: number) => (r * 180) / Math.PI;
export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
/** Normalise an angle to [0, 360). */
export const norm360 = (d: number) => ((d % 360) + 360) % 360;
