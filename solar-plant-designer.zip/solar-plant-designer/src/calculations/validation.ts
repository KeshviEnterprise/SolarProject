/**
 * Input validation (zod schemas) and design-level warnings.
 */
import { z } from 'zod';
import type { Project } from '@/types';
import { isSimplePolygon, pointInPolygon, convexInsidePolygon, convexPolygonsOverlap } from './geometry';
import { findInvalidPanels, moduleDims, calculateRowSpacing, orientedDims } from './panelLayout';
import { buildSurfaces, surfaceMount } from './structure';
import { validateLosses } from './losses';

export const latitudeSchema = z.number({ invalid_type_error: 'Latitude must be a number' }).min(-90, 'Latitude must be ≥ −90°').max(90, 'Latitude must be ≤ 90°');
export const longitudeSchema = z.number({ invalid_type_error: 'Longitude must be a number' }).min(-180, 'Longitude must be ≥ −180°').max(180, 'Longitude must be ≤ 180°');
export const positiveLength = z.number({ invalid_type_error: 'Enter a number' }).positive('Must be greater than zero');
export const nonNegativeLength = z.number({ invalid_type_error: 'Enter a number' }).min(0, 'Cannot be negative');

export const panelSchema = z.object({
  powerW: z.number().positive('Panel power must be greater than zero'),
  lengthMm: z.number().positive('Panel length must be greater than zero'),
  widthMm: z.number().positive('Panel width must be greater than zero'),
  efficiencyPct: z.number().gt(0, 'Efficiency must be greater than zero').max(50, 'Efficiency above 50 % is not physical for flat-plate PV'),
  vocV: z.number().positive('Voc must be greater than zero'),
  iscA: z.number().positive('Isc must be greater than zero'),
  vmpV: z.number().positive('Vmp must be greater than zero'),
  impA: z.number().positive('Imp must be greater than zero'),
  tempCoeffPmaxPctPerC: z.number().min(-1, 'Implausible coefficient').max(0.1, 'Pmax coefficient is normally negative'),
  weightKg: z.number().min(0, 'Weight cannot be negative'),
}).refine((p) => p.vmpV < p.vocV, { message: 'Vmp must be lower than Voc', path: ['vmpV'] })
  .refine((p) => p.impA < p.iscA, { message: 'Imp must be lower than Isc', path: ['impA'] });

export function fieldError(schema: z.ZodTypeAny, value: unknown): string | null {
  const r = schema.safeParse(value);
  return r.success ? null : r.error.issues[0]?.message ?? 'Invalid value';
}

export function validatePanel(p: Project['panel']): Record<string, string> {
  const r = panelSchema.safeParse(p);
  const out: Record<string, string> = {};
  if (!r.success) for (const i of r.error.issues) out[String(i.path[0] ?? 'form')] = i.message;
  return out;
}

export interface DesignIssue { level: 'error' | 'warning' | 'info'; area: string; message: string }

/** Design-level checks for the right-hand warnings panel and the report. */
export function collectDesignIssues(p: Project): DesignIssue[] {
  const out: DesignIssue[] = [];
  const st = p.structure;
  if (latitudeSchema.safeParse(p.location.latitude).success === false) out.push({ level: 'error', area: 'Location', message: 'Latitude is invalid.' });
  if (longitudeSchema.safeParse(p.location.longitude).success === false) out.push({ level: 'error', area: 'Location', message: 'Longitude is invalid.' });
  if (!isSimplePolygon(st.boundary)) out.push({ level: 'error', area: 'Roof', message: 'The roof/land boundary is not a valid polygon (needs ≥3 points and no crossing edges).' });
  if (st.slopeDeg < 0 || st.slopeDeg >= 75) out.push({ level: 'error', area: 'Structure', message: 'Roof slope must be between 0° and 75°.' });
  if (st.eaveHeightM < 0) out.push({ level: 'error', area: 'Structure', message: 'Height cannot be negative.' });
  const pe = validatePanel(p.panel);
  for (const k of Object.keys(pe)) out.push({ level: 'error', area: 'Panel', message: pe[k] });
  for (const m of validateLosses(p.losses)) out.push({ level: 'error', area: 'Losses', message: m });
  if (st.roofType !== 'ground' && st.structuralCapacityKgM2 === null) out.push({ level: 'warning', area: 'Structure', message: 'Structural suitability has not been verified.' });
  if (!p.solarResource) out.push({ level: 'warning', area: 'Solar data', message: 'Solar resource data is not loaded. Energy results are unavailable.' });
  else if (p.solarResource.isDemo) out.push({ level: 'warning', area: 'Solar data', message: 'DEMO solar data is in use. Results are illustrative only.' });

  const surfaces = buildSurfaces(st, p.mounting);
  for (const s of surfaces) {
    const m = surfaceMount(s, p.mounting);
    if (m.forcedRoofFollowing) out.push({ level: 'info', area: 'Mounting', message: `${s.name}: sloped surfaces use roof-following mounting (tilt ${s.slopeDeg}°, azimuth ${s.azimuthDeg.toFixed(0)}°).` });
    const pitch = p.layout.pitchBySurface[s.id];
    if (m.racked && pitch) {
      const k = Math.max(1, Math.round(p.mounting.modulesHigh));
      const od = orientedDims(moduleDims(p.panel), p.mounting.orientation);
      const slant = k * od.slant + (k - 1) * p.mounting.moduleGapM;
      const rs = calculateRowSpacing({ latitudeDeg: p.location.latitude, tiltDeg: m.tiltDeg, slantM: slant, azimuthDeg: m.azimuthDeg, terrainSlopeDeg: m.terrainSlopeDeg, startHour: 10, endHour: 14 });
      if (pitch + 0.01 < rs.pitchPlanM) out.push({ level: 'warning', area: 'Layout', message: `${s.name}: row pitch ${pitch.toFixed(2)} m is less than the 10:00-14:00 shade-free pitch (${rs.pitchPlanM.toFixed(2)} m). Expect winter row shading.` });
    }
  }
  if (p.layout.panels.length) {
    const bad = findInvalidPanels(p.layout.panels, moduleDims(p.panel), st.boundary, p.obstacles.filter((o) => pointInPolygon(o.center, st.boundary) || o.kind === 'walkway' || o.kind === 'exclusion'), convexInsidePolygon, convexPolygonsOverlap);
    if (bad.size) out.push({ level: 'warning', area: 'Layout', message: `${bad.size} panel(s) are outside the boundary or overlap an obstacle/keep-out.` });
  }
  const weight = systemWeightKg(p);
  if (st.structuralCapacityKgM2 !== null && p.layout.panels.length) {
    const area = Math.max(1, p.layout.panels.length * (p.panel.lengthMm / 1000) * (p.panel.widthMm / 1000));
    const load = weight / area;
    if (load > st.structuralCapacityKgM2) out.push({ level: 'warning', area: 'Structure', message: `Estimated array load ${load.toFixed(1)} kg/m² exceeds the entered capacity ${st.structuralCapacityKgM2} kg/m².` });
  }
  if (st.condition === 'poor') out.push({ level: 'warning', area: 'Structure', message: 'Roof condition is poor; repair before installation is recommended.' });
  return out;
}

/** Mounting structure mass assumptions (kg per m² of module area). */
export const MOUNTING_KG_PER_M2: Record<string, number> = { 'fixed-tilt': 8, 'adjustable-tilt': 10, 'roof-following': 4 };

export function systemWeightKg(p: Project): number {
  const n = p.layout.panels.length;
  const area = n * (p.panel.lengthMm / 1000) * (p.panel.widthMm / 1000);
  return n * p.panel.weightKg + area * (MOUNTING_KG_PER_M2[p.mounting.type] ?? 8);
}
