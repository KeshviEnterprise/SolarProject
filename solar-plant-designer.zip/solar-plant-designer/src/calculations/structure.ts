/**
 * Structure → installation surfaces. Every roof or land parcel is decomposed into one or more
 * planar surfaces with a plan polygon, slope, facing azimuth and height model.
 */
import type { Structure, Mounting, Obstacle, Vec2, RoofType } from '@/types';
import {
  azimuthVector, clipHalfPlane, dot, polygonArea, polygonPerimeter, obstacleFootprint,
  sampleFreeArea, pointInPolygon, isSimplePolygon, rectPolygon, v, scale,
} from './geometry';
import { deg2rad, norm360 } from './units';

export interface InstallSurface {
  id: string;
  name: string;
  kind: RoofType;
  polygon: Vec2[];
  slopeDeg: number;
  /** Azimuth the plane faces (downslope direction). For flat roofs = array azimuth. */
  azimuthDeg: number;
  /** Height (m above ground) of the lowest edge of the plane. */
  baseZ: number;
  /** Unit plan vector pointing up-slope. */
  riseDir: Vec2;
  /** min over polygon of dot(p, riseDir). */
  riseRef: number;
}

/** Height (m above ground) of surface at plan point p. */
export function surfaceHeightAt(s: InstallSurface, p: Vec2): number {
  if (s.slopeDeg === 0) return s.baseZ;
  return s.baseZ + Math.max(0, dot(p, s.riseDir) - s.riseRef) * Math.tan(deg2rad(s.slopeDeg));
}

function makeSurface(id: string, name: string, kind: RoofType, polygon: Vec2[], slopeDeg: number, azimuthDeg: number, baseZ: number): InstallSurface {
  const riseDir = scale(azimuthVector(azimuthDeg), -1);
  const riseRef = polygon.length ? Math.min(...polygon.map((p) => dot(p, riseDir))) : 0;
  return { id, name, kind, polygon, slopeDeg, azimuthDeg: norm360(azimuthDeg), baseZ, riseDir, riseRef };
}

/** Build installation surfaces from the structure definition. */
export function buildSurfaces(st: Structure, mounting: Mounting): InstallSurface[] {
  const poly = st.boundary;
  if (poly.length < 3) return [];
  switch (st.roofType) {
    case 'flat':
      return [makeSurface('S1', 'Roof', 'flat', poly, 0, mounting.azimuthDeg, st.eaveHeightM)];
    case 'ground':
      return [makeSurface('S1', 'Land', 'ground', poly, Math.max(0, st.terrainSlopeDeg), mounting.azimuthDeg, 0)];
    case 'shed':
      return [makeSurface('S1', 'Roof plane', 'shed', poly, st.slopeDeg, st.roofAzimuthDeg, st.eaveHeightM)];
    case 'canopy':
      return [makeSurface('S1', 'Canopy', 'canopy', poly, st.slopeDeg, st.roofAzimuthDeg, st.eaveHeightM)];
    case 'gable': {
      const f = azimuthVector(st.roofAzimuthDeg);
      const vals = poly.map((p) => dot(p, f));
      const c = (Math.min(...vals) + Math.max(...vals)) / 2;
      const a = clipHalfPlane(poly, f, c);
      const b = clipHalfPlane(poly, scale(f, -1), -c);
      const out: InstallSurface[] = [];
      if (a.length >= 3 && polygonArea(a) > 0.01) out.push(makeSurface('S1', `Plane facing ${compass(st.roofAzimuthDeg)}`, 'gable', a, st.slopeDeg, st.roofAzimuthDeg, st.eaveHeightM));
      if (b.length >= 3 && polygonArea(b) > 0.01) out.push(makeSurface('S2', `Plane facing ${compass(st.roofAzimuthDeg + 180)}`, 'gable', b, st.slopeDeg, st.roofAzimuthDeg + 180, st.eaveHeightM));
      return out;
    }
  }
}

export function compass(az: number): string {
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  return dirs[Math.round(norm360(az) / 22.5) % 16];
}

/** Ridge height for gable roofs (m above ground). */
export function ridgeHeight(surfaces: InstallSurface[]): number {
  let h = 0;
  for (const s of surfaces) for (const p of s.polygon) h = Math.max(h, surfaceHeightAt(s, p));
  return h;
}

export interface SurfaceMount {
  tiltDeg: number;
  azimuthDeg: number;
  /** Panels on racks with rows spaced for self-shading (true) or flush with surface (false). */
  racked: boolean;
  /** Surface slope along the facing direction (used for row-spacing geometry). */
  terrainSlopeDeg: number;
  forcedRoofFollowing: boolean;
}

/** Effective module tilt/azimuth on a given surface. */
export function surfaceMount(s: InstallSurface, m: Mounting): SurfaceMount {
  if (s.kind === 'flat') {
    const tilt = m.type === 'roof-following' ? 0 : m.tiltDeg;
    return { tiltDeg: tilt, azimuthDeg: m.azimuthDeg, racked: tilt > 0, terrainSlopeDeg: 0, forcedRoofFollowing: false };
  }
  if (s.kind === 'ground') {
    const tilt = m.type === 'roof-following' ? s.slopeDeg : m.tiltDeg;
    return { tiltDeg: tilt, azimuthDeg: m.azimuthDeg, racked: tilt - s.slopeDeg > 0.01, terrainSlopeDeg: s.slopeDeg, forcedRoofFollowing: false };
  }
  // sloped roofs and canopies: flush (roof-following)
  return { tiltDeg: s.slopeDeg, azimuthDeg: s.azimuthDeg, racked: false, terrainSlopeDeg: 0, forcedRoofFollowing: m.type !== 'roof-following' };
}

/** Parapet wall segments (thin rectangles along each boundary edge). */
export function parapetSegments(st: Structure): Vec2[][] {
  if (st.parapetHeightM <= 0 || st.roofType === 'ground' || st.roofType === 'canopy') return [];
  const t = 0.2;
  const out: Vec2[][] = [];
  const poly = st.boundary;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const c = v((a.x + b.x) / 2, (a.y + b.y) / 2);
    const L = Math.hypot(b.x - a.x, b.y - a.y);
    const ang = (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI;
    out.push(rectPolygon(c, L, t, ang));
  }
  return out;
}

/** Obstacles that reserve area (keep-outs) including their buffer. */
export function keepoutPolygons(obstacles: Obstacle[]): Vec2[][] {
  return obstacles.map((o) => obstacleFootprint(o, o.bufferM));
}

export interface AreaSummary {
  roofPlanAreaM2: number;
  roofSurfaceAreaM2: number;
  perimeterM: number;
  setbackAreaM2: number;
  keepoutAreaM2: number;
  usableAreaM2: number;
  valid: boolean;
}

/**
 * calculateRoofArea / calculateUsableArea.
 * Usable area = plan area inside the setback line and outside all obstacle keep-outs
 * (numerical grid sampling, resolution adapts to size).
 */
export function calculateAreas(st: Structure, surfaces: InstallSurface[], obstacles: Obstacle[]): AreaSummary {
  const valid = isSimplePolygon(st.boundary);
  const roofPlanAreaM2 = polygonArea(st.boundary);
  const roofSurfaceAreaM2 = surfaces.reduce((acc, s) => acc + polygonArea(s.polygon) / Math.cos(deg2rad(s.slopeDeg)), 0);
  const inside = obstacles.filter((o) => pointInPolygon(o.center, st.boundary));
  const keep = keepoutPolygons(inside);
  const withSetback = sampleFreeArea(st.boundary, st.setbackM, []);
  const usable = sampleFreeArea(st.boundary, st.setbackM, keep);
  return {
    roofPlanAreaM2,
    roofSurfaceAreaM2,
    perimeterM: polygonPerimeter(st.boundary),
    setbackAreaM2: Math.max(0, roofPlanAreaM2 - withSetback),
    keepoutAreaM2: Math.max(0, withSetback - usable),
    usableAreaM2: usable,
    valid,
  };
}

export function calculateRoofArea(boundary: Vec2[]): number {
  return polygonArea(boundary);
}

/** Rectangle boundary (origin at south-west corner), length along x (east), width along y (north). */
export function rectangleBoundary(lengthM: number, widthM: number): Vec2[] {
  return [v(0, 0), v(lengthM, 0), v(lengthM, widthM), v(0, widthM)];
}
