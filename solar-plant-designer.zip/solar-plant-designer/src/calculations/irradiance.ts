/**
 * Irradiance decomposition and transposition.
 *
 * Method (standard textbook chain, Duffie & Beckman "Solar Engineering of Thermal Processes"):
 *  1. Monthly mean daily GHI (external data) → monthly clearness index K̄t = H / H0.
 *  2. Daily diffuse fraction from the Erbs et al. (1982) daily correlation.
 *  3. Hourly distribution of global (Collares-Pereira & Rabl 1979) and diffuse (Liu & Jordan 1960)
 *     irradiation over the representative day, renormalised to conserve daily totals.
 *  4. Plane-of-array irradiance by the Hay-Davies anisotropic sky model plus isotropic ground
 *     reflection, with ASHRAE incidence-angle modifier for beam.
 */
import { deg2rad, rad2deg, clamp } from './units';
import { declinationDeg, positionFromHourAngle } from './solarPosition';

export const SOLAR_CONSTANT = 1361; // W/m², (Kopp & Lean 2011)

/** Extraterrestrial normal irradiance (W/m²) - Spencer eccentricity approximation. */
export function extraterrestrialNormal(doy: number): number {
  return SOLAR_CONSTANT * (1 + 0.033 * Math.cos((2 * Math.PI * doy) / 365));
}

/** Sunset hour angle ωs (deg) for latitude and declination. */
export function sunsetHourAngleDeg(latDeg: number, declDeg: number): number {
  const x = -Math.tan(deg2rad(latDeg)) * Math.tan(deg2rad(declDeg));
  return rad2deg(Math.acos(clamp(x, -1, 1)));
}

/** Daily extraterrestrial irradiation on a horizontal surface H0 (kWh/m²/day). */
export function dailyExtraterrestrialHorizontal(doy: number, latDeg: number): number {
  const d = declinationDeg(doy);
  const ws = deg2rad(sunsetHourAngleDeg(latDeg, d));
  const phi = deg2rad(latDeg), dr = deg2rad(d);
  const h0Wh = (24 / Math.PI) * extraterrestrialNormal(doy) *
    (Math.cos(phi) * Math.cos(dr) * Math.sin(ws) + ws * Math.sin(phi) * Math.sin(dr));
  return Math.max(0, h0Wh / 1000);
}

/** Erbs et al. (1982) daily diffuse fraction Hd/H from daily clearness index Kt. */
export function erbsDailyDiffuseFraction(kt: number, sunsetHaDeg: number): number {
  const k = clamp(kt, 0, 1);
  if (sunsetHaDeg <= 81.4) {
    if (k < 0.715) return clamp(1 - 0.2727 * k + 2.4495 * k ** 2 - 11.9514 * k ** 3 + 9.3879 * k ** 4, 0, 1);
    return 0.143;
  }
  if (k < 0.722) return clamp(1 + 0.2832 * k - 2.5557 * k ** 2 + 0.8448 * k ** 3, 0, 1);
  return 0.175;
}

/** Collares-Pereira & Rabl ratio of hourly to daily global irradiation r_t. */
export function collaresPereiraRt(hourAngleDeg: number, sunsetHaDeg: number): number {
  const w = deg2rad(hourAngleDeg), ws = deg2rad(sunsetHaDeg);
  const a = 0.409 + 0.5016 * Math.sin(ws - Math.PI / 3);
  const b = 0.6609 - 0.4767 * Math.sin(ws - Math.PI / 3);
  const den = Math.sin(ws) - ws * Math.cos(ws);
  if (den <= 0) return 0;
  return Math.max(0, (Math.PI / 24) * (a + b * Math.cos(w)) * ((Math.cos(w) - Math.cos(ws)) / den));
}

/** Liu & Jordan ratio of hourly to daily diffuse irradiation r_d. */
export function liuJordanRd(hourAngleDeg: number, sunsetHaDeg: number): number {
  const w = deg2rad(hourAngleDeg), ws = deg2rad(sunsetHaDeg);
  const den = Math.sin(ws) - ws * Math.cos(ws);
  if (den <= 0) return 0;
  return Math.max(0, (Math.PI / 24) * ((Math.cos(w) - Math.cos(ws)) / den));
}

/** cos of angle of incidence on a surface of tilt β and azimuth γ. */
export function cosIncidence(sunZenDeg: number, sunAzDeg: number, tiltDeg: number, surfAzDeg: number): number {
  const z = deg2rad(sunZenDeg), b = deg2rad(tiltDeg);
  return Math.cos(z) * Math.cos(b) + Math.sin(z) * Math.sin(b) * Math.cos(deg2rad(sunAzDeg - surfAzDeg));
}

/** ASHRAE incidence angle modifier for beam, b0 = 0.05 (typical glass). */
export function iamAshrae(cosTheta: number, b0 = 0.05): number {
  if (cosTheta <= 0.0) return 0;
  const m = 1 - b0 * (1 / cosTheta - 1);
  return clamp(m, 0, 1);
}

export interface PoaComponents {
  beam: number;
  skyDiffuse: number;
  groundReflected: number;
  total: number;
  cosTheta: number;
}

/**
 * calculatePlaneOfArrayIrradiance - Hay-Davies transposition.
 * @param ghi global horizontal irradiance (W/m²)
 * @param dhi diffuse horizontal irradiance (W/m²)
 * @param doy day of year
 */
export function calculatePlaneOfArrayIrradiance(
  ghi: number, dhi: number, sunZenDeg: number, sunAzDeg: number, tiltDeg: number, surfAzDeg: number, albedo: number, doy: number,
): PoaComponents {
  const cosZ = Math.max(Math.cos(deg2rad(sunZenDeg)), 0.087); // cap at ~85° zenith
  const bh = Math.max(0, ghi - dhi);
  const cosT = cosIncidence(sunZenDeg, sunAzDeg, tiltDeg, surfAzDeg);
  const Rb = Math.max(0, cosT) / cosZ;
  const dni = bh / cosZ;
  const Ai = clamp(dni / extraterrestrialNormal(doy), 0, 1);
  const b = deg2rad(tiltDeg);
  const beam = bh * Rb;
  const skyDiffuse = dhi * (Ai * Rb + (1 - Ai) * (1 + Math.cos(b)) / 2);
  const groundReflected = ghi * albedo * (1 - Math.cos(b)) / 2;
  return { beam, skyDiffuse, groundReflected, total: beam + skyDiffuse + groundReflected, cosTheta: cosT };
}

export interface HourlyHorizontal {
  solarHour: number;
  hourAngleDeg: number;
  zenithDeg: number;
  azimuthDeg: number;
  elevationDeg: number;
  ghi: number; // W/m²
  dhi: number; // W/m²
}

/**
 * calculateSolarIrradiance - distribute a daily GHI total over a representative day.
 * @param dailyGhiKwhM2 daily global horizontal irradiation (kWh/m²/day)
 * @param stepHours integration step (h)
 */
export function calculateSolarIrradiance(latDeg: number, doy: number, dailyGhiKwhM2: number, stepHours = 0.25) {
  const decl = declinationDeg(doy);
  const ws = sunsetHaDeg(latDeg, decl);
  const H0 = dailyExtraterrestrialHorizontal(doy, latDeg);
  const kt = H0 > 0 ? clamp(dailyGhiKwhM2 / H0, 0, 1) : 0;
  const diffuseFraction = erbsDailyDiffuseFraction(kt, ws);
  const Hwh = dailyGhiKwhM2 * 1000;
  const Hdwh = Hwh * diffuseFraction;
  const pts: HourlyHorizontal[] = [];
  let sumG = 0, sumD = 0;
  for (let t = stepHours / 2; t < 24; t += stepHours) {
    const ha = 15 * (t - 12);
    if (Math.abs(ha) >= ws) continue;
    const pos = positionFromHourAngle(latDeg, decl, ha);
    if (pos.elevationDeg <= 0) continue;
    const g = collaresPereiraRt(ha, ws) * Hwh;
    const d = Math.min(g, liuJordanRd(ha, ws) * Hdwh);
    sumG += g * stepHours;
    sumD += d * stepHours;
    pts.push({ solarHour: t, hourAngleDeg: ha, zenithDeg: pos.zenithDeg, azimuthDeg: pos.azimuthDeg, elevationDeg: pos.elevationDeg, ghi: g, dhi: d });
  }
  // Renormalise so that the integrated day equals the input totals exactly.
  const fg = sumG > 0 ? Hwh / sumG : 0;
  const fd = sumD > 0 ? Hdwh / sumD : 0;
  for (const p of pts) {
    p.ghi *= fg;
    p.dhi = Math.min(p.ghi, p.dhi * fd);
  }
  return { points: pts, clearnessIndex: kt, diffuseFraction, h0KwhM2: H0, sunsetHourAngleDeg: ws };
}

function sunsetHaDeg(lat: number, decl: number) {
  return sunsetHourAngleDeg(lat, decl);
}
