/**
 * PV energy model (typical-year, representative-day method).
 *
 * For each month m the representative day (Klein 1977) is simulated at 30-minute steps:
 *   GHI(t), DHI(t)    ← monthly mean daily GHI via Erbs / Collares-Pereira-Rabl / Liu-Jordan
 *   POA(t)            ← Hay-Davies transposition + ground reflection
 *   shading(t)        ← obstacle shadows + inter-row shading applied to the beam component
 *   IAM(t)            ← ASHRAE modifier on beam
 *   Tcell(t)          ← Faiman-type thermal model with diurnal ambient cycle
 *   P_dc(t) = kWp · POA_eff/1000 · [1 + γ(Tcell − 25)] · (1−soiling)(1−mismatch)(1−DC wiring)
 *   P_ac(t) = min(P_dc · (1−inverter loss), AC limit) · (1−AC wiring) · availability · (1−other)
 *   E_month = Σ P_ac(t)·Δt · days(m)
 */
import type { Losses, SolarResource, MonthResult, LossStage, HourlyPoint } from '@/types';
import { calculateSolarIrradiance, calculatePlaneOfArrayIrradiance, iamAshrae } from './irradiance';
import { REPRESENTATIVE_DOY, DAYS_IN_MONTH } from './solarPosition';
import { cellTemperature, calculateTemperatureLoss } from './losses';
import { computeObstacleShading, interRowShadedFraction, type ShadingScene } from './shading';
import { clamp } from './units';

export interface EnergySurfaceInput {
  id: string;
  name: string;
  tiltDeg: number;
  azimuthDeg: number;
  panelIndices: number[];
  kWp: number;
  uValue: number;
  racked: boolean;
  tableSlantM: number;
  pitchPlanM: number;
  terrainSlopeDeg: number;
  /** Share of modules in the front row (not shaded by another row). */
  frontRowShare: number;
  seasonalTiltsDeg: number[] | null;
}

export interface EnergyInput {
  latitudeDeg: number;
  resource: SolarResource;
  surfaces: EnergySurfaceInput[];
  moduleEfficiency: number; // 0-1
  gammaPctPerC: number;
  losses: Losses;
  acLimitKw: number | null;
  scene: ShadingScene | null;
  stepHours?: number;
}

export interface EnergyOutput {
  months: MonthResult[];
  /** Annual stage energies (kWh) in order. */
  stages: { key: string; label: string; after: number; source: LossStage['source'] }[];
  surfacePoa: number[]; // annual POA per surface (kWh/m²)
  tempAmplitudeAssumed: boolean;
}

/** Diurnal ambient temperature (°C) at solar hour h - cosine with maximum at 15:00. */
export function ambientAt(tMean: number, tMax: number | null, tMin: number | null, h: number, fallbackAmplitude = 5): number {
  const amp = tMax !== null && tMin !== null ? (tMax - tMin) / 2 : fallbackAmplitude;
  return tMean + amp * Math.cos((2 * Math.PI * (h - 15)) / 24);
}

export function calculateMonthlyEnergy(inp: EnergyInput): EnergyOutput {
  const dt = inp.stepHours ?? 0.5;
  const L = inp.losses;
  const kSoil = 1 - L.soilingPct / 100, kMis = 1 - L.mismatchPct / 100, kDc = 1 - L.dcWiringPct / 100;
  const kInv = 1 - L.inverterPct / 100, kAc = 1 - L.acWiringPct / 100, kAvail = L.availabilityPct / 100, kOther = 1 - L.otherPct / 100;
  const override = L.shadingOverridePct;
  const totalKwp = inp.surfaces.reduce((a, s) => a + s.kWp, 0);
  const tempAmplitudeAssumed = inp.resource.monthly.some((m) => m.tMaxC === null || m.tMinC === null);

  const annual = { nominal: 0, shade: 0, iam: 0, temp: 0, soil: 0, mis: 0, dc: 0, inv: 0, clip: 0, ac: 0, avail: 0, other: 0 };
  const surfacePoa = inp.surfaces.map(() => 0);
  const months: MonthResult[] = [];

  for (let m = 0; m < 12; m++) {
    const clim = inp.resource.monthly[m];
    const doy = REPRESENTATIVE_DOY[m];
    const days = DAYS_IN_MONTH[m];
    const irr = calculateSolarIrradiance(inp.latitudeDeg, doy, clim.ghiKwhM2Day, dt);
    const day = { nominal: 0, shade: 0, iam: 0, temp: 0, soil: 0, mis: 0, dc: 0, inv: 0, clip: 0, ac: 0, avail: 0, other: 0, poaW: 0, beamPoaW: 0, ghi: 0 };
    const hourly: HourlyPoint[] = [];
    const poaSurf = inp.surfaces.map(() => 0);

    for (const pt of irr.points) {
      const ta = ambientAt(clim.tMeanC, clim.tMaxC, clim.tMinC, pt.solarHour);
      const obs = inp.scene && override === null ? computeObstacleShading(inp.scene, pt.elevationDeg, pt.azimuthDeg) : null;
      let stepDc = 0;
      let stepPoaWeighted = 0, stepShade = 0, stepTc = 0;
      day.ghi += pt.ghi * dt;
      inp.surfaces.forEach((s, si) => {
        if (s.kWp <= 0) return;
        const tilt = s.seasonalTiltsDeg ? s.seasonalTiltsDeg[m] : s.tiltDeg;
        const poa = calculatePlaneOfArrayIrradiance(pt.ghi, pt.dhi, pt.zenithDeg, pt.azimuthDeg, tilt, s.azimuthDeg, L.albedo, doy);
        // shading applied to beam
        let fShade = 0;
        if (override !== null) fShade = 0;
        else {
          let fo = 0;
          if (obs && s.panelIndices.length) {
            for (const i of s.panelIndices) fo += obs[i];
            fo /= s.panelIndices.length;
          }
          const fr = s.racked ? interRowShadedFraction(pt.elevationDeg, pt.azimuthDeg, tilt, s.azimuthDeg, s.tableSlantM, s.pitchPlanM, s.terrainSlopeDeg) * (1 - s.frontRowShare) : 0;
          fShade = clamp(1 - (1 - fo) * (1 - fr), 0, 1);
        }
        const beamAfterShade = poa.beam * (1 - fShade);
        const poaShaded = override !== null ? poa.total * (1 - override / 100) : poa.total - poa.beam * fShade;
        const iam = iamAshrae(poa.cosTheta);
        const poaEff = override !== null ? poaShaded - poa.beam * (1 - override / 100) * (1 - iam) : poaShaded - beamAfterShade * (1 - iam);
        const tc = cellTemperature(ta, poaEff, inp.moduleEfficiency, s.uValue);
        const ft = calculateTemperatureLoss(tc, inp.gammaPctPerC);
        const k = s.kWp / 1000; // kW per W/m²
        const eNom = k * poa.total * dt;
        const eShade = k * poaShaded * dt;
        const eIam = k * poaEff * dt;
        const eTemp = eIam * ft;
        day.nominal += eNom; day.shade += eShade; day.iam += eIam; day.temp += eTemp;
        const pDc = (eTemp * kSoil * kMis * kDc) / dt;
        stepDc += pDc;
        poaSurf[si] += poa.total * dt;
        stepPoaWeighted += poa.total * s.kWp;
        stepShade += fShade * s.kWp;
        stepTc += tc * s.kWp;
        day.beamPoaW += poa.beam * s.kWp * dt;
        day.poaW += poa.total * s.kWp * dt;
      });
      day.soil += (stepDc / (kMis * kDc)) * dt;
      day.mis += (stepDc / kDc) * dt;
      day.dc += stepDc * dt;
      const pInv = stepDc * kInv;
      day.inv += pInv * dt;
      const pClip = inp.acLimitKw !== null ? Math.min(pInv, inp.acLimitKw) : pInv;
      day.clip += pClip * dt;
      const pAcW = pClip * kAc;
      day.ac += pAcW * dt;
      day.avail += pAcW * kAvail * dt;
      const pOut = pAcW * kAvail * kOther;
      day.other += pOut * dt;
      if (Math.abs(pt.solarHour - Math.round(pt.solarHour * 2) / 2) < 1e-6 && totalKwp > 0) {
        hourly.push({ hour: pt.solarHour, ghiW: pt.ghi, poaW: stepPoaWeighted / totalKwp, acKw: pOut, cellTempC: stepTc / totalKwp, shadedFraction: stepShade / totalKwp });
      }
    }

    const poaKwhM2Day = totalKwp > 0 ? day.poaW / totalKwp / 1000 : 0;
    const acMonth = day.other * days;
    const nominalMonth = day.nominal * days;
    months.push({
      month: m,
      days,
      ghiKwhM2: clim.ghiKwhM2Day * days,
      poaKwhM2: poaKwhM2Day * days,
      beamFraction: 1 - irr.diffuseFraction,
      peakSunHours: poaKwhM2Day,
      tMeanC: clim.tMeanC,
      nominalKwh: nominalMonth,
      dcKwh: day.dc * days,
      acKwh: acMonth,
      avgDailyKwh: day.other,
      lossesKwh: nominalMonth - acMonth,
      performanceRatio: nominalMonth > 0 ? acMonth / nominalMonth : 0,
      shadingLossPct: day.nominal > 0 ? (1 - day.shade / day.nominal) * 100 : 0,
      iamLossPct: day.shade > 0 ? (1 - day.iam / day.shade) * 100 : 0,
      temperatureLossPct: day.iam > 0 ? (1 - day.temp / day.iam) * 100 : 0,
      hourly,
    });
    (Object.keys(annual) as (keyof typeof annual)[]).forEach((key) => { annual[key] += day[key] * days; });
    poaSurf.forEach((p, i) => { surfacePoa[i] += (p / 1000) * days; });
  }

  const stages = [
    { key: 'nominal', label: 'Nominal (kWp × POA irradiation)', after: annual.nominal, source: 'calculated' as const },
    { key: 'shading', label: override !== null ? 'Shading (user override)' : 'Shading (obstacles + inter-row)', after: annual.shade, source: override !== null ? 'user' as const : 'calculated' as const },
    { key: 'iam', label: 'Reflection (incidence angle)', after: annual.iam, source: 'calculated' as const },
    { key: 'temperature', label: 'Temperature', after: annual.temp, source: 'calculated' as const },
    { key: 'soiling', label: 'Soiling', after: annual.soil, source: 'assumption' as const },
    { key: 'mismatch', label: 'Module mismatch', after: annual.mis, source: 'assumption' as const },
    { key: 'dcWiring', label: 'DC wiring', after: annual.dc, source: 'assumption' as const },
    { key: 'inverter', label: 'Inverter conversion', after: annual.inv, source: 'assumption' as const },
    { key: 'clipping', label: 'Inverter clipping', after: annual.clip, source: 'calculated' as const },
    { key: 'acWiring', label: 'AC wiring', after: annual.ac, source: 'assumption' as const },
    { key: 'availability', label: 'Availability', after: annual.avail, source: 'assumption' as const },
    { key: 'other', label: 'Other losses', after: annual.other, source: 'assumption' as const },
  ];
  return { months, stages, surfacePoa, tempAmplitudeAssumed };
}

/** calculateAnnualEnergy - sum of monthly AC energy (kWh). */
export function calculateAnnualEnergy(months: Pick<MonthResult, 'acKwh'>[]): number {
  return months.reduce((a, m) => a + m.acKwh, 0);
}

/** calculateSpecificYield - kWh per kWp per year. */
export function calculateSpecificYield(annualKwh: number, kWp: number): number {
  return kWp > 0 ? annualKwh / kWp : 0;
}

/** calculateCapacityFactor - annual energy / (DC rating × 8760 h). */
export function calculateCapacityFactor(annualKwh: number, kWp: number): number {
  return kWp > 0 ? annualKwh / (kWp * 8760) : 0;
}

/** calculatePerformanceRatio (IEC 61724 style) - E_ac / (kWp × H_poa / 1 kW/m²). */
export function calculatePerformanceRatio(annualKwh: number, kWp: number, poaKwhM2: number): number {
  const ref = kWp * poaKwhM2;
  return ref > 0 ? annualKwh / ref : 0;
}

/**
 * Daily series for a typical year. Daily GHI is linearly interpolated between the monthly
 * representative days, each day is simulated without shading, and each month's days are then
 * scaled so their sum equals the monthly model result. Illustrative profile - not measured data.
 */
export function calculateDailySeries(inp: EnergyInput, months: MonthResult[]): number[] {
  const mids = REPRESENTATIVE_DOY;
  const ghi = inp.resource.monthly.map((m) => m.ghiKwhM2Day);
  const raw: number[] = [];
  const monthOf: number[] = [];
  let doy = 1;
  for (let m = 0; m < 12; m++) {
    for (let d = 0; d < DAYS_IN_MONTH[m]; d++, doy++) {
      // cyclic linear interpolation between representative days
      let i1 = mids.findIndex((x) => x > doy);
      if (i1 === -1) i1 = 0;
      const i0 = (i1 + 11) % 12;
      const d0 = mids[i0], d1 = mids[i1] + (i1 === 0 ? 365 : 0);
      const dd = doy < d0 ? doy + 365 : doy;
      const t = (dd - d0) / (d1 - d0);
      const g = ghi[i0] * (1 - t) + ghi[i1] * t;
      const irr = calculateSolarIrradiance(inp.latitudeDeg, doy, g, 1);
      let e = 0;
      for (const pt of irr.points) {
        for (const s of inp.surfaces) {
          const tilt = s.seasonalTiltsDeg ? s.seasonalTiltsDeg[m] : s.tiltDeg;
          const poa = calculatePlaneOfArrayIrradiance(pt.ghi, pt.dhi, pt.zenithDeg, pt.azimuthDeg, tilt, s.azimuthDeg, inp.losses.albedo, doy);
          e += (s.kWp * poa.total) / 1000;
        }
      }
      raw.push(e);
      monthOf.push(m);
    }
  }
  const sums = new Array(12).fill(0);
  raw.forEach((e, i) => { sums[monthOf[i]] += e; });
  return raw.map((e, i) => (sums[monthOf[i]] > 0 ? (e / sums[monthOf[i]]) * months[monthOf[i]].acKwh : 0));
}
