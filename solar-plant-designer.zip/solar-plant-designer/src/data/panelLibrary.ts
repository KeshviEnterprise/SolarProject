import type { PanelSpec } from '@/types';

/**
 * Generic panel classes. Values are representative of common module formats on the market
 * (e.g. 144 half-cell 182 mm, 108 half-cell 182 mm, 132 half-cell 210 mm). They are NOT a
 * specific manufacturer's datasheet. Enter your chosen module's datasheet values before
 * relying on any electrical or energy result.
 */
const note = 'Generic class values - not a manufacturer datasheet. Verify against the selected module.';

export const PANEL_LIBRARY: PanelSpec[] = [
  { id: 'gen-550-perc', manufacturer: 'Generic', model: '550 W mono PERC · 144 half-cell (182 mm)', powerW: 550, lengthMm: 2279, widthMm: 1134, thicknessMm: 35, efficiencyPct: 21.3, vocV: 49.6, iscA: 14.0, vmpV: 41.7, impA: 13.2, tempCoeffPmaxPctPerC: -0.35, tempCoeffVocPctPerC: -0.27, technology: 'mono-PERC', bifacial: false, weightKg: 27.5, sourceNote: note },
  { id: 'gen-580-topcon', manufacturer: 'Generic', model: '580 W n-type TOPCon bifacial · 144 half-cell', powerW: 580, lengthMm: 2278, widthMm: 1134, thicknessMm: 30, efficiencyPct: 22.5, vocV: 51.5, iscA: 14.2, vmpV: 42.6, impA: 13.6, tempCoeffPmaxPctPerC: -0.30, tempCoeffVocPctPerC: -0.25, technology: 'TOPCon', bifacial: true, weightKg: 32, sourceNote: note },
  { id: 'gen-440-topcon', manufacturer: 'Generic', model: '440 W n-type TOPCon · 108 half-cell', powerW: 440, lengthMm: 1722, widthMm: 1134, thicknessMm: 30, efficiencyPct: 22.5, vocV: 39.2, iscA: 14.1, vmpV: 32.6, impA: 13.5, tempCoeffPmaxPctPerC: -0.30, tempCoeffVocPctPerC: -0.25, technology: 'TOPCon', bifacial: false, weightKg: 21, sourceNote: note },
  { id: 'gen-410-perc', manufacturer: 'Generic', model: '410 W mono PERC · 108 half-cell', powerW: 410, lengthMm: 1722, widthMm: 1134, thicknessMm: 30, efficiencyPct: 21.0, vocV: 37.3, iscA: 13.9, vmpV: 31.0, impA: 13.2, tempCoeffPmaxPctPerC: -0.35, tempCoeffVocPctPerC: -0.27, technology: 'mono-PERC', bifacial: false, weightKg: 21.5, sourceNote: note },
  { id: 'gen-670-210', manufacturer: 'Generic', model: '670 W mono · 132 half-cell (210 mm)', powerW: 670, lengthMm: 2384, widthMm: 1303, thicknessMm: 35, efficiencyPct: 21.6, vocV: 45.9, iscA: 18.5, vmpV: 38.2, impA: 17.5, tempCoeffPmaxPctPerC: -0.34, tempCoeffVocPctPerC: -0.25, technology: 'mono-PERC', bifacial: false, weightKg: 34, sourceNote: note },
  { id: 'gen-335-poly', manufacturer: 'Generic', model: '335 W polycrystalline · 72-cell', powerW: 335, lengthMm: 1956, widthMm: 992, thicknessMm: 40, efficiencyPct: 17.3, vocV: 46.2, iscA: 9.3, vmpV: 37.6, impA: 8.9, tempCoeffPmaxPctPerC: -0.40, tempCoeffVocPctPerC: -0.31, technology: 'poly', bifacial: false, weightKg: 22, sourceNote: note },
];

export const CUSTOM_PANEL: PanelSpec = {
  id: 'custom', manufacturer: 'Custom', model: 'Custom panel', powerW: 550, lengthMm: 2279, widthMm: 1134, thicknessMm: 35,
  efficiencyPct: 21.3, vocV: 49.6, iscA: 14.0, vmpV: 41.7, impA: 13.2, tempCoeffPmaxPctPerC: -0.35, tempCoeffVocPctPerC: -0.27,
  technology: 'other', bifacial: false, weightKg: 27.5, sourceNote: 'User-entered values.',
};

/** Efficiency (%) from power and area at STC (1000 W/m²). */
export function panelEfficiencyPct(powerW: number, lengthMm: number, widthMm: number): number {
  const a = (lengthMm / 1000) * (widthMm / 1000);
  return a > 0 ? (powerW / (a * 1000)) * 100 : 0;
}
