import type { InverterSpec } from '@/types';

const note = 'Generic class values - not a manufacturer datasheet. Verify against the selected inverter.';

export const INVERTER_LIBRARY: InverterSpec[] = [
  { id: 'gen-5k', manufacturer: 'Generic', model: '5 kW single-phase string', acPowerKw: 5, maxDcVoltageV: 600, mpptMinV: 90, mpptMaxV: 520, mpptCount: 2, maxInputCurrentPerMpptA: 16, maxEfficiencyPct: 97.5, sourceNote: note },
  { id: 'gen-10k', manufacturer: 'Generic', model: '10 kW three-phase string', acPowerKw: 10, maxDcVoltageV: 1100, mpptMinV: 200, mpptMaxV: 1000, mpptCount: 2, maxInputCurrentPerMpptA: 32, maxEfficiencyPct: 98.4, sourceNote: note },
  { id: 'gen-25k', manufacturer: 'Generic', model: '25 kW three-phase string', acPowerKw: 25, maxDcVoltageV: 1100, mpptMinV: 200, mpptMaxV: 1000, mpptCount: 3, maxInputCurrentPerMpptA: 32, maxEfficiencyPct: 98.6, sourceNote: note },
  { id: 'gen-50k', manufacturer: 'Generic', model: '50 kW three-phase string', acPowerKw: 50, maxDcVoltageV: 1100, mpptMinV: 200, mpptMaxV: 1000, mpptCount: 5, maxInputCurrentPerMpptA: 32, maxEfficiencyPct: 98.7, sourceNote: note },
  { id: 'gen-110k', manufacturer: 'Generic', model: '110 kW three-phase string', acPowerKw: 110, maxDcVoltageV: 1100, mpptMinV: 200, mpptMaxV: 1000, mpptCount: 10, maxInputCurrentPerMpptA: 40, maxEfficiencyPct: 98.7, sourceNote: note },
  { id: 'gen-250k', manufacturer: 'Generic', model: '250 kW 1500 V string', acPowerKw: 250, maxDcVoltageV: 1500, mpptMinV: 500, mpptMaxV: 1500, mpptCount: 12, maxInputCurrentPerMpptA: 65, maxEfficiencyPct: 99.0, sourceNote: note },
];
