import type { ObstacleKind } from '@/types';

export interface ObstacleDef { kind: ObstacleKind; label: string; w: number; d: number; h: number; shape: 'rect' | 'circle'; base: 'roof' | 'ground'; buffer: number }

/** Default sizes are placeholders to start from - edit them to measured dimensions. */
export const OBSTACLE_TYPES: ObstacleDef[] = [
  { kind: 'water-tank', label: 'Water tank', w: 2, d: 2, h: 2, shape: 'circle', base: 'roof', buffer: 0.5 },
  { kind: 'hvac', label: 'HVAC unit', w: 2.5, d: 1.5, h: 1.8, shape: 'rect', base: 'roof', buffer: 1 },
  { kind: 'lift-room', label: 'Lift room', w: 3, d: 3, h: 3, shape: 'rect', base: 'roof', buffer: 0.6 },
  { kind: 'staircase', label: 'Staircase', w: 3, d: 5, h: 2.8, shape: 'rect', base: 'roof', buffer: 0.6 },
  { kind: 'vent', label: 'Vent', w: 0.6, d: 0.6, h: 0.8, shape: 'circle', base: 'roof', buffer: 0.3 },
  { kind: 'skylight', label: 'Skylight', w: 1.2, d: 2.4, h: 0, shape: 'rect', base: 'roof', buffer: 0.2 },
  { kind: 'chimney', label: 'Chimney', w: 0.8, d: 0.8, h: 2, shape: 'rect', base: 'roof', buffer: 0.4 },
  { kind: 'nearby-structure', label: 'Nearby structure', w: 10, d: 8, h: 15, shape: 'rect', base: 'ground', buffer: 0 },
  { kind: 'tree', label: 'Tree', w: 6, d: 6, h: 10, shape: 'circle', base: 'ground', buffer: 0 },
  { kind: 'exclusion', label: 'Exclusion zone', w: 4, d: 3, h: 0, shape: 'rect', base: 'roof', buffer: 0 },
  { kind: 'walkway', label: 'Walkway', w: 1, d: 10, h: 0, shape: 'rect', base: 'roof', buffer: 0 },
  { kind: 'other', label: 'Other obstacle', w: 1.5, d: 1.5, h: 1, shape: 'rect', base: 'roof', buffer: 0.3 },
];
export const OBSTACLE_BY_KIND = Object.fromEntries(OBSTACLE_TYPES.map((o) => [o.kind, o])) as Record<ObstacleKind, ObstacleDef>;
