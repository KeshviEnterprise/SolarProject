import type { StructureTypeId, RoofType, RoofMaterial, MountingType } from '@/types';

export interface StructureTypeDef {
  id: StructureTypeId;
  label: string;
  group: 'Residential' | 'Commercial & industrial' | 'Roof construction' | 'Roof shape' | 'Ground & canopy' | 'Custom';
  roofType: RoofType;
  material: RoofMaterial;
  eaveHeightM: number;
  slopeDeg: number;
  parapetHeightM: number;
  setbackM: number;
  mountingType: MountingType;
  lengthM: number;
  widthM: number;
  note: string;
}

/**
 * Structure registry. Defaults are starting assumptions only - every value is editable.
 * Add a new structure by appending an entry here; the engine only depends on `roofType`.
 */
export const STRUCTURE_TYPES: StructureTypeDef[] = [
  { id: 'bungalow', label: 'Bungalow', group: 'Residential', roofType: 'flat', material: 'rcc', eaveHeightM: 4, slopeDeg: 0, parapetHeightM: 0.9, setbackM: 0.6, mountingType: 'fixed-tilt', lengthM: 15, widthM: 12, note: 'Single-storey house, usually RCC flat roof.' },
  { id: 'independent-house', label: 'Independent house', group: 'Residential', roofType: 'flat', material: 'rcc', eaveHeightM: 7, slopeDeg: 0, parapetHeightM: 0.9, setbackM: 0.6, mountingType: 'fixed-tilt', lengthM: 12, widthM: 9, note: 'G+1 house with terrace.' },
  { id: 'residential-building', label: 'Residential building', group: 'Residential', roofType: 'flat', material: 'rcc', eaveHeightM: 12, slopeDeg: 0, parapetHeightM: 1.0, setbackM: 1.0, mountingType: 'fixed-tilt', lengthM: 25, widthM: 15, note: 'Multi-storey residential terrace.' },
  { id: 'apartment-building', label: 'Apartment building', group: 'Residential', roofType: 'flat', material: 'rcc', eaveHeightM: 24, slopeDeg: 0, parapetHeightM: 1.1, setbackM: 1.2, mountingType: 'fixed-tilt', lengthM: 40, widthM: 20, note: 'High-rise terrace; lift rooms and tanks are common.' },
  { id: 'commercial-building', label: 'Commercial building', group: 'Commercial & industrial', roofType: 'flat', material: 'rcc', eaveHeightM: 15, slopeDeg: 0, parapetHeightM: 1.0, setbackM: 1.2, mountingType: 'fixed-tilt', lengthM: 40, widthM: 25, note: 'Flat commercial roof with HVAC plant.' },
  { id: 'office-building', label: 'Office building', group: 'Commercial & industrial', roofType: 'flat', material: 'rcc', eaveHeightM: 18, slopeDeg: 0, parapetHeightM: 1.0, setbackM: 1.2, mountingType: 'fixed-tilt', lengthM: 35, widthM: 25, note: 'Office roof; check for chillers and cooling towers.' },
  { id: 'industrial-shed', label: 'Industrial shed', group: 'Commercial & industrial', roofType: 'gable', material: 'metal-sheet', eaveHeightM: 8, slopeDeg: 10, parapetHeightM: 0, setbackM: 0.5, mountingType: 'roof-following', lengthM: 50, widthM: 30, note: 'Pre-engineered building, trapezoidal metal sheet on purlins.' },
  { id: 'factory', label: 'Factory', group: 'Commercial & industrial', roofType: 'gable', material: 'metal-sheet', eaveHeightM: 9, slopeDeg: 8, parapetHeightM: 0, setbackM: 0.6, mountingType: 'roof-following', lengthM: 80, widthM: 40, note: 'Factory with metal roof.' },
  { id: 'warehouse', label: 'Warehouse', group: 'Commercial & industrial', roofType: 'gable', material: 'metal-sheet', eaveHeightM: 10, slopeDeg: 6, parapetHeightM: 0, setbackM: 0.6, mountingType: 'roof-following', lengthM: 100, widthM: 50, note: 'Large-span warehouse.' },
  { id: 'rcc-rooftop', label: 'RCC rooftop', group: 'Roof construction', roofType: 'flat', material: 'rcc', eaveHeightM: 10, slopeDeg: 0, parapetHeightM: 0.9, setbackM: 1.0, mountingType: 'fixed-tilt', lengthM: 30, widthM: 20, note: 'Reinforced cement concrete slab.' },
  { id: 'concrete-roof', label: 'Concrete roof', group: 'Roof construction', roofType: 'flat', material: 'concrete', eaveHeightM: 8, slopeDeg: 0, parapetHeightM: 0.9, setbackM: 1.0, mountingType: 'fixed-tilt', lengthM: 30, widthM: 20, note: 'Concrete slab roof.' },
  { id: 'metal-sheet-roof', label: 'Metal sheet roof', group: 'Roof construction', roofType: 'shed', material: 'metal-sheet', eaveHeightM: 6, slopeDeg: 5, parapetHeightM: 0, setbackM: 0.5, mountingType: 'roof-following', lengthM: 30, widthM: 20, note: 'Mono-pitch metal sheet.' },
  { id: 'flat-roof', label: 'Flat roof', group: 'Roof shape', roofType: 'flat', material: 'membrane', eaveHeightM: 8, slopeDeg: 0, parapetHeightM: 0.6, setbackM: 1.0, mountingType: 'fixed-tilt', lengthM: 30, widthM: 20, note: 'Generic flat roof.' },
  { id: 'sloped-roof', label: 'Sloped roof', group: 'Roof shape', roofType: 'shed', material: 'tile', eaveHeightM: 5, slopeDeg: 25, parapetHeightM: 0, setbackM: 0.4, mountingType: 'roof-following', lengthM: 12, widthM: 8, note: 'Single sloped plane.' },
  { id: 'gable-roof', label: 'Gable roof', group: 'Roof shape', roofType: 'gable', material: 'tile', eaveHeightM: 5, slopeDeg: 30, parapetHeightM: 0, setbackM: 0.4, mountingType: 'roof-following', lengthM: 14, widthM: 10, note: 'Two planes meeting at a ridge.' },
  { id: 'shed-roof', label: 'Shed roof', group: 'Roof shape', roofType: 'shed', material: 'metal-sheet', eaveHeightM: 4, slopeDeg: 10, parapetHeightM: 0, setbackM: 0.4, mountingType: 'roof-following', lengthM: 12, widthM: 8, note: 'Mono-pitch (lean-to) roof.' },
  { id: 'ground-mounted', label: 'Ground-mounted solar', group: 'Ground & canopy', roofType: 'ground', material: 'soil', eaveHeightM: 0, slopeDeg: 0, parapetHeightM: 0, setbackM: 5, mountingType: 'fixed-tilt', lengthM: 120, widthM: 80, note: 'Fixed-tilt racks on land.' },
  { id: 'solar-carport', label: 'Solar carport', group: 'Ground & canopy', roofType: 'canopy', material: 'metal-sheet', eaveHeightM: 3.0, slopeDeg: 7, parapetHeightM: 0, setbackM: 0, mountingType: 'roof-following', lengthM: 30, widthM: 11, note: 'Canopy over parking bays; modules follow canopy tilt.' },
  { id: 'parking-structure', label: 'Parking structure', group: 'Ground & canopy', roofType: 'flat', material: 'concrete', eaveHeightM: 12, slopeDeg: 0, parapetHeightM: 1.1, setbackM: 1.0, mountingType: 'fixed-tilt', lengthM: 60, widthM: 35, note: 'Top deck of a multi-level car park.' },
  { id: 'custom-rooftop', label: 'Custom rooftop', group: 'Custom', roofType: 'flat', material: 'other', eaveHeightM: 8, slopeDeg: 0, parapetHeightM: 0, setbackM: 0.8, mountingType: 'fixed-tilt', lengthM: 20, widthM: 15, note: 'Draw any roof outline.' },
  { id: 'custom-polygon', label: 'Custom polygon', group: 'Custom', roofType: 'flat', material: 'other', eaveHeightM: 6, slopeDeg: 0, parapetHeightM: 0, setbackM: 0.5, mountingType: 'fixed-tilt', lengthM: 20, widthM: 15, note: 'Draw a polygon in the roof editor.' },
  { id: 'user-defined-area', label: 'User-defined installation area', group: 'Custom', roofType: 'ground', material: 'other', eaveHeightM: 0, slopeDeg: 0, parapetHeightM: 0, setbackM: 1, mountingType: 'fixed-tilt', lengthM: 30, widthM: 20, note: 'Any area; set the height and slope yourself.' },
];

export const STRUCTURE_BY_ID = Object.fromEntries(STRUCTURE_TYPES.map((s) => [s.id, s])) as Record<StructureTypeId, StructureTypeDef>;

export const ROOF_TYPE_LABELS: Record<RoofType, string> = { flat: 'Flat', shed: 'Shed (single slope)', gable: 'Gable (two slopes)', ground: 'Ground', canopy: 'Canopy / carport' };
export const MATERIAL_LABELS: Record<RoofMaterial, string> = { rcc: 'RCC', concrete: 'Concrete', 'metal-sheet': 'Metal sheet', tile: 'Tile', membrane: 'Membrane', soil: 'Soil / land', other: 'Other' };
