import { lazy, Suspense, useEffect, useState } from 'react';
import { useStore } from '@/store/projectStore';
import { TopBar } from '@/components/TopBar';
import { LeftPanel } from '@/components/LeftPanel';
import { RightPanel } from '@/components/RightPanel';
import { Toast } from '@/components/Toast';
import { SECTIONS } from '@/components/sections';
import { Canvas2D } from '@/features/roof-editor/Canvas2D';
import { ENGINEERING_DISCLAIMER } from '@/utils/disclaimers';

const Scene3D = lazy(() => import('@/features/viewer3d/Scene3D').then((m) => ({ default: m.Scene3D })));
const AnalysisView = lazy(() => import('@/features/solar-analysis/AnalysisView').then((m) => ({ default: m.AnalysisView })));
const Dashboard = lazy(() => import('@/features/dashboard/Dashboard').then((m) => ({ default: m.Dashboard })));

function useBreakpoint() {
  const get = () => (window.innerWidth < 768 ? 'mobile' : window.innerWidth < 1280 ? 'tablet' : 'desktop');
  const [bp, setBp] = useState<'mobile' | 'tablet' | 'desktop'>(get);
  useEffect(() => { const on = () => setBp(get()); window.addEventListener('resize', on); return () => window.removeEventListener('resize', on); }, []);
  return bp;
}

function MainView() {
  const view = useStore((s) => s.view);
  return (
    <div className="relative h-full min-h-0 w-full bg-paper">
      <Suspense fallback={<div className="flex h-full items-center justify-center text-[13px] text-char-700">Loading view…</div>}>
        {view === 'plan' && <Canvas2D />}
        {view === '3d' && <ErrorBoundary3D><Scene3D /></ErrorBoundary3D>}
        {view === 'analysis' && <AnalysisView />}
        {view === 'dashboard' && <Dashboard />}
      </Suspense>
    </div>
  );
}

export default function App() {
  const bp = useBreakpoint();
  const [leftCollapsed, setLeftCollapsed] = useState(false);
  const rightOpen = useStore((s) => s.rightOpen);
  const dirty = useStore((s) => s.dirty);
  const { set } = useStore.getState();

  useEffect(() => {
    const onUnload = (e: BeforeUnloadEvent) => { if (useStore.getState().dirty) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', onUnload);
    return () => window.removeEventListener('beforeunload', onUnload);
  }, [dirty]);

  if (bp === 'mobile') return <MobileWizard />;

  return (
    <div className="flex h-full flex-col">
      <a href="#main-view" className="sr-only focus:not-sr-only focus:absolute focus:z-[2000] focus:bg-sun-500 focus:p-2">Skip to drawing</a>
      <TopBar />
      <div className="flex min-h-0 flex-1">
        <LeftPanel collapsed={leftCollapsed} onToggle={() => setLeftCollapsed((c) => !c)} />
        <main id="main-view" className="relative min-w-0 flex-1 border-x border-rule">
          <MainView />
          {bp === 'tablet' && (
            <button className="btn btn-dark absolute right-2 top-16 z-10 px-2 py-1 text-[12px]" onClick={() => set({ rightOpen: !rightOpen })} aria-expanded={rightOpen}>{rightOpen ? 'Hide properties' : 'Properties'}</button>
          )}
        </main>
        {(bp === 'desktop' || rightOpen) && (
          <div className={bp === 'tablet' ? 'absolute bottom-0 right-0 top-12 z-20 w-[320px] border-l border-rule shadow-xl' : 'w-[300px] shrink-0 2xl:w-[330px]'}>
            <RightPanel />
          </div>
        )}
      </div>
      <footer className="shrink-0 border-t border-navy-700 bg-navy-900 px-3 py-1 text-[10.5px] leading-snug text-navy-200">{ENGINEERING_DISCLAIMER}</footer>
      <Toast />
    </div>
  );
}

function MobileWizard() {
  const section = useStore((s) => s.section);
  const view = useStore((s) => s.view);
  const { set } = useStore.getState();
  const idx = Math.max(0, SECTIONS.findIndex((s) => s.id === section));
  const S = SECTIONS[idx];
  return (
    <div className="flex h-full flex-col bg-white">
      <TopBar compact />
      <div className="flex items-center justify-between border-b border-rule bg-paper px-3 py-2">
        <button className="btn btn-secondary px-2 py-1" disabled={idx === 0} onClick={() => set({ section: SECTIONS[idx - 1].id })}>‹ Back</button>
        <div className="text-center"><div className="text-[11px] text-char-700">Step {idx + 1} of {SECTIONS.length}</div><div className="panel-title text-[15px]">{S.label}</div></div>
        <button className="btn btn-primary px-2 py-1" disabled={idx === SECTIONS.length - 1} onClick={() => set({ section: SECTIONS[idx + 1].id })}>Next ›</button>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="h-[46vh] border-b border-rule"><MainView /></div>
        <div className="px-3 py-3"><S.C /></div>
        {view === 'plan' && <div className="border-t border-rule"><RightPanel /></div>}
        <p className="px-3 pb-4 text-[11px] text-char-700">{ENGINEERING_DISCLAIMER}</p>
      </div>
      <Toast />
    </div>
  );
}

import { Component, type ReactNode } from 'react';
class ErrorBoundary3D extends Component<{ children: ReactNode }, { error: string | null }> {
  state = { error: null as string | null };
  static getDerivedStateFromError(e: Error) { return { error: e.message }; }
  render() {
    if (this.state.error) return <div className="flex h-full items-center justify-center p-6 text-center text-[13px] text-char-700">The 3D view could not start ({this.state.error}). WebGL may be disabled in this browser. The 2D plan and all calculations still work.</div>;
    return this.props.children;
  }
}
