/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_SOLAR_PROVIDER?: string;
  readonly VITE_NREL_API_KEY?: string;
  readonly VITE_PVGIS_BASE_URL?: string;
  readonly VITE_SOLAR_TIMEOUT_MS?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv }
