import { useMemo } from 'react';
import { useStore } from '@/store/projectStore';
import { buildSurfaces, calculateAreas, ridgeHeight } from '@/calculations/structure';
import { mountsFor } from '@/calculations/pipeline';
import { calculateLayoutStats, moduleDims, findInvalidPanels } from '@/calculations/panelLayout';
import { collectDesignIssues, systemWeightKg } from '@/calculations/validation';
import { calculateStringConfiguration } from '@/calculations/electrical';
import { convexInsidePolygon, convexPolygonsOverlap, pointInPolygon } from '@/calculations/geometry';

/** Memoised derived engineering values for the current project. */
export function useDerived() {
  const p = useStore((s) => s.project);
  const surfaces = useMemo(() => buildSurfaces(p.structure, p.mounting), [p.structure, p.mounting]);
  const mounts = useMemo(() => mountsFor(surfaces, p.mounting), [surfaces, p.mounting]);
  const areas = useMemo(() => calculateAreas(p.structure, surfaces, p.obstacles), [p.structure, surfaces, p.obstacles]);
  const stats = useMemo(() => calculateLayoutStats(p.layout.panels, p.panel, areas.roofPlanAreaM2, areas.usableAreaM2), [p.layout.panels, p.panel, areas]);
  const invalidPanels = useMemo(() => findInvalidPanels(p.layout.panels, moduleDims(p.panel), p.structure.boundary,
    p.obstacles.filter((o) => pointInPolygon(o.center, p.structure.boundary) || o.kind === 'walkway' || o.kind === 'exclusion'), convexInsidePolygon, convexPolygonsOverlap),
  [p.layout.panels, p.panel, p.structure.boundary, p.obstacles]);
  const issues = useMemo(() => collectDesignIssues(p), [p]);
  const strings = useMemo(() => calculateStringConfiguration({ panel: p.panel, inverter: p.electrical.inverter, inverterQty: p.electrical.inverterQty, modulesPerString: p.electrical.modulesPerString, stringsTotal: p.electrical.stringsTotal, minAmbientC: p.electrical.minAmbientC, maxAmbientC: p.electrical.maxAmbientC, layoutPanelCount: p.layout.panels.length }), [p.panel, p.electrical, p.layout.panels.length]);
  const weightKg = useMemo(() => systemWeightKg(p), [p]);
  const ridge = useMemo(() => ridgeHeight(surfaces), [surfaces]);
  return { project: p, surfaces, mounts, areas, stats, invalidPanels, issues, strings, weightKg, ridge };
}
