import { useEffect, useState } from 'react';
import { useStore } from '@/store/projectStore';

export function Toast() {
  const toast = useStore((s) => s.toast);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    if (!toast) return;
    setShown(true);
    const t = window.setTimeout(() => setShown(false), toast.tone === 'error' ? 6000 : 3000);
    return () => window.clearTimeout(t);
  }, [toast]);
  if (!toast || !shown) return <div aria-live="polite" className="sr-only" />;
  const cls = toast.tone === 'error' ? 'bg-alarm-600 text-white' : toast.tone === 'ok' ? 'bg-navy-900 text-white border-l-4 border-leaf-500' : 'bg-navy-900 text-white border-l-4 border-sun-500';
  return (
    <div aria-live="polite" role="status" className={`fixed bottom-4 left-1/2 z-[1000] -translate-x-1/2 rounded-[3px] px-4 py-2 text-[13px] shadow-lg ${cls}`} data-testid="toast">{toast.text}</div>
  );
}
