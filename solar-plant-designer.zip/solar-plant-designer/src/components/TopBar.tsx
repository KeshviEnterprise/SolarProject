import { useStore, type ViewId } from '@/store/projectStore';
import { runAnalysisAction } from '@/services/actions';

const VIEWS: { id: ViewId; label: string }[] = [{ id: 'plan', label: '2D' }, { id: '3d', label: '3D' }, { id: 'analysis', label: 'Results' }, { id: 'dashboard', label: 'Dashboard' }];

export function TopBar({ compact = false }: { compact?: boolean }) {
  const name = useStore((s) => s.project.name);
  const dirty = useStore((s) => s.dirty);
  const view = useStore((s) => s.view);
  const canUndo = useStore((s) => s.past.length > 0);
  const canRedo = useStore((s) => s.future.length > 0);
  const aStatus = useStore((s) => s.analysisStatus);
  const isDemo = useStore((s) => !!s.project.solarResource?.isDemo);
  const { save, undo, redo, set } = useStore.getState();

  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b border-navy-700 bg-navy-900 px-3 text-white">
      <div className="flex min-w-0 items-center gap-2">
        <svg width="22" height="22" viewBox="0 0 32 32" aria-hidden><rect x="3" y="12" width="26" height="15" rx="1.5" fill="#2563EB" stroke="#9CC0FF" /><path d="M3 19.5h26M11.7 12v15M20.3 12v15" stroke="#9CC0FF" /><circle cx="24" cy="6" r="3.5" fill="#F5B700" /></svg>
        {!compact && <span className="hidden font-cond text-[15px] font-semibold tracking-tight text-sun-400 lg:inline">Solar Plant Designer</span>}
        <span className="hidden text-navy-400 lg:inline">/</span>
        <span className="truncate text-[13.5px] font-medium" title={name}>{name}</span>
        {dirty && <span className="h-2 w-2 shrink-0 rounded-full bg-sun-500" title="Unsaved changes" aria-label="Unsaved changes" />}
        {isDemo && <span className="rounded-[2px] bg-alarm-600 px-1 text-[10px] font-bold">DEMO DATA</span>}
      </div>
      <div className="ml-auto flex items-center gap-1">
        <button className="btn btn-dark px-2 py-1" onClick={save} data-testid="save-top" title="Save (Ctrl+S)">Save</button>
        <button className="btn btn-dark px-2 py-1" onClick={undo} disabled={!canUndo} title="Undo (Ctrl+Z)" aria-label="Undo">↶<span className="hidden md:inline">Undo</span></button>
        <button className="btn btn-dark px-2 py-1" onClick={redo} disabled={!canRedo} title="Redo (Ctrl+Shift+Z)" aria-label="Redo">↷<span className="hidden md:inline">Redo</span></button>
        <div className="mx-1 flex overflow-hidden rounded-[3px] border border-navy-600" role="tablist" aria-label="View">
          {VIEWS.map((v) => (
            <button key={v.id} role="tab" aria-selected={view === v.id} data-testid={`view-${v.id}`} className={`px-2.5 py-1 text-[12.5px] font-semibold ${view === v.id ? 'bg-sun-500 text-navy-950' : 'bg-navy-800 text-white hover:bg-navy-700'}`} onClick={() => set({ view: v.id })}>{v.label}</button>
          ))}
        </div>
        <button className="btn btn-primary px-2.5 py-1" data-testid="run-analysis" disabled={aStatus === 'running'} onClick={() => void runAnalysisAction()}>{aStatus === 'running' ? 'Running…' : 'Run analysis'}</button>
        <button className="btn btn-dark hidden px-2 py-1 sm:inline-flex" data-testid="export-open" onClick={() => set({ section: 'reports' })}>Export</button>
      </div>
    </header>
  );
}
