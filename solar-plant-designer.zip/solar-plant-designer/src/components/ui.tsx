import { useEffect, useId, useState, type ReactNode } from 'react';
import type { LengthUnit, Provenance } from '@/types';
import { fromMetres, toMetres } from '@/calculations/units';

const TAGS: Record<Provenance, { text: string; cls: string; title: string }> = {
  user: { text: 'USER INPUT', cls: 'bg-pv-100 text-pv-700 border-pv-500/40', title: 'Entered by the user' },
  calculated: { text: 'CALCULATED', cls: 'bg-leaf-100 text-leaf-600 border-leaf-500/40', title: 'Computed from other values by a documented formula' },
  estimated: { text: 'ESTIMATED', cls: 'bg-sun-100 text-[#8a6500] border-sun-500/50', title: 'Approximation or heuristic - verify on site' },
  external: { text: 'EXTERNAL DATA', cls: 'bg-[#E6E1F7] text-[#4B3A99] border-[#4B3A99]/30', title: 'Retrieved from an external data service' },
  demo: { text: 'DEMO', cls: 'bg-alarm-100 text-alarm-600 border-alarm-600/40', title: 'Synthetic demo value - not measured' },
  assumption: { text: 'ASSUMPTION', cls: 'bg-[#ECEEF1] text-char-700 border-char-700/20', title: 'Explicit design assumption, editable' },
};

export function Tag({ kind, className = '' }: { kind: Provenance; className?: string }) {
  const t = TAGS[kind];
  return <span title={t.title} className={`inline-block whitespace-nowrap rounded-[2px] border px-1 py-[1px] text-[9.5px] font-semibold leading-none tracking-wide ${t.cls} ${className}`}>{t.text}</span>;
}

export interface CalcLine { label: string; value: string }

/** "How is this calculated?" disclosure with formula and actual input values. */
export function HowCalculated({ formula, lines, result, note }: { formula: string; lines: CalcLine[]; result?: string; note?: string }) {
  return (
    <details className="group mt-1 text-[12px]">
      <summary className="cursor-pointer select-none text-pv-700 hover:underline">How is this calculated?</summary>
      <div className="mt-1 rounded-[3px] border border-rule bg-paper p-2">
        <div className="font-cond font-semibold text-navy-900 whitespace-pre-wrap">{formula}</div>
        <table className="mt-1 w-full">
          <tbody>
            {lines.map((l) => (
              <tr key={l.label}><td className="py-[1px] pr-2 text-char-700">{l.label}</td><td className="py-[1px] text-right font-medium">{l.value}</td></tr>
            ))}
            {result && <tr className="border-t border-char-700/30"><td className="pt-1 font-semibold">Result</td><td className="pt-1 text-right font-semibold">{result}</td></tr>}
          </tbody>
        </table>
        {note && <p className="mt-1 text-char-700">{note}</p>}
      </div>
    </details>
  );
}

type NumKind = 'length' | 'plain';

interface NumberFieldProps {
  label: string;
  /** Value in SI (metres for length). */
  value: number | null;
  onCommit: (v: number | null) => void;
  kind?: NumKind;
  unit?: string;
  displayUnit?: LengthUnit;
  min?: number;
  max?: number;
  step?: number;
  allowEmpty?: boolean;
  tag?: Provenance;
  hint?: string;
  validate?: (v: number) => string | null;
  testId?: string;
  disabled?: boolean;
  hideLabel?: boolean;
}

/**
 * Numeric input. Length fields carry their own unit selector; values are converted to metres
 * before being stored. Commits on blur / Enter; invalid values are shown and not stored.
 */
export function NumberField(props: NumberFieldProps) {
  const { label, value, onCommit, kind = 'plain', min, max, step, allowEmpty, tag, hint, validate, testId, disabled, hideLabel } = props;
  const id = useId();
  const [unit, setUnit] = useState<LengthUnit>(props.displayUnit ?? 'm');
  useEffect(() => { if (props.displayUnit) setUnit(props.displayUnit); }, [props.displayUnit]);
  const toDisplay = (v: number | null) => (v === null || !Number.isFinite(v) ? '' : String(+(kind === 'length' ? fromMetres(v, unit) : v).toFixed(kind === 'length' && unit === 'mm' ? 1 : 4)));
  const [text, setText] = useState(toDisplay(value));
  const [err, setErr] = useState<string | null>(null);
  const [focused, setFocused] = useState(false);
  useEffect(() => { if (!focused) setText(toDisplay(value)); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, unit, focused]);

  const commit = () => {
    const t = text.trim();
    if (t === '') {
      if (allowEmpty) { setErr(null); onCommit(null); } else setErr('A value is required');
      return;
    }
    const n = Number(t.replace(',', '.'));
    if (!Number.isFinite(n)) { setErr('Enter a number'); return; }
    const si = kind === 'length' ? toMetres(n, unit) : n;
    if (min !== undefined && si < min) { setErr(`Must be at least ${kind === 'length' ? +fromMetres(min, unit).toFixed(3) : min}`); return; }
    if (max !== undefined && si > max) { setErr(`Must be at most ${kind === 'length' ? +fromMetres(max, unit).toFixed(3) : max}`); return; }
    const v = validate?.(si);
    if (v) { setErr(v); return; }
    setErr(null);
    if (si !== value) onCommit(si);
  };

  return (
    <div className="min-w-0">
      <label htmlFor={id} className={hideLabel ? 'sr-only' : 'label flex items-center gap-1.5'}>
        <span className="truncate">{label}</span>{tag && <Tag kind={tag} />}
      </label>
      <div className="flex">
        <input
          id={id} data-testid={testId} inputMode="decimal" className={`input ${kind === 'length' || props.unit ? 'rounded-r-none' : ''}`}
          value={text} disabled={disabled} step={step} aria-invalid={!!err} aria-describedby={err ? `${id}-e` : hint ? `${id}-h` : undefined}
          onFocus={() => setFocused(true)}
          onChange={(e) => setText(e.target.value)}
          onBlur={() => { setFocused(false); commit(); }}
          onKeyDown={(e) => { if (e.key === 'Enter') { commit(); (e.target as HTMLInputElement).blur(); } if (e.key === 'Escape') { setText(toDisplay(value)); setErr(null); } }}
        />
        {kind === 'length' ? (
          <select aria-label={`${label} unit`} className="rounded-r-[3px] border border-l-0 border-rule bg-paper px-1 text-[12px]" value={unit} onChange={(e) => setUnit(e.target.value as LengthUnit)}>
            {(['mm', 'cm', 'm', 'in', 'ft'] as LengthUnit[]).map((u) => <option key={u}>{u}</option>)}
          </select>
        ) : props.unit ? (
          <span className="flex items-center rounded-r-[3px] border border-l-0 border-rule bg-paper px-2 text-[12px] text-char-700">{props.unit}</span>
        ) : null}
      </div>
      {err ? <p id={`${id}-e`} role="alert" className="mt-0.5 text-[11.5px] text-alarm-600">{err}</p> : hint ? <p id={`${id}-h`} className="mt-0.5 text-[11.5px] text-char-700">{hint}</p> : null}
    </div>
  );
}

export function TextField({ label, value, onCommit, placeholder, testId }: { label: string; value: string; onCommit: (v: string) => void; placeholder?: string; testId?: string }) {
  const id = useId();
  const [t, setT] = useState(value);
  useEffect(() => setT(value), [value]);
  return (
    <div className="min-w-0">
      <label htmlFor={id} className="label">{label}</label>
      <input id={id} data-testid={testId} className="input" value={t} placeholder={placeholder} onChange={(e) => setT(e.target.value)} onBlur={() => t !== value && onCommit(t)} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
    </div>
  );
}

export function SelectField<T extends string>({ label, value, options, onChange, tag, testId }: { label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; tag?: Provenance; testId?: string }) {
  const id = useId();
  return (
    <div className="min-w-0">
      <label htmlFor={id} className="label flex items-center gap-1.5">{label}{tag && <Tag kind={tag} />}</label>
      <select id={id} data-testid={testId} className="input" value={value} onChange={(e) => onChange(e.target.value as T)}>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

export function Toggle({ label, checked, onChange, testId }: { label: string; checked: boolean; onChange: (v: boolean) => void; testId?: string }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-[13px]">
      <input type="checkbox" data-testid={testId} className="h-4 w-4 accent-pv-600" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}

export function KV({ label, value, tag, children }: { label: string; value: ReactNode; tag?: Provenance; children?: ReactNode }) {
  return (
    <div className="border-b border-dashed border-rule/80 py-1">
      <div className="flex items-baseline justify-between gap-3 text-[13px]">
        <span className="text-char-700">{label}</span>
        <span className="flex items-center gap-1.5 text-right font-semibold text-char-900">{value}{tag && <Tag kind={tag} />}</span>
      </div>
      {children}
    </div>
  );
}

export function Notice({ tone, children }: { tone: 'info' | 'warning' | 'error' | 'demo'; children: ReactNode }) {
  const cls = { info: 'border-pv-500 bg-pv-100/60', warning: 'border-sun-500 bg-sun-100', error: 'border-alarm-600 bg-alarm-100', demo: 'border-alarm-600 bg-alarm-100' }[tone];
  return <div role={tone === 'error' ? 'alert' : 'note'} className={`border-l-4 px-2.5 py-1.5 text-[12.5px] leading-snug ${cls}`}>{children}</div>;
}

export function Grid2({ children }: { children: ReactNode }) {
  return <div className="grid grid-cols-2 gap-x-3 gap-y-2.5">{children}</div>;
}

export const fmt = (n: number | null | undefined, d = 2) => (n === null || n === undefined || !Number.isFinite(n) ? '—' : n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }));
