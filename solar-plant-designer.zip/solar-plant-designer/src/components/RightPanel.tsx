import { useState } from 'react';
import { useStore } from '@/store/projectStore';
import { useDerived } from '@/hooks/useDerived';
import { NumberField, SelectField, TextField, KV, Notice, Grid2, fmt } from '@/components/ui';
import { OBSTACLE_TYPES, OBSTACLE_BY_KIND } from '@/data/obstacleTypes';
import { orientedDims, moduleDims } from '@/calculations/panelLayout';
import { azimuthVector, polygonArea, v } from '@/calculations/geometry';
import { rectangleBoundary } from '@/calculations/structure';
import { formatArea, formatLength } from '@/calculations/units';
import { uid } from '@/utils/id';
import { ENGINEERING_DISCLAIMER } from '@/utils/disclaimers';
import type { Obstacle, ObstacleKind, PlacedPanel } from '@/types';

export function RightPanel() {
  const sel = useStore((s) => s.selection);
  const p = useStore((s) => s.project);
  if (sel.kind === 'obstacle' && sel.ids.length === 1) {
    const o = p.obstacles.find((x) => x.id === sel.ids[0]);
    if (o) return <ObstacleProps o={o} />;
  }
  if (sel.kind === 'panel' && sel.ids.length) return <PanelProps ids={sel.ids} />;
  if (sel.kind === 'boundary') return <BoundaryProps />;
  return <Summary />;
}

function Shell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <aside className="flex h-full w-full flex-col bg-white" aria-label="Properties">
      <header className="border-b border-rule px-3 py-2"><h2 className="panel-title">{title}</h2></header>
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3">{children}</div>
    </aside>
  );
}

function ObstacleProps({ o }: { o: Obstacle }) {
  const { update, set } = useStore.getState();
  const u = useStore((s) => s.project.settings.displayUnit);
  const setO = (patch: Partial<Obstacle>) => update((q) => ({ ...q, obstacles: q.obstacles.map((x) => (x.id === o.id ? { ...x, ...patch } : x)), analysis: null }));
  const isZone = o.kind === 'exclusion' || o.kind === 'walkway';
  return (
    <Shell title="Obstacle properties">
      <TextField label="Label" value={o.label} onCommit={(label) => setO({ label })} />
      <Grid2>
        <SelectField<ObstacleKind> label="Type" value={o.kind} options={OBSTACLE_TYPES.map((t) => ({ value: t.kind, label: t.label }))} onChange={(k) => setO({ kind: k, shape: OBSTACLE_BY_KIND[k].shape })} />
        <SelectField<'rect' | 'circle'> label="Shape" value={o.shape} options={[{ value: 'rect', label: 'Rectangle' }, { value: 'circle', label: 'Circle' }]} onChange={(shape) => setO({ shape })} />
        <NumberField label={o.shape === 'circle' ? 'Diameter' : 'Width (x before rotation)'} kind="length" displayUnit={u} value={o.widthM} min={0.05} max={500} testId="ob-width" onCommit={(x) => x !== null && setO(o.shape === 'circle' ? { widthM: x, depthM: x } : { widthM: x })} tag="user" />
        {o.shape === 'rect' && <NumberField label="Depth (y before rotation)" kind="length" displayUnit={u} value={o.depthM} min={0.05} max={500} onCommit={(x) => x !== null && setO({ depthM: x })} tag="user" />}
        {!isZone && <NumberField label="Height" kind="length" displayUnit={u} value={o.heightM} min={0} max={300} testId="ob-height" onCommit={(x) => x !== null && setO({ heightM: x })} tag="user" />}
        <NumberField label="Rotation" unit="°" value={o.rotationDeg} min={-360} max={360} onCommit={(x) => x !== null && setO({ rotationDeg: ((x % 360) + 360) % 360 })} />
        <NumberField label="Keep-out buffer" kind="length" displayUnit={u} value={o.bufferM} min={0} max={20} onCommit={(x) => x !== null && setO({ bufferM: x })} />
        <NumberField label="Centre x (east)" kind="length" displayUnit={u} value={o.center.x} min={-5000} max={5000} onCommit={(x) => x !== null && setO({ center: v(x, o.center.y) })} />
        <NumberField label="Centre y (north)" kind="length" displayUnit={u} value={o.center.y} min={-5000} max={5000} onCommit={(y) => y !== null && setO({ center: v(o.center.x, y) })} />
      </Grid2>
      {!isZone && <SelectField<'roof' | 'ground'> label="Stands on" value={o.base} options={[{ value: 'roof', label: 'Roof surface' }, { value: 'ground', label: 'Ground' }]} onChange={(base) => setO({ base })} />}
      <p className="text-[11.5px] text-char-700">{o.base === 'ground' ? 'Height is measured from ground level.' : 'Height is measured from the roof surface at its centre.'} Shading uses the obstacle as a vertical prism{o.kind === 'tree' ? ' (tree crown modelled as a solid cylinder - conservative)' : ''}.</p>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" onClick={() => { const c = { ...o, id: uid('ob'), label: `${o.label} copy`, center: v(o.center.x + 1, o.center.y - 1) }; update((q) => ({ ...q, obstacles: [...q.obstacles, c] })); set({ selection: { kind: 'obstacle', ids: [c.id] } }); }}>Duplicate</button>
        <button className="btn btn-danger" data-testid="delete-obstacle" onClick={() => { update((q) => ({ ...q, obstacles: q.obstacles.filter((x) => x.id !== o.id), analysis: null })); set({ selection: { kind: null, ids: [] } }); }}>Delete</button>
      </div>
      <p className="text-[11.5px] text-char-700">Existing panels are not moved automatically. Re-run the auto layout, or check panels outlined in red.</p>
    </Shell>
  );
}

function PanelProps({ ids }: { ids: string[] }) {
  const p = useStore((s) => s.project);
  const { update, set } = useStore.getState();
  const [rowN, setRowN] = useState(5);
  const [dir, setDir] = useState<1 | -1>(1);
  const idSet = new Set(ids);
  const sel = p.layout.panels.filter((x) => idSet.has(x.id));
  const one = sel.length === 1 ? sel[0] : null;
  const allLocked = sel.every((x) => x.locked);
  const upd = (fn: (pn: PlacedPanel) => PlacedPanel) => update((q) => ({ ...q, layout: { ...q.layout, panels: q.layout.panels.map((x) => (idSet.has(x.id) ? fn(x) : x)) }, analysis: null }));
  const dims = moduleDims(p.panel);
  const u = p.settings.displayUnit;

  const createRow = () => {
    if (!one) return;
    const od = orientedDims(dims, one.orientation);
    const f = azimuthVector(one.azimuthDeg);
    const r = v(f.y, -f.x); // along-row direction
    const step = od.alongRow + p.mounting.moduleGapM;
    const copies: PlacedPanel[] = Array.from({ length: rowN }, (_, i) => ({ ...one, id: uid('pm'), locked: false, manual: true, center: v(one.center.x + r.x * step * (i + 1) * dir, one.center.y + r.y * step * (i + 1) * dir) }));
    update((q) => ({ ...q, layout: { ...q.layout, panels: [...q.layout.panels, ...copies] }, analysis: null }));
    set({ selection: { kind: 'panel', ids: [one.id, ...copies.map((c) => c.id)] } });
  };

  return (
    <Shell title={one ? 'Panel properties' : `${sel.length} panels selected`}>
      <KV label="Selected capacity" value={`${fmt((sel.length * p.panel.powerW) / 1000, 2)} kWp`} tag="calculated" />
      {one && (<>
        <KV label="Surface / row" value={`${one.surfaceId} / ${one.row >= 0 ? one.row + 1 : 'manual'}`} />
        <Grid2>
          <NumberField label="Centre x" kind="length" displayUnit={u} value={one.center.x} min={-5000} max={5000} onCommit={(x) => x !== null && upd((pn) => ({ ...pn, center: v(x, pn.center.y) }))} disabled={one.locked} />
          <NumberField label="Centre y" kind="length" displayUnit={u} value={one.center.y} min={-5000} max={5000} onCommit={(y) => y !== null && upd((pn) => ({ ...pn, center: v(pn.center.x, y) }))} disabled={one.locked} />
          <NumberField label="Azimuth" unit="°" value={one.azimuthDeg} min={0} max={360} onCommit={(a) => a !== null && upd((pn) => ({ ...pn, azimuthDeg: a % 360 }))} disabled={one.locked} />
          <NumberField label="Tilt" unit="°" value={one.tiltDeg} min={0} max={75} onCommit={(t) => t !== null && upd((pn) => ({ ...pn, tiltDeg: t }))} disabled={one.locked} />
        </Grid2>
      </>)}
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" onClick={() => upd((pn) => ({ ...pn, locked: !allLocked }))}>{allLocked ? 'Unlock' : 'Lock'}</button>
        <button className="btn btn-secondary" onClick={() => upd((pn) => (pn.locked ? pn : { ...pn, orientation: pn.orientation === 'portrait' ? 'landscape' : 'portrait', manual: true }))}>Rotate 90°</button>
        <button className="btn btn-secondary" onClick={() => {
          const copies = sel.map((x) => ({ ...x, id: uid('pm'), manual: true, locked: false, row: -1, center: v(x.center.x + 1, x.center.y - 1) }));
          update((q) => ({ ...q, layout: { ...q.layout, panels: [...q.layout.panels, ...copies] }, analysis: null }));
          set({ selection: { kind: 'panel', ids: copies.map((c) => c.id) } });
        }}>Duplicate</button>
        <button className="btn btn-danger" data-testid="delete-panels" onClick={() => { update((q) => ({ ...q, layout: { ...q.layout, panels: q.layout.panels.filter((x) => !idSet.has(x.id) || x.locked) }, analysis: null })); set({ selection: { kind: null, ids: [] } }); }}>Delete</button>
      </div>
      {one && (
        <div className="rounded-[3px] border border-rule p-2">
          <h3 className="mb-1.5 text-[12.5px] font-semibold">Create row from this panel</h3>
          <Grid2>
            <NumberField label="Additional panels" value={rowN} min={1} max={500} onCommit={(n) => n !== null && setRowN(Math.round(n))} />
            <SelectField<'1' | '-1'> label="Direction" value={String(dir) as '1' | '-1'} options={[{ value: '1', label: 'Along row (+)' }, { value: '-1', label: 'Along row (−)' }]} onChange={(d) => setDir(Number(d) as 1 | -1)} />
          </Grid2>
          <button className="btn btn-dark mt-2 w-full" onClick={createRow}>Create row</button>
          <p className="mt-1 text-[11px] text-char-700">Spacing = module width along the row + module gap ({formatLength(p.mounting.moduleGapM, 'mm')}).</p>
        </div>
      )}
      {sel.some((x) => x.locked) && <p className="text-[11.5px] text-char-700">Locked panels are not moved or deleted.</p>}
    </Shell>
  );
}

function BoundaryProps() {
  const b = useStore((s) => s.project.structure.boundary);
  const st = useStore((s) => s.project.structure);
  const { update } = useStore.getState();
  const edges = b.map((a, i) => { const c = b[(i + 1) % b.length]; return { i, len: Math.hypot(c.x - a.x, c.y - a.y) }; });
  const longest = edges.reduce((m, e) => (e.len > m.len ? e : m), edges[0]);
  return (
    <Shell title="Boundary">
      <KV label="Vertices" value={String(b.length)} />
      <KV label="Area" value={formatArea(polygonArea(b), 'm')} tag="calculated" />
      <p className="text-[12px] text-char-700">Drag the yellow vertex handles on the plan (hold Shift to snap to 0.25 m). Exact coordinates can be typed in the Roof editor section.</p>
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-secondary" onClick={() => update((q) => { const bb = q.structure.boundary; const i = longest.i; const a = bb[i], c = bb[(i + 1) % bb.length]; const nb = [...bb]; nb.splice(i + 1, 0, v((a.x + c.x) / 2, (a.y + c.y) / 2)); return { ...q, structure: { ...q.structure, boundary: nb } }; })}>Add vertex (longest edge)</button>
        <button className="btn btn-secondary" disabled={b.length <= 3} onClick={() => update((q) => ({ ...q, structure: { ...q.structure, boundary: q.structure.boundary.slice(0, -1) } }))}>Remove last vertex</button>
        <button className="btn btn-secondary" onClick={() => update((q) => ({ ...q, structure: { ...q.structure, boundary: rectangleBoundary(st.lengthM, st.widthM) } }))}>Reset to {st.lengthM} × {st.widthM} m rectangle</button>
      </div>
    </Shell>
  );
}

function Summary() {
  const { project: p, stats, areas, issues } = useDerived();
  return (
    <Shell title="Design summary">
      <KV label="Panels" value={String(stats.panelCount)} tag="calculated" />
      <KV label="DC capacity" value={`${fmt(stats.dcKwp, 2)} kWp`} tag="calculated" />
      <KV label="Usable area" value={formatArea(areas.usableAreaM2, p.settings.displayUnit)} tag="calculated" />
      <KV label="Utilisation" value={`${fmt(stats.utilizationPct, 1)} %`} tag="calculated" />
      {p.analysis && <KV label="Annual energy" value={`${fmt(p.analysis.annualAcKwh, 0)} kWh`} tag={p.analysis.isDemoData ? 'demo' : 'calculated'} />}
      <h3 className="subhead">Warnings and checks ({issues.length})</h3>
      <div className="space-y-1.5" data-testid="issues">
        {issues.length === 0 && <p className="text-[12.5px] text-char-700">No issues found.</p>}
        {issues.map((i) => <Notice key={i.message} tone={i.level === 'error' ? 'error' : i.level === 'warning' ? 'warning' : 'info'}><strong>{i.area}:</strong> {i.message}</Notice>)}
      </div>
      <p className="text-[12px] text-char-700">Select an obstacle, panel or the boundary on the plan to edit its properties here.</p>
      <h3 className="subhead">Disclaimer</h3>
      <p className="text-[11.5px] leading-relaxed text-char-700">{ENGINEERING_DISCLAIMER}</p>
    </Shell>
  );
}
