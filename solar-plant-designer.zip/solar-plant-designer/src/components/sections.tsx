import type { SectionId } from '@/store/projectStore';
import { ProjectSection } from '@/features/project/ProjectSection';
import { LocationSection } from '@/features/location/LocationSection';
import { StructureSection } from '@/features/structure/StructureSection';
import { RoofSection } from '@/features/roof-editor/RoofSection';
import { PanelSection } from '@/features/panel-library/PanelSection';
import { MountingSection } from '@/features/layout-engine/MountingSection';
import { LayoutSection } from '@/features/layout-engine/LayoutSection';
import { ShadingSection } from '@/features/shading/ShadingSection';
import { ElectricalSection } from '@/features/electrical/ElectricalSection';
import { EnergySection } from '@/features/solar-analysis/EnergySection';
import { ReportsSection } from '@/features/reports/ReportsSection';

export const SECTIONS: { id: SectionId; label: string; C: () => JSX.Element }[] = [
  { id: 'project', label: 'Project', C: ProjectSection },
  { id: 'location', label: 'Location', C: LocationSection },
  { id: 'structure', label: 'Structure', C: StructureSection },
  { id: 'roof', label: 'Roof editor', C: RoofSection },
  { id: 'panels', label: 'Panels', C: PanelSection },
  { id: 'mounting', label: 'Mounting', C: MountingSection },
  { id: 'layout', label: 'Layout', C: LayoutSection },
  { id: 'shading', label: 'Shading', C: ShadingSection },
  { id: 'electrical', label: 'Electrical', C: ElectricalSection },
  { id: 'energy', label: 'Energy analysis', C: EnergySection },
  { id: 'reports', label: 'Reports', C: ReportsSection },
];
