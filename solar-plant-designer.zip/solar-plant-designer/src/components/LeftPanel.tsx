import { useStore } from '@/store/projectStore';
import { SECTIONS } from './sections';

export function LeftPanel({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const section = useStore((s) => s.section);
  const { set } = useStore.getState();
  const active = SECTIONS.find((s) => s.id === section) ?? SECTIONS[0];
  const idx = SECTIONS.indexOf(active);
  return (
    <div className="flex h-full min-h-0">
      <nav className="flex w-[118px] shrink-0 flex-col border-r border-navy-700 bg-navy-900 py-1" aria-label="Design sections">
        {SECTIONS.map((s, i) => (
          <button key={s.id} data-testid={`nav-${s.id}`} aria-current={section === s.id ? 'page' : undefined}
            className={`flex items-center gap-1.5 border-l-[3px] px-2 py-[7px] text-left text-[12.5px] ${section === s.id ? 'border-sun-500 bg-navy-800 font-semibold text-white' : 'border-transparent text-navy-200 hover:bg-navy-800 hover:text-white'}`}
            onClick={() => { set({ section: s.id }); if (collapsed) onToggle(); }}>
            <span className="w-4 shrink-0 text-right font-cond text-[11px] text-navy-400">{i + 1}</span>{s.label}
          </button>
        ))}
        <button className="mt-auto px-2 py-2 text-left text-[11.5px] text-navy-300 hover:text-white" onClick={onToggle} aria-expanded={!collapsed}>{collapsed ? '» Show panel' : '« Hide panel'}</button>
      </nav>
      {!collapsed && (
        <section className="flex w-[340px] min-w-0 flex-col bg-white xl:w-[360px]" aria-label={active.label}>
          <header className="flex items-center justify-between border-b border-rule px-3 py-2">
            <h2 className="panel-title"><span className="mr-1.5 font-normal text-char-700">{idx + 1}.</span>{active.label}</h2>
          </header>
          <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3"><active.C /></div>
        </section>
      )}
    </div>
  );
}
