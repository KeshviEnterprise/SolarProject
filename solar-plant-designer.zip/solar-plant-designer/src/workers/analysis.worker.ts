/// <reference lib="webworker" />
import { runAnalysis, generateLayoutOptions, optimiseTilt } from '@/calculations/pipeline';
import type { Project } from '@/types';

type Req = { id: number; type: 'analysis' | 'options' | 'tilt'; project: Project };

self.onmessage = (ev: MessageEvent<Req>) => {
  const { id, type, project } = ev.data;
  try {
    const result = type === 'analysis' ? runAnalysis(project) : type === 'options' ? generateLayoutOptions(project) : optimiseTilt(project);
    (self as unknown as Worker).postMessage({ id, ok: true, result });
  } catch (e) {
    (self as unknown as Worker).postMessage({ id, ok: false, error: e instanceof Error ? e.message : String(e) });
  }
};
