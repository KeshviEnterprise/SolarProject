import { create } from 'zustand';
import type { Project, ObstacleKind } from '@/types';
import type { LayoutOption } from '@/calculations/pipeline';
import type { ChainAttempt } from '@/services/solarDataProvider';
import { createDemoProject } from '@/utils/projectFactory';
import { saveProject, loadProject, getLastOpen, setLastOpen } from '@/services/storage';
import { dayOfYear } from '@/calculations/solarPosition';

export type SectionId = 'project' | 'location' | 'structure' | 'roof' | 'panels' | 'mounting' | 'layout' | 'shading' | 'electrical' | 'energy' | 'reports';
export type ViewId = 'plan' | '3d' | 'analysis' | 'dashboard';
export type Tool =
  | 'select' | 'pan' | 'rect-boundary' | 'poly-boundary' | 'add-panel'
  | `place:${ObstacleKind}` | 'rect-exclusion' | 'rect-walkway';
export type Selection = { kind: 'obstacle' | 'panel' | 'boundary' | null; ids: string[] };
export type CameraCommand = { kind: 'reset' | 'top' | 'front' | 'side'; n: number };

interface State {
  project: Project;
  past: Project[];
  future: Project[];
  dirty: boolean;
  section: SectionId;
  view: ViewId;
  tool: Tool;
  selection: Selection;
  sun: { doy: number; clockHour: number };
  playing: boolean;
  showShadows: boolean;
  camera: CameraCommand;
  solarStatus: 'idle' | 'loading' | 'error' | 'ok';
  solarAttempts: ChainAttempt[];
  analysisStatus: 'idle' | 'running' | 'error';
  analysisError: string | null;
  layoutOptions: LayoutOption[] | null;
  optionsStatus: 'idle' | 'running' | 'error';
  toast: { text: string; tone: 'ok' | 'error' | 'info'; n: number } | null;
  rightOpen: boolean;

  setProject: (p: Project, opts?: { resetHistory?: boolean; dirty?: boolean }) => void;
  update: (fn: (p: Project) => Project, commit?: boolean) => void;
  checkpoint: () => void;
  undo: () => void;
  redo: () => void;
  save: () => void;
  set: (partial: Partial<State>) => void;
  notify: (text: string, tone?: 'ok' | 'error' | 'info') => void;
}

const HISTORY_LIMIT = 60;

function initialProject(): Project {
  try {
    const last = getLastOpen();
    if (last) { const p = loadProject(last); if (p) return p; }
  } catch { /* fall through */ }
  return createDemoProject();
}

const now = new Date();

export const useStore = create<State>((set, get) => ({
  project: initialProject(),
  past: [],
  future: [],
  dirty: false,
  section: 'project',
  view: 'plan',
  tool: 'select',
  selection: { kind: null, ids: [] },
  sun: { doy: dayOfYear(now.getFullYear(), now.getMonth(), now.getDate()), clockHour: 10 },
  playing: false,
  showShadows: true,
  camera: { kind: 'reset', n: 0 },
  solarStatus: 'idle',
  solarAttempts: [],
  analysisStatus: 'idle',
  analysisError: null,
  layoutOptions: null,
  optionsStatus: 'idle',
  toast: null,
  rightOpen: true,

  setProject: (p, opts = {}) => set((s) => ({
    project: p,
    past: opts.resetHistory ? [] : [...s.past, s.project].slice(-HISTORY_LIMIT),
    future: [],
    dirty: opts.dirty ?? false,
    selection: { kind: null, ids: [] },
    layoutOptions: null,
    solarStatus: p.solarResource ? 'ok' : 'idle',
    solarAttempts: [],
  })),
  update: (fn, commit = true) => set((s) => {
    const next = fn(s.project);
    if (next === s.project) return {};
    return commit
      ? { project: next, past: [...s.past, s.project].slice(-HISTORY_LIMIT), future: [], dirty: true }
      : { project: next, dirty: true };
  }),
  checkpoint: () => set((s) => ({ past: [...s.past, s.project].slice(-HISTORY_LIMIT), future: [] })),
  undo: () => set((s) => {
    if (!s.past.length) return {};
    const prev = s.past[s.past.length - 1];
    return { project: prev, past: s.past.slice(0, -1), future: [s.project, ...s.future], dirty: true };
  }),
  redo: () => set((s) => {
    if (!s.future.length) return {};
    const [next, ...rest] = s.future;
    return { project: next, past: [...s.past, s.project], future: rest, dirty: true };
  }),
  save: () => {
    try {
      const p = get().project;
      saveProject(p);
      setLastOpen(p.id);
      set({ dirty: false });
      get().notify('Project saved', 'ok');
    } catch (e) {
      get().notify(`Save failed: ${e instanceof Error ? e.message : String(e)}`, 'error');
    }
  },
  set: (partial) => set(partial),
  notify: (text, tone = 'info') => set((s) => ({ toast: { text, tone, n: (s.toast?.n ?? 0) + 1 } })),
}));
