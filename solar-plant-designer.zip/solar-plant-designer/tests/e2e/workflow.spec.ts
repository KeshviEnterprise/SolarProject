import { test, expect, type Page } from '@playwright/test';

/**
 * External solar-data services are blocked in these tests so results are deterministic:
 * the app must show "Solar resource data is currently unavailable." and only use demo data
 * after an explicit click. Map tiles / geocoding are blocked as well.
 */
async function blockExternal(page: Page) {
  await page.route(/power\.larc\.nasa\.gov|developer\.nrel\.gov|\/api\/pvgis|nominatim|open-meteo|tile\.openstreetmap|arcgisonline|fonts\.g/, (r) => r.abort('failed'));
}

async function fresh(page: Page) {
  await blockExternal(page);
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await expect(page.getByTestId('plan-svg')).toBeVisible();
}

async function nav(page: Page, id: string) {
  await page.getByTestId(`nav-${id}`).click();
}

async function commit(page: Page, testId: string, value: string) {
  const el = page.getByTestId(testId);
  await el.fill(value);
  await el.press('Enter');
}

async function layoutAndDemoAnalysis(page: Page) {
  await nav(page, 'layout');
  await page.getByTestId('fill-current').click();
  await expect(page.getByTestId('panel-count')).not.toHaveText('0');
  await nav(page, 'energy');
  await page.getByTestId('fetch-solar').click();
  await expect(page.getByTestId('solar-error')).toContainText('Solar resource data is currently unavailable.');
  await page.getByTestId('use-demo-data').click();
  await page.getByTestId('run-analysis').click();
  await expect(page.getByTestId('analysis-view')).toBeVisible();
}

test.beforeEach(async ({ page }) => fresh(page));

test('1. create a new project and rename it', async ({ page }) => {
  page.on('dialog', (d) => d.accept());
  await page.getByTestId('new-project').click();
  await commit(page, 'project-name', 'Warehouse roof A');
  await expect(page.getByText('Warehouse roof A').first()).toBeVisible();
});

test('2. enter coordinates and see calculated sun times', async ({ page }) => {
  await nav(page, 'location');
  await commit(page, 'lat', '28.6139');
  await commit(page, 'lon', '77.2090');
  await expect(page.getByText('28.6139°, 77.2090°')).toBeVisible();
  await expect(page.getByText('Sunrise', { exact: true })).toBeVisible();
  await expect(page.getByText('Day length', { exact: true })).toBeVisible();
});

test('3. invalid inputs are rejected with a message', async ({ page }) => {
  await nav(page, 'location');
  await commit(page, 'lat', '95');
  await expect(page.getByRole('alert').first()).toContainText('90');
  await nav(page, 'structure');
  await commit(page, 'dim-length', '-5');
  await expect(page.getByRole('alert').first()).toBeVisible();
  await nav(page, 'panels');
  await commit(page, 'panel-power', '0');
  await expect(page.getByRole('alert').first()).toBeVisible();
});

test('4. change structure type and dimensions with unit conversion', async ({ page }) => {
  page.on('dialog', (d) => d.accept());
  await nav(page, 'structure');
  await page.getByTestId('structure-type').selectOption('residential-building');
  await page.getByRole('combobox', { name: 'Length (east-west) unit' }).selectOption('ft');
  await commit(page, 'dim-length', '100');
  await commit(page, 'dim-width', '20');
  await page.getByTestId('apply-rectangle').click();
  await expect(page.getByTestId('apply-rectangle')).toContainText('30.48 m × 20.00 m');
});

test('5. draw a rectangular boundary on the plan', async ({ page }) => {
  await nav(page, 'roof');
  await page.getByTestId('tool-rect-boundary').click();
  const box = (await page.getByTestId('plan-svg').boundingBox())!;
  await page.mouse.move(box.x + 200, box.y + 200);
  await page.mouse.down();
  await page.mouse.move(box.x + 450, box.y + 380, { steps: 8 });
  await page.mouse.up();
  await expect(page.getByText(/Boundary · 4 vertices/)).toBeVisible();
});

test('6. place an obstacle and edit its height', async ({ page }) => {
  await nav(page, 'roof');
  await page.getByTestId('place-water-tank').click();
  const box = (await page.getByTestId('plan-svg').boundingBox())!;
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  await expect(page.getByText('Obstacle properties')).toBeVisible();
  await commit(page, 'ob-height', '3.5');
  await expect(page.getByTestId('ob-height')).toHaveValue('3.5');
});

test('7. select a library panel and a custom power rating', async ({ page }) => {
  await nav(page, 'panels');
  const options = await page.getByTestId('panel-select').locator('option').allTextContents();
  expect(options.length).toBeGreaterThan(3);
  await commit(page, 'panel-power', '600');
  await expect(page.getByTestId('panel-select')).toHaveValue('custom');
});

test('8. auto layout evaluates configurations and applies one', async ({ page }) => {
  await nav(page, 'layout');
  await page.getByTestId('generate-auto-layout').click();
  await expect(page.getByTestId('layout-options')).toBeVisible();
  await page.getByTestId('apply-opt-0').click();
  const n = Number(await page.getByTestId('panel-count').textContent());
  expect(n).toBeGreaterThan(100);
  await expect(page.getByTestId('dc-capacity')).toContainText('kWp');
});

test('9. manual mode: add and delete panels, undo', async ({ page }) => {
  await nav(page, 'layout');
  await page.getByTestId('fill-current').click();
  const before = Number(await page.getByTestId('panel-count').textContent());
  await page.getByTestId('tool-add-panel').click();
  const box = (await page.getByTestId('plan-svg').boundingBox())!;
  await page.mouse.click(box.x + 60, box.y + 60);
  await expect(page.getByTestId('panel-count')).toHaveText(String(before + 1));
  await page.getByTestId('delete-panels').click();
  await expect(page.getByTestId('panel-count')).toHaveText(String(before));
  await page.getByRole('button', { name: 'Undo' }).click();
  await expect(page.getByTestId('panel-count')).toHaveText(String(before + 1));
});

test('10. 3D view renders and camera presets work', async ({ page }) => {
  await nav(page, 'layout');
  await page.getByTestId('fill-current').click();
  await page.getByTestId('view-3d').click();
  await expect(page.getByTestId('scene-3d').locator('canvas')).toBeVisible({ timeout: 30_000 });
  await page.getByRole('button', { name: 'Top' }).click();
  await page.getByTestId('view-plan').click();
  await expect(page.getByTestId('plan-svg')).toBeVisible();
});

test('11. solar data failure shows message; demo only after explicit click', async ({ page }) => {
  await nav(page, 'energy');
  await page.getByTestId('fetch-solar').click();
  await expect(page.getByTestId('solar-error')).toContainText('Solar resource data is currently unavailable.');
  await expect(page.getByText('DEMO DATA', { exact: true })).toHaveCount(0);
  await page.getByTestId('use-demo-data').click();
  await expect(page.getByText('DEMO DATA', { exact: true })).toBeVisible();
});

test('12. run analysis: 12-month table, annual total consistent, DEMO labelled', async ({ page }) => {
  await layoutAndDemoAnalysis(page);
  const rows = page.getByTestId('monthly-table').locator('tbody tr');
  await expect(rows).toHaveCount(13);
  const total = Number((await page.getByTestId('annual-total').textContent())!.replace(/,/g, ''));
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += Number((await rows.nth(i).locator('td').nth(5).textContent())!.replace(/,/g, ''));
  expect(Math.abs(sum - total)).toBeLessThanOrEqual(12);
  await expect(page.getByText('DEMO / ESTIMATED results.')).toBeVisible();
  await expect(page.getByTestId('kpi-annual')).toContainText('Wh');
});

test('13. save, reload and export (CSV, JSON, PDF)', async ({ page }) => {
  await layoutAndDemoAnalysis(page);
  await nav(page, 'project');
  await commit(page, 'project-name', 'Persisted project');
  await page.getByTestId('save-project').click();
  await page.reload();
  await expect(page.getByTestId('project-name')).toHaveValue('Persisted project');
  await nav(page, 'reports');
  const [csv] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-csv').click()]);
  expect(csv.suggestedFilename()).toMatch(/monthly\.csv$/);
  const [json] = await Promise.all([page.waitForEvent('download'), page.getByTestId('export-json').click()]);
  expect(json.suggestedFilename()).toMatch(/\.spd\.json$/);
  const [pdf] = await Promise.all([page.waitForEvent('download', { timeout: 60_000 }), page.getByTestId('export-pdf').click()]);
  expect(pdf.suggestedFilename()).toMatch(/report\.pdf$/);
  const path = await pdf.path();
  const fs = await import('node:fs');
  expect(fs.readFileSync(path!).subarray(0, 4).toString()).toBe('%PDF');
});
