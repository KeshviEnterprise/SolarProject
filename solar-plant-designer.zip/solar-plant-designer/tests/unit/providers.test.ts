import { describe, it, expect, vi, afterEach } from 'vitest';
import { NASAProvider } from '@/services/nasaProvider';
import { PVGISProvider } from '@/services/pvgisProvider';
import { MockSolarDataProvider } from '@/services/mockSolarProvider';
import { fetchWithFallback, ProviderError } from '@/services/solarDataProvider';
import { migrateProject } from '@/services/storage';
import { createProject } from '@/utils/projectFactory';

const M = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
const series = (vals: number[]) => Object.fromEntries(M.map((m, i) => [m, vals[i]]));

afterEach(() => vi.unstubAllGlobals());

describe('solar data providers', () => {
  it('parses a NASA POWER climatology response', () => {
    const json = { geometry: { coordinates: [72.8, 21.2, 12] }, header: { fill_value: -999, range: '20-year' }, properties: { parameter: {
      ALLSKY_SFC_SW_DWN: series([5, 5.5, 6, 6.5, 6.8, 5.2, 4, 4.1, 4.9, 5.3, 5, 4.7]), T2M: series(new Array(12).fill(28)), T2M_MAX: series(new Array(12).fill(34)), T2M_MIN: series(new Array(12).fill(22)) } } };
    const r = new NASAProvider().parse(json, 21.2, 72.8, 'u');
    expect(r.isDemo).toBe(false);
    expect(r.monthly[3].ghiKwhM2Day).toBe(6.5);
    expect(r.monthly[0].tMaxC).toBe(34);
    expect(r.elevationM).toBe(12);
  });
  it('rejects NASA responses with fill values', () => {
    const json = { header: { fill_value: -999 }, properties: { parameter: { ALLSKY_SFC_SW_DWN: series([...new Array(11).fill(5), -999]), T2M: series(new Array(12).fill(28)) } } };
    expect(() => new NASAProvider().parse(json, 0, 0, null)).toThrow(ProviderError);
  });
  it('parses PVGIS MRcalc, converting monthly totals to daily means', () => {
    const monthly = [];
    for (const y of [2019, 2020]) for (let m = 1; m <= 12; m++) monthly.push({ year: y, month: m, 'H(h)_m': 31 * 5, T2m: 25 });
    const r = new PVGISProvider('/x').parse({ outputs: { monthly }, inputs: { meteo_data: { radiation_db: 'PVGIS-SARAH3', year_min: 2019, year_max: 2020 } } }, 21, 72, null);
    expect(r.monthly[0].ghiKwhM2Day).toBeCloseTo(5);
    expect(r.monthly[1].ghiKwhM2Day).toBeCloseTo((155 / 28 + 155 / 29) / 2); // leap year handled
    expect(r.period).toBe('2019-2020');
  });
  it('mock provider is always marked as demo', async () => {
    const r = await new MockSolarDataProvider().fetch(21, 72);
    expect(r.isDemo).toBe(true);
    expect(r.providerLabel).toMatch(/DEMO/);
  });
  it('fallback chain reports failures and never silently substitutes demo data', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    const { resource, attempts } = await fetchWithFallback([new NASAProvider(), new PVGISProvider('/x')], 21, 72);
    expect(resource).toBeNull();
    expect(attempts).toHaveLength(2);
    expect(attempts.every((a) => !a.ok)).toBe(true);
  });
});

describe('project schema', () => {
  it('migrates current projects and rejects foreign files', () => {
    const p = createProject();
    expect(migrateProject(JSON.parse(JSON.stringify(p))).id).toBe(p.id);
    expect(() => migrateProject({ hello: 1 })).toThrow();
    expect(() => migrateProject({ ...p, schemaVersion: 99 })).toThrow();
  });
});
