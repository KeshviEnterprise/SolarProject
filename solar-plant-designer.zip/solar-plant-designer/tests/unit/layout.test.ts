import { describe, it, expect } from 'vitest';
import { calculatePanelLayout, calculateRowSpacing, bandIntervals, panelFootprint, calculateLayoutStats, suggestTiltFromLatitude } from '@/calculations/panelLayout';
import { buildSurfaces, surfaceMount, rectangleBoundary, surfaceHeightAt, calculateAreas } from '@/calculations/structure';
import { convexInsidePolygon, convexPolygonsOverlap, rectPolygon, v, polygonArea } from '@/calculations/geometry';
import { createProject } from '@/utils/projectFactory';
import type { Mounting } from '@/types';

const baseSettings = {
  orientation: 'portrait' as const, modulesHigh: 1, moduleGapM: 0, rowSpacingMode: 'shade-free' as const,
  shadeFreeStartHour: 9, shadeFreeEndHour: 15, gcr: 0.5, manualPitchM: 4, walkwayEveryRows: 0, walkwayWidthM: 0.8, setbackM: 0, latitudeDeg: 21,
};

function flatProject(tilt: number) {
  const p = createProject();
  p.structure = { ...p.structure, roofType: 'flat', boundary: rectangleBoundary(10, 5), setbackM: 0 };
  p.mounting = { ...p.mounting, tiltDeg: tilt, azimuthDeg: 180, type: tilt ? 'fixed-tilt' : 'roof-following' } as Mounting;
  return p;
}

describe('panel layout engine', () => {
  it('packs a flat 10 × 5 m area with 1 × 2 m flush modules exactly (20 modules)', () => {
    const p = flatProject(0);
    const s = buildSurfaces(p.structure, p.mounting);
    const res = calculatePanelLayout(s, { S1: surfaceMount(s[0], p.mounting) }, [], { lengthM: 2, widthM: 1 }, baseSettings);
    expect(res.panels.length).toBe(20);
  });
  it('landscape vs portrait counts differ for the same area', () => {
    const p = flatProject(0);
    const s = buildSurfaces(p.structure, p.mounting);
    const m = { S1: surfaceMount(s[0], p.mounting) };
    const land = calculatePanelLayout(s, m, [], { lengthM: 2, widthM: 1 }, { ...baseSettings, orientation: 'landscape' });
    expect(land.panels.length).toBe(25); // 5 across × 5 rows
  });
  it('respects setbacks and obstacles; no panel leaves the boundary or overlaps keep-outs', () => {
    const p = flatProject(0);
    p.structure.boundary = rectangleBoundary(20, 12);
    const s = buildSurfaces(p.structure, p.mounting);
    const keep = [rectPolygon(v(10, 6), 3, 3, 30)];
    const res = calculatePanelLayout(s, { S1: surfaceMount(s[0], p.mounting) }, keep, { lengthM: 2.279, widthM: 1.134 }, { ...baseSettings, setbackM: 1, moduleGapM: 0.02 });
    expect(res.panels.length).toBeGreaterThan(40);
    const e = 1e-6; // tolerance: panels may touch the setback line exactly
    const inner = rectangleBoundary(18 + 2 * e, 10 + 2 * e).map((q) => v(q.x + 1 - e, q.y + 1 - e));
    for (const pn of res.panels) {
      const fp = panelFootprint(pn, { lengthM: 2.279, widthM: 1.134 });
      expect(convexInsidePolygon(fp, inner)).toBe(true);
      expect(convexPolygonsOverlap(fp, keep[0])).toBe(false);
    }
  });
  it('panels do not overlap each other', () => {
    const p = flatProject(20);
    p.structure.boundary = rectangleBoundary(30, 20);
    const s = buildSurfaces(p.structure, p.mounting);
    const res = calculatePanelLayout(s, { S1: surfaceMount(s[0], p.mounting) }, [], { lengthM: 2.279, widthM: 1.134 }, { ...baseSettings, moduleGapM: 0.02 });
    const fps = res.panels.map((pn) => panelFootprint(pn, { lengthM: 2.279, widthM: 1.134 }));
    for (let i = 0; i < fps.length; i++) for (let j = i + 1; j < Math.min(fps.length, i + 40); j++) expect(convexPolygonsOverlap(fps[i], fps[j], 1e-6)).toBe(false);
  });
  it('racked rows are spaced by the shade-free pitch', () => {
    const p = flatProject(20);
    p.structure.boundary = rectangleBoundary(30, 20);
    const s = buildSurfaces(p.structure, p.mounting);
    const res = calculatePanelLayout(s, { S1: surfaceMount(s[0], p.mounting) }, [], { lengthM: 2.279, widthM: 1.134 }, baseSettings);
    const rs = calculateRowSpacing({ latitudeDeg: 21, tiltDeg: 20, slantM: 2.279, azimuthDeg: 180 });
    expect(res.surfaces[0].pitchPlanM).toBeCloseTo(rs.pitchPlanM, 6);
    expect(res.surfaces[0].rows).toBe(Math.floor((20 - rs.tableDepthPlanM) / rs.pitchPlanM) + 1);
  });
  it('band intervals of a concave polygon', () => {
    const L = [v(0, 0), v(10, 0), v(10, 4), v(4, 4), v(4, 10), v(0, 10)];
    expect(bandIntervals(L, 1, 3)).toEqual([[expect.closeTo(0, 5), expect.closeTo(10, 5)]]);
    const iv = bandIntervals(L, 3, 6);
    expect(iv[0][1]).toBeCloseTo(4, 5);
  });
  it('computes layout statistics', () => {
    const p = flatProject(0);
    const s = buildSurfaces(p.structure, p.mounting);
    const res = calculatePanelLayout(s, { S1: surfaceMount(s[0], p.mounting) }, [], { lengthM: 2, widthM: 1 }, baseSettings);
    const st = calculateLayoutStats(res.panels, { ...p.panel, lengthMm: 2000, widthMm: 1000, powerW: 500 }, 50, 50);
    expect(st.dcKwp).toBeCloseTo(10);
    expect(st.utilizationPct).toBeCloseTo(80);
    expect(st.rows).toBe(2);
  });
  it('suggested tilt increases with latitude', () => {
    expect(suggestTiltFromLatitude(10)).toBeLessThan(suggestTiltFromLatitude(40));
  });
});

describe('row spacing', () => {
  it('shade-free pitch at noon matches the closed-form result', () => {
    const lat = 21.17, tilt = 20, L = 2.279;
    const rs = calculateRowSpacing({ latitudeDeg: lat, tiltDeg: tilt, slantM: L, azimuthDeg: 180, startHour: 12, endHour: 12 });
    const elev = 90 - lat - 23.44;
    const expected = L * (Math.cos(tilt * Math.PI / 180) + Math.sin(tilt * Math.PI / 180) / Math.tan(elev * Math.PI / 180));
    expect(rs.pitchPlanM).toBeCloseTo(expected, 1);
  });
  it('wider shade-free window needs a larger pitch', () => {
    const a = calculateRowSpacing({ latitudeDeg: 30, tiltDeg: 25, slantM: 2, azimuthDeg: 180, startHour: 10, endHour: 14 });
    const b = calculateRowSpacing({ latitudeDeg: 30, tiltDeg: 25, slantM: 2, azimuthDeg: 180, startHour: 9, endHour: 15 });
    expect(b.pitchPlanM).toBeGreaterThan(a.pitchPlanM);
    expect(b.gcr).toBeLessThan(a.gcr);
  });
  it('south-facing terrain slope reduces the required pitch', () => {
    const flat = calculateRowSpacing({ latitudeDeg: 30, tiltDeg: 25, slantM: 2, azimuthDeg: 180 });
    const hill = calculateRowSpacing({ latitudeDeg: 30, tiltDeg: 25, slantM: 2, azimuthDeg: 180, terrainSlopeDeg: 5 });
    expect(hill.pitchPlanM).toBeLessThan(flat.pitchPlanM);
  });
});

describe('structure surfaces', () => {
  it('gable roof splits into two planes with correct heights', () => {
    const p = createProject();
    p.structure = { ...p.structure, roofType: 'gable', boundary: rectangleBoundary(50, 30), slopeDeg: 10, roofAzimuthDeg: 180, eaveHeightM: 8 };
    const s = buildSurfaces(p.structure, p.mounting);
    expect(s).toHaveLength(2);
    expect(polygonArea(s[0].polygon) + polygonArea(s[1].polygon)).toBeCloseTo(1500);
    expect(s[0].azimuthDeg).toBe(180);
    expect(s[1].azimuthDeg).toBe(0);
    // south plane: eave at y = 0, ridge at y = 15
    expect(surfaceHeightAt(s[0], v(10, 0))).toBeCloseTo(8, 6);
    expect(surfaceHeightAt(s[0], v(10, 15))).toBeCloseTo(8 + 15 * Math.tan(10 * Math.PI / 180), 6);
    expect(surfaceMount(s[0], p.mounting).tiltDeg).toBe(10);
  });
  it('roof and usable areas', () => {
    const p = createProject();
    p.structure = { ...p.structure, roofType: 'flat', boundary: rectangleBoundary(30, 20), setbackM: 1 };
    const a = calculateAreas(p.structure, buildSurfaces(p.structure, p.mounting), []);
    expect(a.roofPlanAreaM2).toBeCloseTo(600);
    expect(Math.abs(a.usableAreaM2 - 28 * 18)).toBeLessThan(6);
  });
});
