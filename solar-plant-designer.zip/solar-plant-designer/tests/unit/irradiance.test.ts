import { describe, it, expect } from 'vitest';
import { dailyExtraterrestrialHorizontal, erbsDailyDiffuseFraction, calculateSolarIrradiance, calculatePlaneOfArrayIrradiance, iamAshrae, sunsetHourAngleDeg } from '@/calculations/irradiance';

describe('irradiance', () => {
  it('H0 matches Duffie & Beckman example (43°N, 15 April ≈ 33.8 MJ/m²)', () => {
    const h0MJ = dailyExtraterrestrialHorizontal(105, 43) * 3.6;
    expect(Math.abs(h0MJ - 33.8) / 33.8).toBeLessThan(0.015);
  });
  it('sunset hour angle 90° at equator', () => {
    expect(sunsetHourAngleDeg(0, 10)).toBeCloseTo(90, 6);
  });
  it('Erbs diffuse fraction is bounded and decreasing', () => {
    const a = erbsDailyDiffuseFraction(0.3, 80), b = erbsDailyDiffuseFraction(0.6, 80);
    expect(a).toBeGreaterThan(b);
    expect(erbsDailyDiffuseFraction(0.8, 80)).toBeCloseTo(0.143);
    expect(erbsDailyDiffuseFraction(0.8, 90)).toBeCloseTo(0.175);
  });
  it('hourly distribution conserves the daily total', () => {
    const r = calculateSolarIrradiance(21, 105, 6.2, 0.25);
    const sum = r.points.reduce((a, p) => a + p.ghi * 0.25, 0) / 1000;
    expect(sum).toBeCloseTo(6.2, 6);
    const dsum = r.points.reduce((a, p) => a + p.dhi * 0.25, 0) / 1000;
    expect(dsum).toBeLessThanOrEqual(6.2 + 1e-9);
  });
  it('horizontal POA equals GHI', () => {
    const p = calculatePlaneOfArrayIrradiance(800, 200, 30, 150, 0, 180, 0.2, 100);
    expect(p.total).toBeCloseTo(800, 6);
  });
  it('tilted equator-facing plane gets more beam in winter', () => {
    const flat = calculatePlaneOfArrayIrradiance(600, 150, 60, 180, 0, 180, 0.2, 355);
    const tilted = calculatePlaneOfArrayIrradiance(600, 150, 60, 180, 30, 180, 0.2, 355);
    expect(tilted.total).toBeGreaterThan(flat.total);
  });
  it('IAM is 1 at normal incidence and 0 behind', () => {
    expect(iamAshrae(1)).toBe(1);
    expect(iamAshrae(0)).toBe(0);
    expect(iamAshrae(0.5)).toBeCloseTo(0.95);
  });
});
