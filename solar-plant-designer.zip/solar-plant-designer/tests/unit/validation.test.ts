import { describe, it, expect } from 'vitest';
import { fieldError, latitudeSchema, longitudeSchema, positiveLength, validatePanel, collectDesignIssues } from '@/calculations/validation';
import { createProject } from '@/utils/projectFactory';
import { v } from '@/calculations/geometry';

describe('validation', () => {
  it('rejects negative and zero dimensions', () => {
    expect(fieldError(positiveLength, -1)).toBeTruthy();
    expect(fieldError(positiveLength, 0)).toBeTruthy();
    expect(fieldError(positiveLength, 2.3)).toBeNull();
  });
  it('rejects invalid coordinates', () => {
    expect(fieldError(latitudeSchema, 91)).toBeTruthy();
    expect(fieldError(longitudeSchema, -181)).toBeTruthy();
    expect(fieldError(latitudeSchema, 21.17)).toBeNull();
  });
  it('rejects zero panel power and zero dimensions', () => {
    const p = createProject();
    expect(validatePanel({ ...p.panel, powerW: 0 }).powerW).toBeTruthy();
    expect(validatePanel({ ...p.panel, lengthMm: 0 }).lengthMm).toBeTruthy();
    expect(validatePanel({ ...p.panel, vmpV: 60 }).vmpV).toBeTruthy();
    expect(Object.keys(validatePanel(p.panel))).toHaveLength(0);
  });
  it('reports invalid polygons, missing structural info and missing solar data', () => {
    const p = createProject();
    p.structure.boundary = [v(0, 0), v(1, 1), v(1, 0), v(0, 1)];
    const issues = collectDesignIssues(p);
    expect(issues.some((i) => i.level === 'error' && i.area === 'Roof')).toBe(true);
    expect(issues.some((i) => i.message === 'Structural suitability has not been verified.')).toBe(true);
    expect(issues.some((i) => i.area === 'Solar data')).toBe(true);
  });
  it('flags panels outside the boundary', () => {
    const p = createProject();
    p.layout.panels = [{ id: 'x', surfaceId: 'S1', center: v(-5, -5), azimuthDeg: 180, tiltDeg: 0, orientation: 'portrait', row: -1, stackIndex: 0, locked: false, manual: true }];
    expect(collectDesignIssues(p).some((i) => i.area === 'Layout' && i.message.includes('outside'))).toBe(true);
  });
});
