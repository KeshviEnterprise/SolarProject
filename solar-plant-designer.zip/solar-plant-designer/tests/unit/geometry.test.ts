import { describe, it, expect } from 'vitest';
import { polygonArea, pointInPolygon, isSimplePolygon, offsetPolygonInward, convexPolygonsOverlap, convexInsidePolygon, rectPolygon, convexHull, clipHalfPlane, sampleFreeArea, v, centroid } from '@/calculations/geometry';

const rect = [v(0, 0), v(10, 0), v(10, 5), v(0, 5)];
const L = [v(0, 0), v(10, 0), v(10, 4), v(4, 4), v(4, 10), v(0, 10)];

describe('polygon geometry', () => {
  it('computes rectangle and L-shape area', () => {
    expect(polygonArea(rect)).toBeCloseTo(50);
    expect(polygonArea([...rect].reverse())).toBeCloseTo(50);
    expect(polygonArea(L)).toBeCloseTo(40 + 24);
  });
  it('computes centroid', () => {
    const c = centroid(rect);
    expect(c.x).toBeCloseTo(5); expect(c.y).toBeCloseTo(2.5);
  });
  it('tests point containment in concave polygons', () => {
    expect(pointInPolygon(v(2, 8), L)).toBe(true);
    expect(pointInPolygon(v(8, 8), L)).toBe(false);
  });
  it('detects invalid polygons', () => {
    expect(isSimplePolygon(rect)).toBe(true);
    expect(isSimplePolygon([v(0, 0), v(1, 1), v(1, 0), v(0, 1)])).toBe(false); // bow-tie
    expect(isSimplePolygon([v(0, 0), v(1, 1)])).toBe(false);
    expect(isSimplePolygon([v(0, 0), v(1, 0), v(2, 0)])).toBe(false); // zero area
  });
  it('offsets a rectangle inward exactly', () => {
    const o = offsetPolygonInward(rect, 1);
    expect(polygonArea(o)).toBeCloseTo(8 * 3);
    expect(offsetPolygonInward(rect, 3)).toEqual([]);
  });
  it('SAT overlap between rotated rectangles', () => {
    expect(convexPolygonsOverlap(rectPolygon(v(0, 0), 2, 2, 0), rectPolygon(v(1.5, 0), 2, 2, 45))).toBe(true);
    expect(convexPolygonsOverlap(rectPolygon(v(0, 0), 2, 2, 0), rectPolygon(v(3, 0), 2, 2, 0))).toBe(false);
  });
  it('convex-inside test rejects rectangles crossing a concave notch', () => {
    expect(convexInsidePolygon(rectPolygon(v(2, 2), 2, 2), L)).toBe(true);
    expect(convexInsidePolygon(rectPolygon(v(5, 5), 3, 3), L)).toBe(false);
  });
  it('convex hull and half-plane clip', () => {
    expect(convexHull([v(0, 0), v(1, 1), v(2, 0), v(1, 0.2), v(1, -1)]).length).toBe(4);
    const half = clipHalfPlane(rect, v(1, 0), 5);
    expect(polygonArea(half)).toBeCloseTo(25);
  });
  it('samples free area with setback and keep-outs', () => {
    const a = sampleFreeArea(rect, 1, [rectPolygon(v(5, 2.5), 2, 2)]);
    expect(a).toBeGreaterThan(24 - 4 - 1);
    expect(a).toBeLessThan(24 - 4 + 1);
  });
});
