import { describe, it, expect } from 'vitest';
import { calculateShadowLength, shadowDirectionDeg, shadowPolygon, interRowShadedFraction, computeObstacleShading, buildShadingScene } from '@/calculations/shading';
import { calculateRowSpacing } from '@/calculations/panelLayout';
import { rectPolygon, v, polygonArea, pointInPolygon } from '@/calculations/geometry';
import { solarPositionAtSolarTime } from '@/calculations/solarPosition';
import type { PlacedPanel } from '@/types';

describe('shadow engine', () => {
  it('shadow length = h / tan(elevation)', () => {
    expect(calculateShadowLength(10, 45)).toBeCloseTo(10);
    expect(calculateShadowLength(10, 30)).toBeCloseTo(17.3205, 3);
    expect(calculateShadowLength(10, 0)).toBe(Infinity);
  });
  it('shadows point away from the sun', () => {
    expect(shadowDirectionDeg(180)).toBe(0);
    expect(shadowDirectionDeg(90)).toBe(270);
  });
  it('shadow polygon of a 1 m cube with sun due south at 45° extends 1 m north', () => {
    const fp = rectPolygon(v(0, 0), 1, 1);
    const sh = shadowPolygon(fp, 1, 45, 180)!;
    expect(polygonArea(sh)).toBeCloseTo(2, 6);
    expect(pointInPolygon(v(0, 1.2), sh)).toBe(true);
    expect(pointInPolygon(v(0, -1.2), sh)).toBe(false);
  });
  it('no shadow when object is below the receiver or sun is down', () => {
    expect(shadowPolygon(rectPolygon(v(0, 0), 1, 1), -1, 45, 180)).toBeNull();
    expect(shadowPolygon(rectPolygon(v(0, 0), 1, 1), 2, -5, 180)).toBeNull();
  });
  it('inter-row shading is zero at the shade-free pitch and positive when rows are closer', () => {
    const lat = 21, tilt = 20, L = 2.279;
    const rs = calculateRowSpacing({ latitudeDeg: lat, tiltDeg: tilt, slantM: L, azimuthDeg: 180, startHour: 9, endHour: 15 });
    for (const h of [9, 10, 12, 14, 15]) {
      const pos = solarPositionAtSolarTime(lat, rs.designDoy, h);
      expect(interRowShadedFraction(pos.elevationDeg, pos.azimuthDeg, tilt, 180, L, rs.pitchPlanM + 1e-6)).toBeLessThan(1e-6);
    }
    const pos9 = solarPositionAtSolarTime(lat, rs.designDoy, 9);
    expect(interRowShadedFraction(pos9.elevationDeg, pos9.azimuthDeg, tilt, 180, L, rs.pitchPlanM * 0.8)).toBeGreaterThan(0);
  });
  it('shades modules north of a tall obstacle at low sun', () => {
    const panels: PlacedPanel[] = [
      { id: 'a', surfaceId: 'S1', center: v(0, 3), azimuthDeg: 180, tiltDeg: 0, orientation: 'portrait', row: 0, stackIndex: 0, locked: false, manual: false },
      { id: 'b', surfaceId: 'S1', center: v(0, -5), azimuthDeg: 180, tiltDeg: 0, orientation: 'portrait', row: 1, stackIndex: 0, locked: false, manual: false },
    ];
    const scene = buildShadingScene(panels, { lengthM: 2, widthM: 1 }, [], [{ id: 'o', label: 'tank', footprint: rectPolygon(v(0, 0), 2, 2), baseZ: 0, topZ: 3 }], 0.3, {});
    const f = computeObstacleShading(scene, 30, 180);
    expect(f[0]).toBeGreaterThan(0.5);
    expect(f[1]).toBe(0);
  });
});

import { shadowOnPlane, receiverPlane } from '@/calculations/shading';
describe('shadow on sloped plane', () => {
  it('matches the horizontal result on a flat plane', () => {
    const fp = rectPolygon(v(0, 0), 1, 1);
    const a = shadowOnPlane(fp, 1, { a: 0, gx: 0, gy: 0 }, 45, 180)!;
    expect(polygonArea(a)).toBeCloseTo(2, 6);
  });
  it('a plane rising away from the sun shortens the shadow', () => {
    const fp = rectPolygon(v(0, 0), 1, 1);
    const flat = shadowOnPlane(fp, 1, { a: 0, gx: 0, gy: 0 }, 30, 180)!;
    const rising = shadowOnPlane(fp, 1, { a: 0, gx: 0, gy: Math.tan(0.2) }, 30, 180)!;
    expect(polygonArea(rising)).toBeLessThan(polygonArea(flat));
  });
  it('receiverPlane reproduces surface heights', () => {
    const s = { id: 'S1', name: '', kind: 'shed' as const, polygon: [v(0, 0), v(10, 0), v(10, 10), v(0, 10)], slopeDeg: 10, azimuthDeg: 180, baseZ: 5, riseDir: v(0, 1), riseRef: 0 };
    const pl = receiverPlane(s, 0);
    expect(pl.a + pl.gy * 10).toBeCloseTo(5 + 10 * Math.tan(10 * Math.PI / 180), 9);
  });
});
