import { describe, it, expect } from 'vitest';
import { createDemoProject } from '@/utils/projectFactory';
import { generateLayout, runAnalysis, generateLayoutOptions, optimiseTilt } from '@/calculations/pipeline';
import { MockSolarDataProvider } from '@/services/mockSolarProvider';

describe('end-to-end pipeline (demo project, DEMO solar data)', () => {
  const p = createDemoProject();
  p.solarResource = new MockSolarDataProvider().build(p.location.latitude, p.location.longitude);
  const layout = generateLayout(p);
  p.layout = { panels: layout.panels, pitchBySurface: layout.pitchBySurface, configLabel: 'test', generatedAt: '' };

  it('lays out panels on both gable planes', () => {
    expect(layout.panels.length).toBeGreaterThan(300);
    expect(new Set(layout.panels.map((x) => x.surfaceId)).size).toBe(2);
  });
  it('produces finite monthly and annual results', () => {
    const a = runAnalysis(p);
    expect(a.months).toHaveLength(12);
    expect(a.isDemoData).toBe(true);
    for (const m of a.months) expect(Number.isFinite(m.acKwh) && m.acKwh > 0).toBe(true);
    expect(a.annualAcKwh).toBeCloseTo(a.months.reduce((s, m) => s + m.acKwh, 0), 3);
    expect(a.daily).toHaveLength(365);
    expect(a.daily.reduce((s, d) => s + d, 0)).toBeCloseTo(a.annualAcKwh, 0);
    expect(a.performanceRatio).toBeGreaterThan(0.6);
    expect(a.performanceRatio).toBeLessThan(0.95);
    expect(a.lossStages[a.lossStages.length - 1].energyAfterKwh).toBeCloseTo(a.annualAcKwh, 3);
  });
  it('evaluates alternative configurations with measurable differences', () => {
    const opts = generateLayoutOptions(p);
    expect(opts.length).toBeGreaterThanOrEqual(2);
    for (const o of opts) expect(o.annualKwh).not.toBeNull();
  });
  it('racked flat-roof options differ in count, pitch and shading', () => {
    const q = createDemoProject();
    q.structure = { ...q.structure, roofType: 'flat', slopeDeg: 0, parapetHeightM: 1 };
    q.mounting = { ...q.mounting, type: 'fixed-tilt', tiltDeg: 20 };
    q.solarResource = p.solarResource;
    const opts = generateLayoutOptions(q);
    expect(opts).toHaveLength(6);
    expect(new Set(opts.map((o) => o.panelCount)).size).toBeGreaterThan(2);
    const wide = opts.find((o) => o.label.includes('09-15'))!, narrow = opts.find((o) => o.label.includes('10-14'))!;
    expect(narrow.pitchM!).toBeLessThan(wide.pitchM!);
    expect(narrow.panelCount).toBeGreaterThanOrEqual(wide.panelCount);
    expect(narrow.shadingLossPct!).toBeGreaterThan(wide.shadingLossPct!);
  });
  it('tilt optimisation returns a plausible tilt for 21°N', () => {
    const t = optimiseTilt(p)!;
    expect(t.tiltDeg).toBeGreaterThan(10);
    expect(t.tiltDeg).toBeLessThan(30);
  });
});
