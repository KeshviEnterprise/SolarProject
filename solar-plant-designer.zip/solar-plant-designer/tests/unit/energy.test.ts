import { describe, it, expect } from 'vitest';
import { calculateMonthlyEnergy, calculateSpecificYield, calculateCapacityFactor, calculatePerformanceRatio, calculateAnnualEnergy, ambientAt, type EnergyInput } from '@/calculations/energy';
import { calculateSystemLosses, calculateTemperatureLoss, cellTemperature, DEFAULT_LOSSES } from '@/calculations/losses';
import type { SolarResource } from '@/types';

const resource: SolarResource = {
  provider: 'demo', providerLabel: 'test', isDemo: true, fetchedAt: '', latitude: 21, longitude: 72, elevationM: null, period: '', notes: [], requestUrl: null,
  monthly: [5, 5.8, 6.5, 7, 7.1, 5.5, 4.2, 4.3, 5, 5.5, 5, 4.7].map((g) => ({ ghiKwhM2Day: g, tMeanC: 28, tMaxC: 34, tMinC: 22 })),
};
const zeroLoss = { soilingPct: 0, mismatchPct: 0, dcWiringPct: 0, acWiringPct: 0, inverterPct: 0, availabilityPct: 100, otherPct: 0, shadingOverridePct: null, albedo: 0.2 };
const surf = (tilt: number) => ({ id: 's', name: 's', tiltDeg: tilt, azimuthDeg: 180, panelIndices: [], kWp: 100, uValue: 29, racked: false, tableSlantM: 2, pitchPlanM: 4, terrainSlopeDeg: 0, frontRowShare: 1, seasonalTiltsDeg: null });
const input = (tilt: number, overrides: Partial<EnergyInput> = {}): EnergyInput => ({ latitudeDeg: 21, resource, surfaces: [surf(tilt)], moduleEfficiency: 0.21, gammaPctPerC: 0, losses: zeroLoss, acLimitKw: null, scene: null, ...overrides });
const annualGhi = resource.monthly.reduce((a, m, i) => a + m.ghiKwhM2Day * [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][i], 0);

describe('energy model', () => {
  it('horizontal array: nominal energy equals kWp × annual GHI (energy conservation)', () => {
    const out = calculateMonthlyEnergy(input(0));
    expect(Math.abs(out.stages[0].after - 100 * annualGhi) / (100 * annualGhi)).toBeLessThan(0.005);
  });
  it('with zero losses and γ = 0 only IAM reduces output', () => {
    const out = calculateMonthlyEnergy(input(0));
    const annual = calculateAnnualEnergy(out.months);
    const ratio = annual / out.stages[0].after;
    expect(ratio).toBeGreaterThan(0.95);
    expect(ratio).toBeLessThan(1);
  });
  it('equator-facing tilt near latitude increases annual POA at 21°N', () => {
    const flat = calculateMonthlyEnergy(input(0)).months.reduce((a, m) => a + m.poaKwhM2, 0);
    const tilted = calculateMonthlyEnergy(input(20)).months.reduce((a, m) => a + m.poaKwhM2, 0);
    expect(tilted).toBeGreaterThan(flat);
    expect(tilted / flat).toBeLessThan(1.15);
  });
  it('temperature coefficient reduces output in a hot climate', () => {
    const a = calculateAnnualEnergy(calculateMonthlyEnergy(input(20)).months);
    const b = calculateAnnualEnergy(calculateMonthlyEnergy(input(20, { gammaPctPerC: -0.35 })).months);
    expect(b).toBeLessThan(a);
    expect(b / a).toBeGreaterThan(0.85);
  });
  it('system losses apply multiplicatively', () => {
    const a = calculateAnnualEnergy(calculateMonthlyEnergy(input(20)).months);
    const b = calculateAnnualEnergy(calculateMonthlyEnergy(input(20, { losses: { ...zeroLoss, soilingPct: 10 } })).months);
    expect(b / a).toBeCloseTo(0.9, 6);
  });
  it('AC limit clips output', () => {
    const a = calculateAnnualEnergy(calculateMonthlyEnergy(input(20)).months);
    const b = calculateAnnualEnergy(calculateMonthlyEnergy(input(20, { acLimitKw: 40 })).months);
    expect(b).toBeLessThan(a);
  });
  it('loss stages are monotonically non-increasing', () => {
    const out = calculateMonthlyEnergy(input(20, { losses: DEFAULT_LOSSES, gammaPctPerC: -0.35 }));
    for (let i = 1; i < out.stages.length; i++) expect(out.stages[i].after).toBeLessThanOrEqual(out.stages[i - 1].after + 1e-6);
  });
  it('metric helpers', () => {
    expect(calculateSpecificYield(150000, 100)).toBe(1500);
    expect(calculateCapacityFactor(876000, 500)).toBeCloseTo(0.2);
    expect(calculatePerformanceRatio(160000, 100, 2000)).toBeCloseTo(0.8);
    expect(calculateSpecificYield(1, 0)).toBe(0);
  });
  it('diurnal ambient model averages to the mean', () => {
    let s = 0; for (let h = 0; h < 24; h += 0.5) s += ambientAt(28, 34, 22, h);
    expect(s / 48).toBeCloseTo(28, 6);
    expect(ambientAt(28, 34, 22, 15)).toBeCloseTo(34);
    expect(ambientAt(28, 34, 22, 3)).toBeCloseTo(22);
  });
});

describe('loss model', () => {
  it('combines fixed losses multiplicatively', () => {
    const r = calculateSystemLosses({ ...zeroLoss, soilingPct: 2, mismatchPct: 2, availabilityPct: 99 });
    expect(r.combinedFactor).toBeCloseTo(0.98 * 0.98 * 0.99, 9);
  });
  it('temperature factor and cell temperature', () => {
    expect(calculateTemperatureLoss(25, -0.35)).toBe(1);
    expect(calculateTemperatureLoss(55, -0.35)).toBeCloseTo(0.895);
    expect(cellTemperature(30, 1000, 0.2, 29)).toBeCloseTo(30 + 0.9 * 1000 * 0.8 / 29, 6);
  });
});
