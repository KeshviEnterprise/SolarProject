import { describe, it, expect } from 'vitest';
import { declinationDeg, calculateSolarPosition, calculateSunriseSunset, dayOfYear, solarPositionAtSolarTime, equationOfTimeMin } from '@/calculations/solarPosition';

describe('solar position (NOAA)', () => {
  it('declination near solstices and equinox', () => {
    expect(declinationDeg(172)).toBeCloseTo(23.44, 0);
    expect(declinationDeg(355)).toBeCloseTo(-23.44, 0);
    expect(Math.abs(declinationDeg(80))).toBeLessThan(1);
  });
  it('equation of time extremes', () => {
    expect(equationOfTimeMin(307)).toBeGreaterThan(15); // early Nov ≈ +16 min
    expect(equationOfTimeMin(42)).toBeLessThan(-13); // mid Feb ≈ −14 min
  });
  it('day of year handles leap years', () => {
    expect(dayOfYear(2023, 2, 1)).toBe(60);
    expect(dayOfYear(2024, 2, 1)).toBe(61);
  });
  it('solar-noon elevation = 90 − |φ − δ|', () => {
    const lat = 21.17, doy = 172;
    const p = solarPositionAtSolarTime(lat, doy, 12);
    expect(p.elevationDeg).toBeCloseTo(90 - Math.abs(lat - declinationDeg(doy)), 1);
  });
  it('azimuth: east in morning, south at noon, west in afternoon (northern mid-latitude)', () => {
    expect(solarPositionAtSolarTime(40, 80, 8).azimuthDeg).toBeGreaterThan(90);
    expect(solarPositionAtSolarTime(40, 80, 8).azimuthDeg).toBeLessThan(180);
    expect(solarPositionAtSolarTime(40, 80, 12).azimuthDeg).toBeCloseTo(180, 0);
    expect(solarPositionAtSolarTime(40, 80, 16).azimuthDeg).toBeGreaterThan(180);
  });
  it('clock-time position at Greenwich solar noon', () => {
    // Greenwich, 21 June, ~12:02 UTC → elevation ≈ 90 − (51.48 − 23.44) ≈ 61.96°
    const p = calculateSolarPosition(51.4769, 0, 172, 12.03, 0);
    expect(p.elevationDeg).toBeCloseTo(61.96, 0);
    expect(p.azimuthDeg).toBeGreaterThan(178);
    expect(p.azimuthDeg).toBeLessThan(182);
  });
  it('equator equinox day length ≈ 12 h 07 min (refraction + disc)', () => {
    const t = calculateSunriseSunset(0, 0, 80, 0);
    expect(t.dayLengthHours).toBeGreaterThan(12.05);
    expect(t.dayLengthHours).toBeLessThan(12.2);
  });
  it('Surat sunrise/sunset are ordered and plausible', () => {
    const jun = calculateSunriseSunset(21.17, 72.83, 172, 5.5);
    const dec = calculateSunriseSunset(21.17, 72.83, 355, 5.5);
    expect(jun.dayLengthHours).toBeGreaterThan(dec.dayLengthHours);
    expect(jun.sunrise!).toBeGreaterThan(5.5); expect(jun.sunrise!).toBeLessThan(6.3);
    expect(jun.sunset!).toBeGreaterThan(19); expect(jun.sunset!).toBeLessThan(19.6);
    expect(jun.solarNoon).toBeGreaterThan(12.4); expect(jun.solarNoon).toBeLessThan(12.8);
  });
  it('polar day and night', () => {
    expect(calculateSunriseSunset(80, 0, 172, 0).polar).toBe('day');
    expect(calculateSunriseSunset(80, 0, 355, 0).polar).toBe('night');
  });
});
