import { describe, it, expect } from 'vitest';
import { calculateStringConfiguration, suggestStringConfiguration, moduleVoltageAt } from '@/calculations/electrical';
import { PANEL_LIBRARY } from '@/data/panelLibrary';
import { INVERTER_LIBRARY } from '@/data/inverterLibrary';

const panel = PANEL_LIBRARY[0]; // Voc 49.6, βVoc −0.27 %/°C
const inv = INVERTER_LIBRARY[3]; // 50 kW, 1100 V

describe('electrical', () => {
  it('temperature-corrected Voc rises in the cold', () => {
    expect(moduleVoltageAt(49.6, -0.27, 0)).toBeCloseTo(49.6 * (1 + 0.0027 * 25), 6);
  });
  it('computes string values and DC/AC ratio', () => {
    const r = calculateStringConfiguration({ panel, inverter: inv, inverterQty: 1, modulesPerString: 18, stringsTotal: 6, minAmbientC: 10, maxAmbientC: 45, layoutPanelCount: 108 });
    expect(r.modulesInStrings).toBe(108);
    expect(r.dcKwp).toBeCloseTo(59.4);
    expect(r.dcAcRatio).toBeCloseTo(59.4 / 50);
    expect(r.stringVocStcV).toBeCloseTo(18 * 49.6);
    expect(r.warnings.filter((w) => w.level === 'error')).toHaveLength(0);
  });
  it('flags over-voltage strings', () => {
    const r = calculateStringConfiguration({ panel, inverter: inv, inverterQty: 1, modulesPerString: 24, stringsTotal: 2, minAmbientC: 0, maxAmbientC: 45, layoutPanelCount: 48 });
    expect(r.warnings.some((w) => w.level === 'error' && w.message.includes('exceeds'))).toBe(true);
  });
  it('flags too few modules in the layout', () => {
    const r = calculateStringConfiguration({ panel, inverter: inv, inverterQty: 1, modulesPerString: 18, stringsTotal: 6, minAmbientC: 10, maxAmbientC: 45, layoutPanelCount: 100 });
    expect(r.warnings.some((w) => w.level === 'error')).toBe(true);
  });
  it('suggests a valid configuration', () => {
    const s = suggestStringConfiguration(panel, inv, 1, 100, 10, 45)!;
    expect(s.modulesPerString).toBeGreaterThanOrEqual(s.minN);
    expect(s.modulesPerString).toBeLessThanOrEqual(s.maxN);
    const r = calculateStringConfiguration({ panel, inverter: inv, inverterQty: 1, modulesPerString: s.modulesPerString, stringsTotal: s.stringsTotal, minAmbientC: 10, maxAmbientC: 45, layoutPanelCount: 100 });
    expect(r.warnings.filter((w) => w.level === 'error')).toHaveLength(0);
  });
});
