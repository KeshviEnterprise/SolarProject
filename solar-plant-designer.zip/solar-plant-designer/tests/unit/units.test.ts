import { describe, it, expect } from 'vitest';
import { toMetres, fromMetres, convertLength, areaFromM2, formatEnergyKwh, norm360 } from '@/calculations/units';

describe('unit conversion', () => {
  it('converts lengths to metres', () => {
    expect(toMetres(2279, 'mm')).toBeCloseTo(2.279, 9);
    expect(toMetres(100, 'cm')).toBe(1);
    expect(toMetres(12, 'in')).toBeCloseTo(0.3048, 9);
    expect(toMetres(1, 'ft')).toBeCloseTo(0.3048, 9);
  });
  it('round-trips every unit', () => {
    for (const u of ['mm', 'cm', 'm', 'in', 'ft'] as const) expect(fromMetres(toMetres(7.25, u), u)).toBeCloseTo(7.25, 9);
  });
  it('converts between units', () => {
    expect(convertLength(1, 'ft', 'in')).toBeCloseTo(12, 9);
    expect(convertLength(1, 'm', 'mm')).toBeCloseTo(1000, 9);
  });
  it('converts areas', () => {
    expect(areaFromM2(1, 'ft')).toBeCloseTo(10.7639, 3);
  });
  it('formats energy with units', () => {
    expect(formatEnergyKwh(1234)).toBe('1,234 kWh');
    expect(formatEnergyKwh(123456)).toBe('123.46 MWh');
  });
  it('normalises angles', () => {
    expect(norm360(-90)).toBe(270);
    expect(norm360(450)).toBe(90);
  });
});
